# Prompt to build or extend this agent

Paste the block below into Claude Code (or another AI coding tool) in an empty folder to build the agent from scratch, or in this folder to extend it. The working code in this folder is the reference implementation of this prompt.

```
Build a WhatsApp-only operations agent for a hotel and restaurant group, in Python.

Stack
- FastAPI web server, single process, SQLite database, APScheduler for timed jobs.
- WhatsApp through Twilio: POST /whatsapp webhook (validate X-Twilio-Signature), answer
  Twilio immediately with empty TwiML and send the real reply through the Twilio REST API.
  Free-form messages only within 24h of the person's last message; outside that, send an
  approved Content Template (one variable) whose Content SID comes from the environment.
  Download media (MediaUrl0..n) with the Twilio account SID and auth token.
- Claude through the official anthropic Python SDK (client.beta.messages.create), model
  claude-opus-5-5, thinking {type: adaptive}, output_config effort "low", server-side refusal
  fallback (betas ["server-side-fallback-2026-07-01"], fallbacks "default"), a stable cached
  system prompt, and a manual tool-use loop. Keep each person's conversation append-only and
  start a fresh one after 3 hours idle or 60 messages. Put the sender's name, roles,
  department, outlet and local time in a <sender> block at the start of each user turn.
  Images and PDFs go to Claude as image/document blocks so it can read bills and count sheets.

People and roles (configurable): admin, requester, approver, purchase_manager, store_keeper,
counter, accounts. Each tool checks the sender's role.

Workflow 1, purchase and requisition
- Staff describe what they need in any words. The agent identifies department and request
  type, matches items to the item master, and collects every required field of that
  department/type format (formats are configurable lists of fields with type and required).
- Routing rules (configurable, first match wins) match on department, request type, minimum
  value and urgency, and give an ordered list of approvers, who to notify after approval,
  and an escalation time and contact. Unanswered requests are reminded and escalated.
- Approvers approve, reject with a reason, or change quantities. The purchase manager marks
  the order placed with the vendor. The store keeper records what was received, with
  shortages. Goods go into the main store or straight to the department, per format.
- The purchase manager pushes the received purchase to Petpooja with one reply ("push 12").

Workflow 2, daily stock count and leakage
- Locations: main store, kitchen, bar, housekeeping. Every issue from store to a department
  is recorded on WhatsApp by the store keeper.
- At a configurable time each counter receives a count sheet (items grouped by category) and
  replies with quantities in parts, or a photo. Housekeeping also gives rooms occupied.
  Missing items and impossible figures (above book stock) are asked again.
- Report at a configurable time to the owner, per department and item:
  actual use = opening count + issued - closing count; expected use = Petpooja
  recipe-based consumption (kitchen, bar) or per-room norm x rooms occupied (housekeeping);
  variance above a configurable tolerance is flagged with its rupee value. For the main store,
  any difference between book stock and the count is a shortage.

Workflow 3, bills, accounts and Tally
- A photo or PDF of a supplier bill is read by Claude (vendor, GSTIN, invoice number and
  date, lines with qty, unit, rate, amount, taxable, CGST, SGST, IGST, total) and matched
  three ways against the requisition and the goods received: quantity, rate tolerance,
  totals, duplicate invoice. Differences go to the purchase manager, who can override with
  a reason. Once pushed to Petpooja, the bill goes to accounts to verify or query.
- Verified bills are posted to Tally as purchase vouchers in TallyPrime XML: either an
  import file behind a signed download link, or a direct HTTP push to TallyPrime.
  Ledger names per item category and GST ledgers are configurable.
- Daily accounts digest on WhatsApp; on request, purchases by department and bills by vendor.

Petpooja
- Put Petpooja behind one interface: push_purchase, get_items, get_expected_consumption.
  A manual adapter (default, no credentials) writes a daily Petpooja-ready CSV. An HTTP
  adapter turns on when PETPOOJA_BASE_URL and PETPOOJA_ACCESS_TOKEN are set, sends app key,
  app secret, access token and the outlet's restID, and reads endpoint paths and response
  field names from config, so matching Petpooja's documentation needs no code change.

Configuration
- config.yaml holds the starting setup (outlets, users, routing, formats, items, count
  times, tolerances, housekeeping norms, Tally ledgers, Petpooja endpoints). Admins can change
  routing, formats, count settings, users and items by chatting with the agent; those
  changes are stored in the database and override the file.

Deliver: the code, requirements.txt, .env.example, Dockerfile, a README with Twilio setup
steps, and pytest tests that run a full day of all three workflows without any external
service (fake WhatsApp sender, scripted fake Claude client).
```
