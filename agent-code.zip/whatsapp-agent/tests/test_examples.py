"""Pramit's two worked examples."""
from datetime import timedelta
from unittest import mock

from app import db, ops, petpooja

CHEF, OWNER, PM, STORE, ACC = "+919800000002", "+919800000001", "+919800000003", "+919800000004", "+919800000005"
COST = "+919800000008"


def u(phone):
    return db.get_user(phone)


class FakePetpooja:
    name = "petpooja_api"

    def __init__(self, consumption=None, payables=None):
        self.consumption = consumption or {}
        self.payables = payables

    def get_expected_consumption(self, outlet, start, end):
        return self.consumption

    def get_vendor_payables(self, outlet, vendor):
        return self.payables

    def push_purchase(self, purchase):
        return "PP-1"

    def get_items(self, outlet):
        return []


def full(loc, **qty):
    return [{"item": i["name"], "qty": qty.get(i["code"], 0)} for i in ops.items_for_location(loc)]


def test_arhar_dal_variance_alert(outbox):
    """10 kg bought, 5 kg issued to kitchen. Next day the kitchen count shows 1.5 kg used,
    Petpooja's recipes say 1.2 kg: the concerned people get the variation."""
    base = db.now().replace(hour=7, minute=30, second=0, microsecond=0)
    day0, day1, day2 = base - timedelta(days=2), base - timedelta(days=1), base
    fake = FakePetpooja(consumption={"ARH001": {"qty": 1.2, "portions": {"Dal Tadka": 24}}})
    with mock.patch.object(db, "now", return_value=day0 + timedelta(hours=4)):
        db.execute("INSERT INTO stock_moves(at,kind,from_loc,to_loc,item_code,qty) VALUES (?,?,?,?,?,?)",
                   (db.now_iso(), "receipt", "supplier", "store", "ARH001", 10))
        ops.record_issue(u(STORE), "kitchen", [{"item": "Arhar dal", "qty": 5}])
    with mock.patch.object(db, "now", return_value=day1), mock.patch.object(petpooja, "adapter", return_value=fake):
        r = ops.submit_count(u(CHEF), "kitchen", full("kitchen", ARH001=5))
        assert r["status"] == "complete" and "First count" in r["note"]
    outbox.clear()
    with mock.patch.object(db, "now", return_value=day2), mock.patch.object(petpooja, "adapter", return_value=fake):
        r = ops.submit_count(u(CHEF), "kitchen", full("kitchen", ARH001=3.5))
    assert r["flagged_items"] == ["Arhar dal"]
    recipients = {p for p, _ in outbox}
    assert recipients == {CHEF, OWNER, PM, COST}    # kitchen alert list + the item's own alert_to
    msg = next(t for p, t in outbox if p == OWNER)
    assert "Arhar dal: counted use 1.5 kg, expected 1.2 kg (Dal Tadka x24). 0.3 kg more, 25%, ₹36." in msg
    assert "3.5 kg left, about 2.3 days" in msg

    # Within its own threshold nothing is sent: raise arhar dal's threshold to 0.5 kg and recheck.
    ops.set_variance_threshold(u(PM), "arhar dal", quantity=0.5)
    with mock.patch.object(db, "now", return_value=day2), mock.patch.object(petpooja, "adapter", return_value=fake):
        assert ops.location_variance("kitchen", day2.strftime("%Y-%m-%d"))["flagged"] == []


def test_vendor_payment_flow(outbox):
    db.execute("INSERT INTO bills(vendor,invoice_no,invoice_date,taxable,total,status) VALUES "
               "('City Liquors','CL-881','2026-10-10',17100,17100,'posted'),"
               "('City Liquors','CL-902','2026-10-13',9000,9450,'verified')")
    # Without Petpooja payables the agent uses its own bill records.
    r = ops.vendor_pending(u(ACC), "city liquor")
    assert r["vendor"] == "City Liquors" and r["pending"] == 26550 and "agent records" in r["source"]

    p = ops.record_payment(u(ACC), "City Liquors", 17100, "NEFT", "UTR123", invoices=["CL-881"])
    assert p["notified"] == ["Asha (Purchase)"]
    assert outbox[-1][0] == PM and "Please record it in Petpooja" in outbox[-1][1] and "UTR123" in outbox[-1][1]
    assert ops.vendor_pending(u(ACC), "City Liquors")["pending"] == 9450
    assert "payments_to_update_in_petpooja" in ops.pending_for(u(PM))

    # With Petpooja connected the pending figure comes from Petpooja.
    fake = FakePetpooja(payables=[{"vendor": "City Liquors", "invoice_no": "CL-881", "invoice_date": "2026-10-10", "amount": 17100, "pending": 17100},
                                  {"vendor": "City Liquors", "invoice_no": "CL-902", "invoice_date": "2026-10-13", "amount": 9450, "pending": 9450}])
    with mock.patch.object(petpooja, "adapter", return_value=fake):
        r = ops.vendor_pending(u(ACC), "City Liquors")
    assert r["source"] == "Petpooja" and r["pending_in_petpooja"] == 26550
    assert r["payments_not_yet_in_petpooja"] == 17100 and r["pending_after_those_payments"] == 9450

    ops.confirm_payment_updated(u(PM), p["payment_id"])
    assert outbox[-1][0] == ACC and "updated in Petpooja" in outbox[-1][1]
    try:
        ops.record_payment(u(PM), "City Liquors", 100, "UPI")
        raise AssertionError("only accounts records payments")
    except ops.OpsError:
        pass
