"""Stock in hand: last count plus moves since."""
from datetime import timedelta
from unittest import mock

import pytest

from app import db, ops

STORE = "+919800000004"


def test_stock_on_hand_after_count_and_issue():
    store = db.get_user(STORE)
    start = db.now().replace(hour=8, minute=0, second=0, microsecond=0) - timedelta(days=1)
    with mock.patch.object(db, "now", return_value=start):
        ops.submit_count(store, "store", [{"item": i["name"], "qty": 8 if i["code"] == "PAN001" else 0}
                                          for i in ops.items_for_location("store")])
    with mock.patch.object(db, "now", return_value=start + timedelta(hours=3)):
        ops.record_issue(store, "kitchen", [{"item": "Paneer", "qty": 2}])
    r = ops.stock_on_hand("paneer")
    row = r["items"][0]
    assert row["item"] == "Paneer" and row["by_department"] == {"store": 6, "kitchen": 2} and row["total"] == 8
    assert r["last_count"]["store"] == start.strftime("%Y-%m-%d") and r["last_count"]["kitchen"] is None
    assert ops.stock_on_hand("arhar dal")["items"][0]["by_department"] == {"store": 0}
    with pytest.raises(ops.OpsError):
        ops.stock_on_hand("gold bars")


def test_admin_sets_opening_stock_and_corrections():
    ops.set_stock("admin panel", "store", [{"item_code": "PAN001", "qty": 2}])
    assert ops.stock_on_hand("paneer")["items"][0]["by_department"] == {"store": 2}
    ops.set_stock("admin panel", "store", [{"item_code": "PAN001", "qty": 1.5}])     # correction down
    assert ops.stock_on_hand("paneer")["items"][0]["total"] == 1.5
    with pytest.raises(ops.OpsError):
        ops.set_stock("admin panel", "roof", [{"item_code": "PAN001", "qty": 1}])
    with pytest.raises(ops.OpsError):
        ops.set_stock("admin panel", "store", [{"item_code": "PAN001", "qty": None}])
