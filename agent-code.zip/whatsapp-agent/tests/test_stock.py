"""Pramit's example: 10 kg chicken sent to the kitchen, 8 kg counted next day = 2 kg actual use,
compared with Petpooja sales x recipes; the Excel report goes to the configured emails."""
import io
from datetime import datetime
from unittest import mock

import pytest
from openpyxl import load_workbook

from app import db, report, sales, scheduler, stock
from tests.conftest import ADMIN, KEEPER, MANAGER
from app.tools import run_tool


def at(y, mo, d, h, mi=0):
    return mock.patch.object(db, "now", return_value=datetime(y, mo, d, h, mi, tzinfo=db.tz()))


def bill(order_id, items, created, status="Success"):
    return {"event": "orderdetails", "properties": {
        "Restaurant": {"restID": "r1"}, "Order": {"orderID": order_id, "status": status, "total": 900, "created_on": created},
        "OrderItem": [{"name": n, "itemcode": "", "itemid": 1, "quantity": q, "addon": []} for n, q in items]}}


def full_count(**q):
    return [{"item": i["name"], "qty": q.get(i["code"], 0)} for i in stock.count_list()]


def test_daily_flow_actual_vs_ideal_and_email(outbox, mailbox):
    keeper = db.get_user(KEEPER)
    db.put("report_emails", ["owner@example.com", "chef@example.com"])
    sales.save_recipes([{"dish": "Chicken Curry", "item_code": "Chicken", "qty": 0.2},
                        {"dish": "Chicken Curry", "item_code": "OIL", "qty": 0.02},
                        {"dish": "Dal Tadka", "item_code": "ARH", "qty": 0.08}])
    # Day 1: first count is the opening stock (nothing in the kitchen yet).
    with at(2026, 10, 20, 9, 30):
        r = stock.submit_count(keeper, [{"item": "chicken", "qty": 0}], finished=True)
        assert r["status"] == "in_progress" and "Arhar dal (kg)" in r["still_missing"]
        r = stock.submit_count(keeper, full_count(), finished=True)
        assert r["status"] == "complete"
    with at(2026, 10, 20, 11, 0):
        assert stock.record_issue("Ramesh", [{"item": "Chicken", "qty": 10}, {"item": "arhar", "qty": 3}])["saved"]
    sales.record_order(bill(1, [("Chicken Curry", 7), ("Dal Tadka", 25)], "2026-10-20 13:00:00"))
    sales.record_order(bill(2, [("Chicken Curry", 3)], "2026-10-20 20:00:00", status="Cancelled"))
    sales.record_order(bill(3, [("Paneer Tikka", 4)], "2026-10-20 21:00:00"))
    # Day 2 at 09:40: 8 kg chicken left -> actual 2 kg; ideal 7 x 0.2 = 1.4 kg.
    with at(2026, 10, 21, 9, 40):
        r = run_tool("save_count", {"lines": full_count(CHK=8, ARH=0.8, OIL=0), "finished": True}, keeper)
    assert r["status"] == "complete" and r["report"] == "will be emailed at 11:00" and not mailbox
    rep = stock.variance("2026-10-21")
    chk = next(x for x in rep["rows"] if x["item"] == "Chicken")
    assert (chk["opening"], chk["issued"], chk["closing"], chk["actual"], chk["ideal"]) == (0, 10, 8, 2, 1.4)
    assert chk["variance"] == 0.6 and chk["variance_amount"] == 150
    dal = next(x for x in rep["rows"] if x["item"] == "Arhar dal")
    assert dal["actual"] == 2.2 and dal["ideal"] == 2.0
    assert "Sugar" not in [x["item"] for x in rep["rows"]]      # not on the daily count list
    # 11:00 tick emails the Excel once.
    assert "report" in scheduler.tick(datetime(2026, 10, 21, 11, 0, tzinfo=db.tz()))
    assert scheduler.tick(datetime(2026, 10, 21, 11, 1, tzinfo=db.tz())) == []
    mail = mailbox[0]
    assert mail["to"] == ["owner@example.com", "chef@example.com"] and mail["name"] == "kitchen-variance-2026-10-21.xlsx"
    ws = load_workbook(io.BytesIO(mail["data"]))["Variance"]
    rows = [[c.value for c in r] for r in ws.iter_rows()]
    header = next(r for r in rows if r[0] == "Item")
    assert header[5:8] == ["Actual consumption", "Ideal consumption", "Variance qty"] and header[9] == "Variance amount (Rs)"
    assert next(r for r in rows if r[0] == "Chicken")[5:10] == [2, 1.4, 0.6, 250, 150]
    dishes = [[c.value for c in r] for r in load_workbook(io.BytesIO(mail["data"]))["Dishes sold"].iter_rows()]
    assert ["Paneer Tikka", 4, "NO, add it in the admin panel"] in dishes


def test_report_goes_when_count_finishes_after_report_time(mailbox):
    keeper = db.get_user(KEEPER)
    db.put("report_emails", ["owner@example.com"])
    with at(2026, 10, 20, 9, 0):
        stock.submit_count(keeper, full_count(CHK=5), finished=True)
    with at(2026, 10, 21, 12, 15):
        r = run_tool("save_count", {"lines": full_count(CHK=4), "finished": True}, keeper)
    assert r["report"] == "emailed to owner@example.com" and len(mailbox) == 1


def test_scheduler_sends_list_and_late_alert(outbox):
    db.execute("INSERT INTO count_days(count_date,status) VALUES ('2026-10-21','in_progress')")
    ran = scheduler.tick(datetime(2026, 10, 21, 9, 0, tzinfo=db.tz()))
    assert ran == ["count_list"] and outbox[0][0] == KEEPER and "Chicken (kg)" in outbox[0][1] and "Sugar" not in outbox[0][1]
    outbox.clear()
    with at(2026, 10, 21, 10, 5):
        assert scheduler.tick(datetime(2026, 10, 21, 10, 5, tzinfo=db.tz())) == ["count_late"]
    assert {p for p, _ in outbox} == {KEEPER, ADMIN}


def test_permissions_and_item_matching():
    manager = db.get_user(MANAGER)
    with pytest.raises(stock.StockError, match="cannot"):
        stock.submit_count(manager, [])
    assert "error" in run_tool("record_issue", {"lines": [{"item": "Chicken", "qty": 1}]}, manager)
    keeper = db.get_user(KEEPER)
    r = stock.submit_count(keeper, [{"item": "gold", "qty": 1}])
    assert r["problems"] == ["gold: not in the item list"]
    assert stock.kitchen_stock("chicken")["rows"][0]["in_kitchen"] == 0


def test_email_failure_tells_admin(outbox):
    keeper = db.get_user(KEEPER)
    with at(2026, 10, 20, 9, 0):
        stock.submit_count(keeper, full_count(), finished=True)
    r = report.email_report("2026-10-20", to=["x@example.com"])
    assert r["status"] == "failed" and "BREVO_API_KEY" in r["error"]
    assert outbox and outbox[0][0] == ADMIN
