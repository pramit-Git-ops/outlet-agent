"""A full day: requisition -> approval -> order -> receipt -> bill -> Petpooja ->
accounts -> Tally, plus issues, two morning counts and the leakage report."""
import json
from datetime import timedelta
from unittest import mock

from app import db, ops, tally

CHEF, OWNER, PM, STORE, ACC, BAR, HK = (
    "+919800000002", "+919800000001", "+919800000003", "+919800000004",
    "+919800000005", "+919800000006", "+919800000007")


def u(phone):
    return db.get_user(phone)


def test_requisition_to_tally(outbox):
    # Missing required field -> not created, agent must ask.
    r = ops.create_requisition(u(BAR), "bar", "liquor", [{"item": "whisky", "qty": 12}], {"needed_by": "2026-10-16"})
    assert r["created"] is False and r["missing_fields"] == ["brand_and_bottle_size"]

    r = ops.create_requisition(u(BAR), "bar", "liquor", [{"item": "Whisky 750ml", "qty": 12}],
                               {"needed_by": "2026-10-16", "brand_and_bottle_size": "House whisky 750ml"})
    assert r["created"] and r["status"] == "pending_approval" and r["routed_by_rule"] == "Bar liquor"
    rid = r["requisition_id"]
    assert outbox[-1][0] == OWNER and "Approval needed" in outbox[-1][1]

    # Wrong person cannot approve.
    try:
        ops.decide_requisition(u(CHEF), rid, "approve")
        raise AssertionError("chef should not approve bar request")
    except ops.OpsError:
        pass
    r = ops.decide_requisition(u(OWNER), rid, "approve", quantity_changes=[{"item": "Whisky 750ml", "qty": 10}])
    assert r["status"] == "approved"
    assert any(p == PM and "please order" in t for p, t in outbox)

    ops.mark_ordered(u(PM), rid, "City Liquors", "tomorrow 11am")
    r = ops.record_receipt(u(STORE), rid, [{"item": "Whisky 750ml", "qty": 9}])
    assert r["short"] and r["received_into"] == "store"

    # Bill with a rate above tolerance -> mismatch, then override.
    b = ops.record_bill(u(STORE), "City Liquors", "CL-881", "2026-10-15",
                        [{"item": "Whisky 750ml", "qty": 9, "rate": 1900}], taxable=17100, total=17100)
    assert b["status"] == "mismatch" and any("rate" in d for d in b["differences"])
    assert b["summary"].startswith(f"Bill #{b['bill_id']}")
    ops.override_bill(u(PM), b["bill_id"], "New price list from October")

    # Duplicate invoice is refused.
    try:
        ops.record_bill(u(STORE), "City Liquors", "CL-881", "2026-10-15", [{"item": "Whisky 750ml", "qty": 9, "rate": 1900}], 17100, 17100)
        raise AssertionError("duplicate accepted")
    except ops.OpsError:
        pass

    p = ops.push_to_petpooja(u(PM), bill_id=b["bill_id"])
    assert p["mode"] == "manual" and p["petpooja_ref"].startswith("MANUAL-")
    assert any(ph == ACC and "Bill ready to verify" in t for ph, t in outbox)
    assert db.get_user(ACC)
    assert db.query_one("SELECT rate FROM items WHERE code='WHI001'")["rate"] == 1900

    ops.accounts_review(u(ACC), b["bill_id"], "verified")
    t = ops.tally_post(u(ACC))
    assert t["exported"] and "/exports/" in t["download_link"]
    xml = (db.query_one("SELECT * FROM bills WHERE id=?", (b["bill_id"],)))
    assert xml["tally_status"] == "exported"


def test_tally_voucher_balances():
    db.execute("INSERT INTO bills(id,vendor,invoice_no,invoice_date,taxable,cgst,sgst,total,lines_json,status) "
               "VALUES (1,'Fresh Farms','FF-1','2026-10-15',1000,25,25,1050,?, 'verified')",
               (json.dumps([{"item_code": "PAN001", "item_name": "Paneer", "qty": 2, "rate": 350, "amount": 700},
                            {"item_code": "SOP001", "item_name": "Guest soap", "qty": 25, "rate": 12, "amount": 300}]),))
    x = tally.voucher_xml(db.query_one("SELECT * FROM bills WHERE id=1"))
    import re
    amounts = [float(a) for a in re.findall(r"<AMOUNT>(-?[\d.]+)</AMOUNT>", x)]
    assert abs(sum(amounts)) < 0.005, amounts
    assert "Purchase - Housekeeping" in x and "Input CGST" in x and "<DATE>20261015</DATE>" in x


def test_daily_counts_and_leakage(outbox):
    base = db.now().replace(hour=7, minute=30, second=0, microsecond=0)
    day1, day2 = base - timedelta(days=1), base

    def full(loc, **qty):
        return [{"item": i["name"], "qty": qty.get(i["code"], 0)} for i in ops.items_for_location(loc)]

    def at(t):
        return mock.patch.object(db, "now", return_value=t)

    # Day 1: store receives and issues; everyone does the first count.
    with at(day1 - timedelta(hours=2)):
        db.execute("INSERT INTO stock_moves(at,kind,from_loc,to_loc,item_code,qty) VALUES (?,?,?,?,?,?)",
                   (db.now_iso(), "receipt", "supplier", "store", "PAN001", 10))
        ops.record_issue(u(STORE), "kitchen", [{"item": "Paneer", "qty": 2}])
        ops.record_issue(u(STORE), "housekeeping", [{"item": "Guest soap", "qty": 40}])
    with at(day1):
        ops.submit_count(u(STORE), "store", full("store", PAN001=8))
        ops.submit_count(u(CHEF), "kitchen", full("kitchen", PAN001=2))
        r = ops.submit_count(u(HK), "housekeeping", full("housekeeping", SOP001=40))
        assert r["rooms_occupied_needed"] and r["status"] == "in_progress"
        r = ops.submit_count(u(HK), "housekeeping", [], rooms_occupied=10)
        assert r["status"] == "complete"
    # During the day: 5 kg more paneer issued, 30 soaps used for 10 rooms (norm 2/room = 20).
    with at(day1 + timedelta(hours=5)):
        ops.record_issue(u(STORE), "kitchen", [{"item": "Paneer", "qty": 5}])
    # Day 2 morning counts.
    with at(day2):
        r = ops.submit_count(u(STORE), "store", [{"item": "Paneer", "qty": 2.5}], final=False)
        assert r["status"] == "in_progress" and r["still_missing"]
        ops.submit_count(u(STORE), "store", [{"item": i["name"], "qty": 0} for i in ops.items_for_location("store") if i["code"] != "PAN001"])
        ops.submit_count(u(CHEF), "kitchen", full("kitchen", PAN001=1.5))
        ops.submit_count(u(HK), "housekeeping", full("housekeeping", SOP001=10), rooms_occupied=10)
        rep = ops.consumption_report()
    k = {r["item"]: r for r in rep["locations"]["kitchen"]["rows"]}
    assert k["Paneer"]["actual_used"] == 5.5                     # 2 + 5 - 1.5
    s = {r["item"]: r for r in rep["locations"]["store"]["rows"]}
    assert s["Paneer"]["variance"] == 0.5                         # 8 - 5 issued - 2.5 counted
    h = rep["locations"]["housekeeping"]
    flagged = {r["item"]: r for r in h["flagged"]}
    assert flagged["Guest soap"]["variance"] == 10               # 30 used vs 2 x 10 rooms
    assert flagged["Shampoo sachet"]["variance"] == -20          # none used vs 20 expected: also flagged
    assert h["leakage_value"] == 120
    text = ops.report_text(rep)
    assert "Housekeeping: leakage ₹120" in text


def test_escalation(outbox):
    r = ops.create_requisition(u(HK), "housekeeping", "supplies", [{"item": "Bath towel", "qty": 4}], {"needed_by": "2026-10-20"})
    later = db.now() + timedelta(hours=5)
    with mock.patch.object(db, "now", return_value=later):
        assert ops.chase_overdue() >= 1
    assert any(p == OWNER and "Escalation" in t for p, t in outbox)


def test_admin_changes_routing():
    rules = ops.get_settings("routing")["routing"]
    rules.insert(0, {"name": "Bar over 5000", "match": {"department": "bar", "min_value": 5000},
                     "approvers": [OWNER], "then_notify": [PM]})
    try:
        ops.update_settings(u(CHEF), "routing", json.dumps(rules))
        raise AssertionError("chef is not admin")
    except ops.OpsError:
        pass
    ops.update_settings(u(OWNER), "routing", json.dumps(rules))
    assert ops.match_rule("bar", "anything", 6000, False)["name"] == "Bar over 5000"


def test_setup_check_and_reseed(monkeypatch):
    from app import db, main
    from app.settings import settings

    checks = main.health()
    assert checks["setup"]["team_phone_numbers"].startswith("8 sample numbers")

    # Owner replaces a sample number in config.yaml and redeploys.
    users = [dict(u) for u in settings.config["users"]]
    users[0] = {**users[0], "phone": "+919811112222"}
    monkeypatch.setitem(settings.config, "users", users)
    db.seed_from_config()
    assert db.get_user("+919811112222")["name"] == "Pramit"
    assert db.get_user("+919800000001") is None
    assert main.health()["setup"]["team_phone_numbers"].startswith("7 sample numbers")
