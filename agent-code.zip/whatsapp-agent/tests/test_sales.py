"""Petpooja Global API sales webhook, recipes and recipe-based expected use."""
import pytest
from fastapi.testclient import TestClient

from app import db, ops, sales
from app.main import app
from app.settings import settings

KITCHEN = "+919800000002"


def bill(order_id, items, status="Success", created="2026-10-19 13:00:00", token=""):
    return {"token": token, "event": "orderdetails", "properties": {
        "Restaurant": {"res_name": "Demo", "restID": "cp81ghin"},
        "Order": {"orderID": order_id, "status": status, "total": 500, "created_on": created, "order_from": "POS"},
        "OrderItem": items}}


def dish(name, qty=1, code="", addons=()):
    return {"name": name, "itemcode": code, "itemid": 1, "quantity": qty, "price": 100, "total": 100 * qty,
            "addon": [{"name": a, "quantity": "2", "addon_id": "9"} for a in addons]}


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(settings, "run_scheduler", False)
    with TestClient(app) as c:
        yield c


def test_webhook_needs_token_and_stores_bills(client):
    url = "/petpooja/orders/" + sales.webhook_token()
    assert client.post("/petpooja/orders/wrong", json=bill(1, [dish("Dal Tadka")])).status_code == 403
    # Petpooja may put the token in the body instead of the address.
    assert client.post("/petpooja/orders/x", json=bill(1, [dish("Dal Tadka")], token=sales.webhook_token())).status_code == 200
    r = client.post(url, json=bill(2, [dish("Dal Tadka", 2, addons=["Garlic Sauce"]), dish("Jeera Rice")]))
    assert r.json()["lines"] == 3
    client.post(url, json=bill(2, [dish("Dal Tadka", 2)], status="Cancelled"))   # resent as cancelled
    s = sales.sales_summary("2026-10-19")
    assert s["bills"] == 1 and s["cancelled"] == 1 and s["top_dishes"][0] == {"dish": "Dal Tadka", "qty": 1}
    assert "petpooja_sales_webhook" in client.get("/health").json()["setup"]


def test_recipes_validate_and_drive_expected_use(client):
    with pytest.raises(sales.SalesError, match="not in the Items list"):
        sales.save_recipes([{"dish": "Dal Tadka", "item_code": "Gold", "qty": 1}])
    sales.save_recipes([
        {"dish": "Dal Tadka", "item_code": "Arhar dal", "qty": 0.1, "location": "kitchen"},
        {"dish": "dal tadka", "item_code": "OIL001", "qty": 0.01},
        {"dish": "JR1", "item_code": "RIC001", "qty": 0.15},          # matched by Petpooja item code
    ])
    for i, d in enumerate([dish("Dal Tadka", 3), dish("Jeera Rice", 2, code="JR1"), dish("Paneer Tikka")]):
        sales.record_order(bill(10 + i, [d]))
    exp = sales.expected_use("kitchen", "2026-10-19T09:00:00+05:30", "2026-10-20T09:00:00+05:30")
    assert exp["ARH001"]["qty"] == pytest.approx(0.3) and exp["ARH001"]["portions"] == {"Dal Tadka": 3}
    assert exp["RIC001"]["qty"] == pytest.approx(0.3)
    assert "ARH001" not in sales.expected_use("bar", "2026-10-19T09:00:00", "2026-10-20T09:00:00")
    # Outside the window nothing is expected, but recipe items are still compared (at zero).
    assert sales.expected_use("kitchen", "2026-10-20T09:00:00", "2026-10-21T09:00:00")["ARH001"]["qty"] == 0
    assert sales.dishes_without_recipe(days=10000)[0]["dish"] == "Paneer Tikka"


def test_count_compares_with_sales_times_recipes(outbox):
    sales.save_recipes([{"dish": "Dal Tadka", "item_code": "ARH001", "qty": 0.1}])
    kitchen = db.get_user(KITCHEN)
    full = lambda **q: [{"item": i["name"], "qty": q.get(i["code"], 0)} for i in ops.items_for_location("kitchen")]  # noqa: E731
    from datetime import datetime
    from unittest import mock
    tz = db.tz()
    day1, day2 = datetime(2026, 10, 19, 8, 0, tzinfo=tz), datetime(2026, 10, 20, 8, 0, tzinfo=tz)
    with mock.patch.object(db, "now", return_value=day1):
        ops.submit_count(kitchen, "kitchen", full(ARH001=5))
    sales.record_order(bill(20, [dish("Dal Tadka", 10)], created="2026-10-19 13:00:00"))
    with mock.patch.object(db, "now", return_value=day2):
        ops.submit_count(kitchen, "kitchen", full(ARH001=3))
        data = ops.location_variance("kitchen", "2026-10-20")
    row = next(x for x in data["rows"] if x["code"] == "ARH001")
    assert row["actual_used"] == 2 and row["expected"] == 1 and row["portions"] == {"Dal Tadka": 10}
    assert row in data["flagged"]
    assert any("Dal Tadka x10" in t for _, t in outbox)
