"""Admin panel, Petpooja webhook, the Claude loop, and copying people from the old agent."""
import sqlite3
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app import agent, db, sales
from app.main import app
from app.settings import settings
from tests.conftest import ADMIN, KEEPER

H = {"X-Admin-Request": "1"}


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(settings, "admin_password", "pw-12345")
    with TestClient(app) as c:
        assert c.post("/admin/login", data={"password": "pw-12345"}, follow_redirects=False).status_code == 303
        yield c


def test_admin_people_items_settings(client, mailbox):
    s = client.get("/admin/api/state").json()
    assert s["today"]["status"] == "not started" and s["today"]["items"] == 3
    people = [{**u, "original_phone": u["phone"]} for u in s["users"]]
    assert client.post("/admin/api/people", json={"people": people}).status_code == 403      # header missing
    bad = [{**p, "roles": []} for p in people]
    assert "administrator" in client.post("/admin/api/people", json={"people": bad}, headers=H).json()["error"]
    people.append({"name": "Sita", "phone": "12345", "roles": ["stock_keeper"], "active": True})
    r = client.post("/admin/api/people", json={"people": people}, headers=H)
    assert r.status_code == 400 and "not a WhatsApp number" in r.json()["error"]
    people[-1]["phone"] = "98444 44444"          # Indian mobile without +91
    assert client.post("/admin/api/people", json={"people": people}, headers=H).status_code == 200
    assert db.get_user("+919844444444")["roles"] == ["stock_keeper"]

    items = s["items"] + [{"name": "Paneer", "unit": "kg", "rate": 340, "count_daily": True, "code": ""}]
    r = client.post("/admin/api/items", json={"items": items}, headers=H).json()
    assert any(i["code"] == "PANEER" and i["count_daily"] for i in r["items"])

    v = {**s["settings"], "report_emails": ["owner@example.com", "nope"]}
    assert "Not an email" in client.post("/admin/api/settings", json={"settings": v}, headers=H).json()["error"]
    v["report_emails"], v["report_at"] = ["owner@example.com"], "25:00"
    assert "time" in client.post("/admin/api/settings", json={"settings": v}, headers=H).json()["error"]
    v["report_at"] = "10:30"
    assert client.post("/admin/api/settings", json={"settings": v}, headers=H).json()["settings"]["report_at"] == "10:30"
    assert client.post("/admin/api/test-email", json={}, headers=H).json() == {"ok": True}
    assert mailbox[0]["to"] == ["owner@example.com"]


def test_admin_issues_recipes_and_report_download(client):
    r = client.post("/admin/api/issues", json={"lines": [{"item_code": "CHK", "qty": 10}]}, headers=H).json()
    assert r["issues"][0]["item"] == "Chicken" and r["issues"][0]["entered_by"] == "admin panel"
    r = client.post("/admin/api/recipes", json={"recipes": [{"dish": "Dal", "item_code": "Gold", "qty": 1}]}, headers=H)
    assert "not in the Items list" in r.json()["error"]
    r = client.post("/admin/api/recipes", json={"recipes": [{"dish": "Dal", "item_code": "Arhar dal", "qty": 0.08}]}, headers=H)
    assert r.json()["recipes"][0]["item_code"] == "ARH"
    # Items used in records cannot be deleted.
    r = client.post("/admin/api/items", json={"items": [{"name": "Sugar", "unit": "kg", "code": "SUG"}]}, headers=H)
    assert "cannot be removed" in r.json()["error"] and "Chicken" in r.json()["error"]
    assert client.get("/admin/api/report.xlsx?date=2026-01-01").status_code == 404
    page = client.get("/admin").text
    assert "Kitchen stock agent" in page and "Items to count" in page


def test_petpooja_webhook(client):
    body = {"event": "orderdetails", "properties": {"Restaurant": {"restID": "r1"},
            "Order": {"orderID": 5, "status": "Success", "total": 300, "created_on": "2026-10-20 13:00:00"},
            "OrderItem": [{"name": "Dal", "itemcode": "", "itemid": 9, "quantity": 2, "addon": []}]}}
    assert client.post("/petpooja/orders/wrong", json=body).status_code == 403
    assert client.post("/petpooja/orders/" + sales.webhook_token(), json=body).json()["lines"] == 1
    assert client.get("/health").json()["setup"]["petpooja_bills"] == "1 received"


class Block(SimpleNamespace):
    def model_dump(self, **_):
        return {k: v for k, v in vars(self).items() if v is not None}


def test_agent_saves_count_through_tools(outbox):
    calls = []
    script = [SimpleNamespace(stop_reason="tool_use", content=[Block(type="tool_use", id="t1", name="save_count",
                              input={"lines": [{"item": "chicken", "qty": 8}], "finished": False})]),
              SimpleNamespace(stop_reason="end_turn", content=[Block(type="text", text="Saved chicken 8 kg. Still need: Arhar dal, Refined oil.")])]

    class Msgs:
        def create(self, **kw):
            calls.append(kw)
            return script.pop(0)
    agent.set_client(SimpleNamespace(beta=SimpleNamespace(messages=Msgs())))
    db.put("house_rules", "Reply in Hindi.")
    reply = agent.handle_message(KEEPER, "chicken 8 kg")
    assert "Still need" in reply and db.query_one("SELECT qty FROM counts WHERE item_code='CHK'")["qty"] == 8
    assert "Reply in Hindi." in calls[0]["system"][-1]["text"] and "roles: stock_keeper" in calls[0]["messages"][0]["content"][0]["text"]
    assert "not registered" in agent.handle_message("+910000000000", "hi")


def test_people_and_items_copied_from_old_agent():
    old = sqlite3.connect(settings.old_database_path)
    old.executescript("CREATE TABLE users(phone, name, roles, department, outlet, active);"
                      "CREATE TABLE items(code, name, unit, category, rate, petpooja_code);"
                      "INSERT INTO users VALUES ('+917340396453','Pramit','admin,approver',NULL,'MAIN',1),"
                      "('+919800000004','Mohan','store_keeper',NULL,'MAIN',1),('+919900000000','Nishchay','purchase_manager',NULL,'MAIN',1);"
                      "INSERT INTO items VALUES ('PAN001','Paneer','kg','dairy',350,NULL);")
    old.commit()
    old.close()
    db.reset_connection()
    import os
    os.unlink(settings.database_path)
    db.init_db()
    assert db.get_user("+917340396453")["roles"] == ["admin", "manager"]
    assert db.get_user("+919900000000")["roles"] == ["manager"]
    assert db.get_user("+919800000004") is None                      # sample numbers are not copied
    assert db.query_one("SELECT count_daily FROM items WHERE code='PAN001'")["count_daily"] == 0
