"""Petpooja Inventory API: transfers become stock sent to the kitchen, Petpooja's consumption is the
ideal use, purchases set the rates. Responses are shaped like the examples in Inventory_APIs 3.1."""
import io
from datetime import datetime
from unittest import mock

import pytest
from openpyxl import load_workbook

from app import db, petpooja, report, stock
from app.settings import settings
from tests.conftest import KEEPER


def at(y, mo, d, h, mi=0):
    return mock.patch.object(db, "now", return_value=datetime(y, mo, d, h, mi, tzinfo=db.tz()))


def transfer(sale_id, receiver, lines, created="2026-10-20 11:00:00", status="Active"):
    return {"sale_id": sale_id, "type": "Transfer", "invoice_number": f"TR{sale_id}", "created_on": created,
            "action_status": status, "restaurant_details": {"receiver": {"receiver_name": receiver}},
            "item_details": [{"item_id": str(i), "itemname": n, "qty": q, "lbl_unit": u, "sap_code": ""}
                             for i, (n, q, u) in enumerate(lines)]}


class FakePetpooja:
    def __init__(self):
        self.calls = []
        self.transfers = [transfer("501", "Main Kitchen", [("Chicken", 10, "Kgs."), ("Arhar Dal", 3000, "gm")]),
                          transfer("502", "Bar", [("Chicken", 5, "Kgs.")])]
        self.orders = {"2026-10-20": [
            self.order("1641", "Success", "2026-10-20 13:00:00", "Chicken Curry", 7,
                       [("Chicken", 1400, "gm", ""), ("Refined Oil", 140, "ml", ""), ("Butter", 100, "gm", "123123")]),
            self.order("1642", "Cancelled", "2026-10-20 20:00:00", "Chicken Curry", 3, [("Chicken", 600, "gm", "")]),
            self.order("1643", "Success", "2026-10-20 21:00:00", "Jeera Soda", 2, []),
        ]}

    @staticmethod
    def order(oid, status, created, dish, qty, consumed):
        return {"Restaurant": {"restID": "enhfbqyt"}, "Order": {"orderID": oid, "status": status, "created_on": created},
                "OrderItem": [{"name": dish, "quantity": str(qty), "addon": [],
                               "consumed": [{"rawmaterialname": n, "rawmaterialquantity": q, "unitname": u, "rawmaterialsapcode": c}
                                            for n, q, u, c in consumed]}]}

    def __call__(self, endpoint, body):
        self.calls.append((endpoint, body))
        assert body["app_key"] == "key" and body["menuSharingCode"] == "msc"
        if endpoint == "get_orders_api/":
            return {"success": "1", "order_json": self.orders.get(body["order_date"], [])}
        if endpoint == "get_sales/":
            assert body["slType"] == "transfer" and len(body["from_date"]) == 10 and body["from_date"][2] == "-"
            return {"success": "1", "sales": self.transfers}
        if endpoint == "get_purchase/":
            return {"success": "1", "purchases": [
                {"purchase_id": "9", "action_status": "Active", "created_on": "2026-10-19 10:00:00",
                 "item_details": [{"itemname": "Chicken", "lbl_unit": "Kgs.", "price": 240, "weighted_price": 260},
                                  {"itemname": "Arhar Dal", "lbl_unit": "gm", "price": 0.12, "weighted_price": 0.13}]},
                {"purchase_id": "10", "action_status": "Active", "created_on": "2026-10-20 10:00:00",
                 "item_details": [{"itemname": "Chicken", "lbl_unit": "Kgs.", "price": 270, "weighted_price": 280}]}]}
        if endpoint == "get_stock_api/":
            return {"success": "1", "closing_json": [
                {"name": "Chicken", "price": 280, "unit": "Kgs.", "qty": "25", "category": "Meat", "sapcode": ""},
                {"name": "Butter", "price": 0.5, "unit": "gm", "qty": "4000", "category": "Dairy", "sapcode": "123123"}]}
        raise AssertionError(endpoint)


@pytest.fixture
def fake(monkeypatch):
    for k, v in (("petpooja_app_key", "key"), ("petpooja_app_secret", "secret"),
                 ("petpooja_access_token", "token"), ("petpooja_menu_sharing_code", "msc")):
        monkeypatch.setattr(settings, k, v)
    f = FakePetpooja()
    petpooja.post_hook = f
    yield f
    petpooja.post_hook = None


def full_count(**q):
    return [{"item": i["name"], "qty": q.get(i["code"], 0)} for i in stock.count_list()]


def test_units():
    assert petpooja.convert(1400, "gm", "kg") == 1.4
    assert petpooja.convert(2, "Kgs.", "kg") == 2
    assert petpooja.convert(140, "ml", "litre") == pytest.approx(0.14)
    assert petpooja.convert(3, "pcs", "Nos") == 3
    assert petpooja.convert(1, "kg", "litre") is None


def test_transfers_consumption_and_rates_drive_the_variance(fake, mailbox):
    keeper = db.get_user(KEEPER)
    db.put("kitchen_receiver", "kitchen")
    db.put("report_emails", ["owner@example.com"])
    with at(2026, 10, 20, 9, 30):
        assert stock.submit_count(keeper, full_count(), finished=True)["status"] == "complete"
    with at(2026, 10, 21, 9, 40):
        r = stock.submit_count(keeper, full_count(CHK=8, ARH=0.8), finished=True)
    assert r["status"] == "complete"

    # Only the transfer to the kitchen came in, in our units, once.
    issues = db.query("SELECT item_code, qty, entered_by FROM issues ORDER BY item_code")
    assert issues == [{"item_code": "ARH", "qty": 3.0, "entered_by": "Petpooja"},
                      {"item_code": "CHK", "qty": 10.0, "entered_by": "Petpooja"}]
    rep = stock.variance("2026-10-21")
    assert rep["ideal_source"] == "Petpooja recipes"
    chk = next(x for x in rep["rows"] if x["item"] == "Chicken")
    # Actual 0 + 10 - 8 = 2 kg; Petpooja consumed 1.4 kg on successful bills; rate from the latest purchase.
    assert (chk["actual"], chk["ideal"], chk["variance"], chk["rate"]) == (2, 1.4, 0.6, 280)
    assert chk["variance_amount"] == 168
    oil = next(x for x in rep["rows"] if x["item"] == "Refined oil")
    assert oil["ideal"] == pytest.approx(0.14)
    dal = next(x for x in rep["rows"] if x["item"] == "Arhar dal")
    assert dal["actual"] == 2.2 and dal["rate"] == 130
    assert rep["not_matched"] == ["Butter"]
    assert {d["dish"]: d["has_recipe"] for d in rep["dishes_sold"]} == {"Chicken Curry": True, "Jeera Soda": False}

    # A transfer cancelled in Petpooja disappears on the next fetch.
    fake.transfers[0]["action_status"] = "Inactive"
    with at(2026, 10, 21, 10, 0):
        petpooja.sync()
    assert db.query("SELECT COUNT(*) AS n FROM issues")[0]["n"] == 0

    data, _ = report.build_excel("2026-10-20")
    assert "Petpooja store stock" in load_workbook(io.BytesIO(data)).sheetnames


def test_failure_is_reported_and_other_parts_still_run(fake):
    def broken(endpoint, body):
        if endpoint == "get_purchase/":
            return {"success": "0", "message": "Invalid access token"}
        return fake(endpoint, body)
    petpooja.post_hook = broken
    with at(2026, 10, 21, 10, 0):
        result = petpooja.sync()
    assert result["errors"] == ["purchase rates: Petpooja said: Invalid access token"]
    assert result["transfers to kitchen"] == 3 and result["store stock"] == 2


def test_paging_uses_last_id(fake):
    pages = {"": [{"sale_id": str(i)} for i in range(50)], "49": [{"sale_id": "50"}]}
    petpooja.post_hook = lambda e, b: {"success": "1", "sales": pages[b["refId"]]}
    rows = petpooja._paged("get_sales/", {}, "sales", lambda s: s["sale_id"])
    assert len(rows) == 51


def test_import_items_from_petpooja_stock(fake):
    with at(2026, 10, 21, 10, 0):
        petpooja.sync()
    assert petpooja.import_items() == 1
    butter = db.query_one("SELECT * FROM items WHERE name='Butter'")
    assert butter["sap_code"] == "123123" and butter["count_daily"] == 0
    assert petpooja.import_items() == 0
