"""The Claude loop and the Twilio webhook, with a scripted fake Claude."""
from types import SimpleNamespace

from fastapi.testclient import TestClient

from app import agent, db


class Block(SimpleNamespace):
    def model_dump(self, **_):
        return {k: v for k, v in vars(self).items() if v is not None}


class FakeMessages:
    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def create(self, **kwargs):
        import copy
        self.calls.append(copy.deepcopy(kwargs))
        return self.script.pop(0)


class FakeClient:
    def __init__(self, script):
        self.beta = SimpleNamespace(messages=FakeMessages(script))


def resp(stop, *blocks):
    return SimpleNamespace(stop_reason=stop, content=list(blocks))


def test_agent_creates_requisition_via_tools(outbox):
    fake = FakeClient([
        resp("tool_use",
             Block(type="thinking", thinking="", signature="sig"),
             Block(type="tool_use", id="t1", name="create_requisition", input={
                 "department": "kitchen", "request_type": "perishables",
                 "lines": [{"item": "paneer", "qty": 5}, {"item": "tomato", "qty": 10}],
                 "fields": {"needed_by": "2026-10-16 08:00"}})),
        resp("end_turn", Block(type="text", text="Done! Requisition #1 created and sent to Asha (Purchase).")),
    ])
    agent.set_client(fake)
    reply = agent.handle_message("+919800000002", "5 kg paneer and 10 kg tomato for tomorrow 8am, yes go ahead")
    assert "#1" in reply
    req = db.query_one("SELECT * FROM requisitions WHERE id=1")
    assert req["status"] == "approved" and req["receive_into"] == "kitchen"
    first = fake.beta.messages.calls[0]
    assert first["model"] == "claude-opus-5-5" and first["fallbacks"] == "default"
    assert first["thinking"] == {"type": "adaptive"} and "<sender>" in first["messages"][0]["content"][0]["text"]
    second = fake.beta.messages.calls[1]["messages"]
    assert second[-1]["content"][0]["type"] == "tool_result"
    assert second[-2]["content"][0]["type"] == "thinking"   # history passed back unchanged
    # History persisted for the next message.
    assert len(agent._load_history("+919800000002")) == 4


def test_unknown_number():
    assert "not registered" in agent.handle_message("+910000000000", "hi")


def test_webhook_replies_in_background(outbox):
    agent.set_client(FakeClient([resp("end_turn", Block(type="text", text="Nothing pending."))]))
    from app.main import app
    with TestClient(app) as c:
        r = c.post("/whatsapp", data={"From": "whatsapp:+919800000003", "Body": "pending?", "NumMedia": "0"})
        assert r.status_code == 200 and "<Response>" in r.text
    assert outbox[-1] == ("+919800000003", "Nothing pending.")
