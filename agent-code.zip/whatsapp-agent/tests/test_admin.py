"""Admin panel, role-based routing, deadline alerts to the cost controller,
scheduled reminders and house rules."""
from datetime import timedelta
from unittest import mock

import pytest
from fastapi.testclient import TestClient

from app import agent, db, ops, scheduler
from app.main import app
from app.settings import settings

OWNER, CHEF, PM, HK, COST = "+919800000001", "+919800000002", "+919800000003", "+919800000007", "+919800000008"
H = {"X-Admin-Request": "1"}


def u(phone):
    return db.get_user(phone)


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(settings, "admin_password", "s3cret-pass")
    monkeypatch.setattr(settings, "run_scheduler", False)
    with TestClient(app) as c:
        yield c


def signed_in(c):
    r = c.post("/admin/login", data={"password": "s3cret-pass"}, follow_redirects=False)
    assert r.status_code == 303
    return c


def test_panel_needs_password(monkeypatch):
    monkeypatch.setattr(settings, "admin_password", "")
    with TestClient(app) as c:
        assert "Admin panel is off" in c.get("/admin").text


def test_sign_in_and_state(client):
    assert "Sign in" in client.get("/admin").text
    assert client.get("/admin/api/state").status_code == 401
    assert "Wrong password" in client.post("/admin/login", data={"password": "nope"}).text
    signed_in(client)
    assert "Outlet agent admin" in client.get("/admin").text
    s = client.get("/admin/api/state").json()
    assert s["sample_people"] == 8 and "cost_controller" in s["roles"]
    assert s["sections"]["deadlines"]["alert_to"] == ["role:cost_controller"]


def test_admin_edits_people_and_roles_follow(client, outbox):
    signed_in(client)
    people = client.get("/admin/api/state").json()["users"]
    for p in people:
        p["original_phone"] = p["phone"]
    pm = next(p for p in people if p["phone"] == PM)
    pm.update(phone="+919811111111", name="Asha Rao")

    # Saving without the panel's header is refused.
    assert client.post("/admin/api/people", json={"people": people}).status_code == 403
    bad = [dict(p) for p in people] + [{"name": "Dup", "phone": OWNER, "roles": []}]
    r = client.post("/admin/api/people", json={"people": bad}, headers=H)
    assert r.status_code == 400 and "twice" in r.json()["error"]

    r = client.post("/admin/api/people", json={"people": people}, headers=H)
    assert r.status_code == 200
    assert db.get_user(PM) is None and db.get_user("+919811111111")["name"] == "Asha Rao"

    # Routing names the role, so the new purchase manager gets the order.
    ops.create_requisition(u(CHEF), "kitchen", "perishables", [{"item": "tomato", "qty": 5}], {"needed_by": "2026-10-20 08:00"})
    assert outbox[-1][0] == "+919811111111" and "New request to order" in outbox[-1][1]

    # Someone must stay admin.
    no_admin = [{**p, "roles": [r for r in p["roles"] if r != "admin"]} for p in r.json()["users"] if p["active"]]
    r = client.post("/admin/api/people", json={"people": no_admin}, headers=H)
    assert r.status_code == 400 and "admin" in r.json()["error"]


def test_admin_adds_requisition_type_and_rule(client):
    signed_in(client)
    s = client.get("/admin/api/state").json()["sections"]
    formats = s["formats"]
    formats["kitchen/bakery"] = {"receive_into": "kitchen", "fields": [
        {"name": "needed_by", "type": "datetime", "required": True},
        {"name": "occasion", "type": "choice", "required": False, "options": ["banquet", "daily"]}]}
    assert client.post("/admin/api/settings/formats", json={"value": formats}, headers=H).status_code == 200
    assert "bakery" in ops.request_types("kitchen")

    rules = s["routing"]
    rules.insert(0, {"name": "Bakery", "match": {"department": "kitchen", "request_type": "bakery"},
                     "approvers": ["role:nobody_role"], "then_notify": ["role:purchase_manager"]})
    r = client.post("/admin/api/settings/routing", json={"value": rules}, headers=H)
    assert r.status_code == 400 and "unknown role" in r.json()["error"]
    rules[0]["approvers"] = ["role:cost_controller"]
    assert client.post("/admin/api/settings/routing", json={"value": rules}, headers=H).status_code == 200
    r = ops.create_requisition(u(CHEF), "kitchen", "bakery", [{"item": "Paneer", "qty": 1}], {"needed_by": "2026-10-20 07:00"})
    assert r["routed_by_rule"] == "Bakery" and r["notified"] == ["Kiran (Cost Controller)"]
    # Any holder of the role can approve that step.
    assert ops.decide_requisition(u(COST), r["requisition_id"], "approve")["status"] == "approved"


def test_house_rules_reach_claude(client):
    signed_in(client)
    rules = "Reply in Hindi to kitchen staff."
    assert client.post("/admin/api/settings/agent_instructions", json={"value": rules}, headers=H).status_code == 200
    from tests.test_agent import Block, FakeClient, resp
    fake = FakeClient([resp("end_turn", Block(type="text", text="Namaste"))])
    agent.set_client(fake)
    agent.handle_message(CHEF, "hi")
    system = fake.beta.messages.calls[0]["system"]
    assert rules in system[-1]["text"] and system[-1]["cache_control"] == {"type": "ephemeral"}


def test_deadline_alerts_go_to_cost_controller(outbox):
    start = db.now().replace(hour=6, minute=0, second=0, microsecond=0)
    with mock.patch.object(db, "now", return_value=start):
        r = ops.create_requisition(u(HK), "housekeeping", "supplies", [{"item": "Bath towel", "qty": 4}],
                                   {"needed_by": start.strftime("%Y-%m-%d") + " 10:00"})
        rid = r["requisition_id"]
    outbox.clear()
    # 09:30: four-hour approval limit not reached yet, but the counts are late.
    with mock.patch.object(db, "now", return_value=start + timedelta(hours=3, minutes=30)):
        ops.deadline_alerts()
    msg = [t for p, t in outbox if p == COST]
    assert msg and "Kitchen stock count not finished by 09:00" in msg[0] and f"#{rid}" not in msg[0]
    outbox.clear()
    # 12:30: approval is late and it is past needed-by plus two hours.
    with mock.patch.object(db, "now", return_value=start + timedelta(hours=6, minutes=30)):
        assert ops.deadline_alerts() == 2
        later = [t for p, t in outbox if p == COST][0]
        assert f"#{rid} housekeeping supplies" in later and "waiting 6 h for approval by Pramit" in later
        assert "not received yet" in later
        outbox.clear()
        assert ops.deadline_alerts() == 0 and not outbox          # each delay is told once
        delays = ops.list_delays(u(COST))["delays"]
        assert len(delays) == 6                                   # 4 counts + approval + delivery
    with pytest.raises(ops.OpsError):
        ops.list_delays(u(HK))


def test_scheduler_tick_runs_jobs_and_reminders_once(outbox):
    db.set_cfg("reminders", [{"name": "Payments", "time": "11:00", "days": [], "to": ["role:accounts"],
                              "message": "Review vendor payments.", "active": True}], "test")
    db.set_cfg("stock_count", {**db.cfg("stock_count"), "send_sheets_at": "10:45"}, "test")
    at = db.now().replace(hour=11, minute=5, second=0, microsecond=0)
    ran = scheduler.tick(at)
    assert "count_sheets" in ran and "reminder:Payments" in ran
    assert ("+919800000005", "Review vendor payments.") in outbox
    assert scheduler.tick(at + timedelta(minutes=1)) == []         # not again the same day
    assert scheduler.tick(at.replace(hour=12)) == []              # outside the catch-up window


def test_validation_messages():
    with pytest.raises(ops.OpsError, match="time like"):
        ops.validate_section("reminders", [{"name": "x", "time": "25:00", "to": ["role:admin"], "message": "m"}])
    with pytest.raises(ops.OpsError, match="phone number"):
        ops.validate_section("deadlines", {"alert_to": ["12345"]})
    with pytest.raises(ops.OpsError, match="store"):
        ops.validate_section("locations", ["kitchen"])
