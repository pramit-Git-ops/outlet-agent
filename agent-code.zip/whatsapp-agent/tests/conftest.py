import os
import sys
import tempfile
from pathlib import Path

import pytest

_tmp = tempfile.mkdtemp()
os.environ["DATABASE_PATH"] = str(Path(_tmp) / "test.db")
os.environ["EXPORT_DIR"] = str(Path(_tmp) / "exports")
os.environ["VALIDATE_TWILIO_SIGNATURE"] = "false"
os.environ["RUN_SCHEDULER"] = "false"
os.environ["PETPOOJA_BASE_URL"] = ""
os.environ["PETPOOJA_ACCESS_TOKEN"] = ""
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import db, whatsapp  # noqa: E402


@pytest.fixture(autouse=True)
def fresh_db():
    db.reset_connection()
    p = Path(os.environ["DATABASE_PATH"])
    if p.exists():
        p.unlink()
    db.init_db()
    yield
    db.reset_connection()


@pytest.fixture
def outbox():
    sent = []
    whatsapp.send_hook = lambda phone, text: sent.append((phone, text))
    yield sent
    whatsapp.send_hook = None
