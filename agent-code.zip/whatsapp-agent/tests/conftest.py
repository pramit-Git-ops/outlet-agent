import os
import sys
import tempfile
from pathlib import Path

import pytest

_tmp = tempfile.mkdtemp()
os.environ.update(DATABASE_PATH=str(Path(_tmp) / "test.db"), OLD_DATABASE_PATH=str(Path(_tmp) / "old.db"),
                  VALIDATE_TWILIO_SIGNATURE="false", RUN_SCHEDULER="false")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import db, report, whatsapp  # noqa: E402

ADMIN, KEEPER, MANAGER = "+919811111111", "+919822222222", "+919833333333"


@pytest.fixture(autouse=True)
def fresh_db():
    db.reset_connection()
    for p in (Path(os.environ["DATABASE_PATH"]), Path(os.environ["OLD_DATABASE_PATH"])):
        if p.exists():
            p.unlink()
    db.init_db()
    for phone, name, roles in ((ADMIN, "Pramit", "admin"), (KEEPER, "Ramesh", "stock_keeper"), (MANAGER, "Kiran", "manager")):
        db.execute("INSERT INTO users(phone,name,roles) VALUES (?,?,?)", (phone, name, roles))
    for code, name, unit, rate, daily in (("CHK", "Chicken", "kg", 250, 1), ("ARH", "Arhar dal", "kg", 120, 1),
                                          ("OIL", "Refined oil", "litre", 150, 1), ("SUG", "Sugar", "kg", 45, 0)):
        db.execute("INSERT INTO items(code,name,unit,rate,count_daily) VALUES (?,?,?,?,?)", (code, name, unit, rate, daily))
    yield
    db.reset_connection()


@pytest.fixture
def outbox():
    sent = []
    whatsapp.send_hook = lambda phone, text: sent.append((phone, text))
    yield sent
    whatsapp.send_hook = None


@pytest.fixture
def mailbox():
    sent = []
    report.send_hook = lambda to, subject, html, data, name: sent.append({"to": to, "subject": subject, "html": html, "data": data, "name": name})
    yield sent
    report.send_hook = None
