"""Business logic for the three workflows. No WhatsApp or Claude code here.

Every public function takes the acting user (a dict from db.get_user) and
returns a plain dict that is shown to Claude as the tool result. Messages to
other people go out through notify().
"""
from __future__ import annotations

import difflib
import hashlib
import hmac
import json
import re
from datetime import datetime, timedelta
from pathlib import Path

from . import db, petpooja, sales, tally, whatsapp
from .settings import settings


class OpsError(Exception):
    """A business-rule problem Claude should explain to the user."""


# ---------------------------------------------------------------- helpers

ROLES = {
    "admin": "Administrator: can do everything and change settings",
    "requester": "Raises requisitions for their department",
    "approver": "Approves requisitions",
    "purchase_manager": "Purchase manager: orders, Petpooja entries",
    "store_keeper": "Store keeper: receives and issues stock",
    "counter": "Does the morning stock count",
    "accounts": "Accounts: bills, payments, Tally",
    "cost_controller": "Cost controller: deadline delays and leakage alerts",
    "stakeholder": "Stakeholder: kept informed, can ask for reports",
}


def all_roles() -> dict[str, str]:
    """Built-in roles plus any the administrator added in the admin panel."""
    extra = {r["key"]: r.get("label") or r["key"] for r in (db.cfg("custom_roles", []) or []) if r.get("key")}
    return {**ROLES, **extra}


def recipients(entries: list[str] | None) -> list[str]:
    """Expand a list of phone numbers and role references to phone numbers.
    "role:purchase_manager" is everyone with that role; "role:counter@kitchen"
    limits it to one department."""
    out: list[str] = []
    for entry in entries or []:
        entry = str(entry or "").strip()
        if entry.startswith("role:"):
            role, _, dept = entry[5:].partition("@")
            out += [u["phone"] for u in db.users_with_role(role) if not dept or u.get("department") == dept]
        elif entry:
            out.append(db.normalize_phone(entry))
    return list(dict.fromkeys(out))


def label(entry: str | None) -> str:
    """Human name for a phone number or role reference."""
    if not entry:
        return "nobody"
    if str(entry).startswith("role:"):
        names = [name_of(p) for p in recipients([entry])]
        role, _, dept = entry[5:].partition("@")
        return ", ".join(names) or f"nobody with role {role.replace('_', ' ')}" + (f" in {dept}" if dept else "")
    return name_of(entry)


def has_role(user: dict, *roles: str) -> bool:
    return "admin" in user["roles"] or any(r in user["roles"] for r in roles)


def require(user: dict, *roles: str) -> None:
    if not has_role(user, *roles):
        raise OpsError(f"{user['name']} does not have permission for this (needs: {', '.join(roles)}).")


def notify(phones: list[str], text: str, exclude: str | None = None) -> list[str]:
    sent = []
    for p in recipients(phones):  # expands roles, de-duplicates, keeps order
        if p and db.normalize_phone(p) != db.normalize_phone(exclude or ""):
            whatsapp.send(p, text)
            sent.append(p)
    return sent


def name_of(phone: str) -> str:
    u = db.get_user(phone)
    return u["name"] if u else phone


def money(v: float) -> str:
    return f"₹{v:,.0f}"


def find_items(text: str, limit: int = 8) -> list[dict]:
    items = db.query("SELECT * FROM items")
    t = text.lower().strip()
    exact = [i for i in items if i["code"].lower() == t or i["name"].lower() == t]
    if exact:
        return exact
    contains = [i for i in items if t in i["name"].lower()]
    names = [i["name"] for i in items]
    close = difflib.get_close_matches(text, names, n=limit, cutoff=0.5)
    fuzzy = [i for i in items if i["name"] in close and i not in contains]
    return (contains + fuzzy)[:limit]


def resolve_item(text: str) -> dict | None:
    found = find_items(text, 2)
    if len(found) == 1:
        return found[0]
    if found and found[0]["name"].lower() == text.lower().strip():
        return found[0]
    return None


def _lines_from_input(lines: list[dict]) -> tuple[list[dict], list[str]]:
    out, unknown = [], []
    for line in lines:
        item = resolve_item(line["item"])
        if not item:
            options = find_items(line["item"], 4)
            unknown.append(f"'{line['item']}'" + (f" (did you mean: {', '.join(o['name'] for o in options)}?)" if options else ""))
            continue
        out.append({
            "item_code": item["code"], "item_name": item["name"], "qty": float(line["qty"]),
            "unit": line.get("unit") or item["unit"], "rate": float(item["rate"] or 0),
        })
    return out, unknown


def sign_link(path: str) -> str:
    sig = hmac.new(settings.link_secret.encode(), path.encode(), hashlib.sha256).hexdigest()[:24]
    return f"{settings.public_base_url.rstrip('/')}{path}?sig={sig}"


def check_link(path: str, sig: str) -> bool:
    good = hmac.new(settings.link_secret.encode(), path.encode(), hashlib.sha256).hexdigest()[:24]
    return hmac.compare_digest(good, sig or "")


# ------------------------------------------------- scenario 1: requisitions

def request_types(department: str) -> list[str]:
    return sorted(k.split("/", 1)[1] for k in db.cfg("formats", {}) if k.startswith(f"{department}/"))


def get_format(department: str, request_type: str) -> dict:
    formats = db.cfg("formats", {})
    fmt = formats.get(f"{department}/{request_type}") or formats.get("default") or {"fields": []}
    return {"department": department, "request_type": request_type, **fmt}


def match_rule(department: str, request_type: str, value: float, urgent: bool) -> dict:
    for rule in db.cfg("routing", []):
        m = rule.get("match", {})
        if "urgent" in m and bool(m["urgent"]) != urgent:
            continue
        if "department" in m and m["department"] != department:
            continue
        if "request_type" in m and m["request_type"] != request_type:
            continue
        if "min_value" in m and value < float(m["min_value"]):
            continue
        return rule
    return {"name": "No rule", "approvers": [], "then_notify": ["role:purchase_manager"]}


def get_req(req_id: int) -> dict:
    req = db.query_one("SELECT * FROM requisitions WHERE id=?", (req_id,))
    if not req:
        raise OpsError(f"Requisition #{req_id} not found.")
    req["lines"] = db.query("SELECT * FROM req_lines WHERE req_id=? ORDER BY id", (req_id,))
    req["fields"] = json.loads(req["fields_json"] or "{}")
    req["approvers"] = json.loads(req["approvers_json"] or "[]")
    req["then_notify"] = json.loads(req["then_notify_json"] or "[]")
    req["escalate_to"] = json.loads(req["escalate_to_json"] or "[]")
    return req


def req_summary(req_id: int) -> str:
    r = get_req(req_id)
    lines = "\n".join(
        f"• {l['item_name']}: {l['qty']:g} {l['unit'] or ''}"
        + (f" (received {l['received_qty']:g})" if l["received_qty"] is not None else "")
        for l in r["lines"]
    )
    fields = "\n".join(f"{k.replace('_', ' ').capitalize()}: {v}" for k, v in r["fields"].items() if v)
    urgent = " URGENT" if r["urgent"] else ""
    return (
        f"Requisition #{r['id']}{urgent} · {r['department'].capitalize()} · {r['request_type'].replace('_', ' ')}\n"
        f"By {name_of(r['requester'])} · Est. {money(r['est_value'])} · Status: {r['status'].replace('_', ' ')}\n"
        f"{lines}" + (f"\n{fields}" if fields else "")
    )


def create_requisition(user: dict, department: str, request_type: str, lines: list[dict],
                       fields: dict | None = None, urgent: bool = False) -> dict:
    require(user, "requester")
    if "admin" not in user["roles"] and user.get("department") and user["department"] != department:
        raise OpsError(f"{user['name']} can raise requests only for {user['department']}.")
    fmt = get_format(department, request_type)
    fields = {k: v for k, v in (fields or {}).items() if v not in (None, "")}
    missing = [f["name"] for f in fmt.get("fields", []) if f.get("required") and f["name"] not in fields]
    clean, unknown = _lines_from_input(lines)
    if missing or unknown or not clean:
        return {
            "created": False,
            "missing_fields": missing,
            "unknown_items": unknown,
            "message": "Ask the user for the missing details, then call create_requisition again.",
        }
    value = sum(l["qty"] * l["rate"] for l in clean)
    rule = match_rule(department, request_type, value, urgent)
    approvers = rule.get("approvers", [])
    status = "pending_approval" if approvers else "approved"
    ts = db.now_iso()
    cur = db.execute(
        "INSERT INTO requisitions(outlet,department,request_type,requester,urgent,fields_json,status,rule_name,"
        "approvers_json,approval_step,then_notify_json,escalate_after,escalate_to_json,est_value,receive_into,"
        "created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,0,?,?,?,?,?,?,?)",
        (user.get("outlet"), department, request_type, user["phone"], int(urgent), json.dumps(fields), status,
         rule.get("name"), json.dumps(approvers), json.dumps(rule.get("then_notify", [])),
         rule.get("escalate_after_minutes"), json.dumps(rule.get("escalate_to", [])), value,
         fmt.get("receive_into", "store"), ts, ts),
    )
    req_id = cur.lastrowid
    for l in clean:
        db.execute(
            "INSERT INTO req_lines(req_id,item_code,item_name,qty,unit,rate) VALUES (?,?,?,?,?,?)",
            (req_id, l["item_code"], l["item_name"], l["qty"], l["unit"], l["rate"]),
        )
    db.log_event("created", user["phone"], rule.get("name"), req_id=req_id)
    summary = req_summary(req_id)
    if approvers:
        notified = notify([approvers[0]], f"Approval needed\n{summary}\n\nReply approve {req_id}, reject {req_id} with a reason, or change a quantity.", exclude=user["phone"])
    else:
        notified = notify(rule.get("then_notify", []), f"New request to order\n{summary}", exclude=user["phone"])
    return {"created": True, "requisition_id": req_id, "status": status, "routed_by_rule": rule.get("name"),
            "notified": [name_of(p) for p in notified], "summary": summary}


def pending_for(user: dict) -> dict:
    out: dict[str, list[str]] = {}
    pend = db.query("SELECT id, approvers_json, approval_step FROM requisitions WHERE status='pending_approval'")
    mine = [r["id"] for r in pend
            if user["phone"] in recipients([(json.loads(r["approvers_json"]) + [None])[r["approval_step"]]])
            or ("admin" in user["roles"])]
    if mine:
        out["awaiting_your_approval"] = [req_summary(i) for i in mine]
    if has_role(user, "purchase_manager"):
        out["approved_to_order"] = [req_summary(r["id"]) for r in db.query("SELECT id FROM requisitions WHERE status='approved'")]
        out["received_not_in_petpooja"] = [req_summary(r["id"]) for r in db.query(
            "SELECT id FROM requisitions WHERE status='received' AND petpooja_ref IS NULL")]
        out["payments_to_update_in_petpooja"] = [
            f"Payment #{p['id']}: {p['vendor']} {money(p['amount'])} by {p['mode']} on {p['paid_on']}"
            for p in db.query("SELECT * FROM payments WHERE status='awaiting_petpooja_update' ORDER BY id")]
    if has_role(user, "store_keeper"):
        out["ordered_awaiting_delivery"] = [req_summary(r["id"]) for r in db.query("SELECT id FROM requisitions WHERE status='ordered'")]
    if has_role(user, "accounts"):
        out["bills_to_verify"] = [bill_summary(b["id"]) for b in db.query("SELECT id FROM bills WHERE status='in_petpooja'")]
    mine_open = db.query("SELECT id FROM requisitions WHERE requester=? AND status NOT IN ('closed','rejected') ORDER BY id DESC LIMIT 10", (user["phone"],))
    if mine_open:
        out["your_open_requests"] = [req_summary(r["id"]) for r in mine_open]
    return out or {"message": "Nothing pending."}


def decide_requisition(user: dict, req_id: int, decision: str, note: str = "",
                       quantity_changes: list[dict] | None = None) -> dict:
    req = get_req(req_id)
    if req["status"] != "pending_approval":
        raise OpsError(f"#{req_id} is not awaiting approval (status: {req['status']}).")
    current = req["approvers"][req["approval_step"]] if req["approval_step"] < len(req["approvers"]) else None
    if user["phone"] not in recipients([current]) and "admin" not in user["roles"]:
        raise OpsError(f"#{req_id} is waiting for {label(current)}, not {user['name']}.")
    for ch in quantity_changes or []:
        line = next((l for l in req["lines"] if l["item_name"].lower() == ch["item"].lower()
                     or (resolve_item(ch["item"]) or {}).get("code") == l["item_code"]), None)
        if not line:
            raise OpsError(f"Item {ch['item']} is not on #{req_id}.")
        db.execute("UPDATE req_lines SET qty=? WHERE id=?", (float(ch["qty"]), line["id"]))
        db.log_event("qty_changed", user["phone"], f"{line['item_name']} {line['qty']:g} -> {ch['qty']}", req_id=req_id)
    if quantity_changes:
        value = sum(l["qty"] * l["rate"] for l in db.query("SELECT qty, rate FROM req_lines WHERE req_id=?", (req_id,)))
        db.execute("UPDATE requisitions SET est_value=? WHERE id=?", (value, req_id))
    ts = db.now_iso()
    if decision == "reject":
        db.execute("UPDATE requisitions SET status='rejected', updated_at=? WHERE id=?", (ts, req_id))
        db.log_event("rejected", user["phone"], note, req_id=req_id)
        notify([req["requester"]], f"#{req_id} was rejected by {user['name']}. Reason: {note or 'not given'}", exclude=user["phone"])
        return {"status": "rejected", "summary": req_summary(req_id)}
    step = req["approval_step"] + 1
    db.log_event("approved", user["phone"], note, req_id=req_id)
    if step < len(req["approvers"]):
        db.execute("UPDATE requisitions SET approval_step=?, updated_at=? WHERE id=?", (step, ts, req_id))
        nxt = req["approvers"][step]
        notify([nxt], f"Approval needed (approved by {user['name']})\n{req_summary(req_id)}\n\nReply approve {req_id} or reject {req_id}.")
        return {"status": "pending_approval", "next_approver": label(nxt), "summary": req_summary(req_id)}
    db.execute("UPDATE requisitions SET status='approved', approval_step=?, updated_at=? WHERE id=?", (step, ts, req_id))
    summary = req_summary(req_id)
    notify(req["then_notify"], f"Approved, please order\n{summary}", exclude=user["phone"])
    notify([req["requester"]], f"#{req_id} approved by {user['name']}.", exclude=user["phone"])
    return {"status": "approved", "summary": summary}


def mark_ordered(user: dict, req_id: int, vendor: str, expected_delivery: str = "") -> dict:
    require(user, "purchase_manager")
    req = get_req(req_id)
    if req["status"] != "approved":
        raise OpsError(f"#{req_id} is {req['status']}, it must be approved before ordering.")
    db.execute("UPDATE requisitions SET status='ordered', vendor=?, updated_at=? WHERE id=?", (vendor, db.now_iso(), req_id))
    db.log_event("ordered", user["phone"], f"{vendor} {expected_delivery}", req_id=req_id)
    store = [u["phone"] for u in db.users_with_role("store_keeper")]
    when = f", expected {expected_delivery}" if expected_delivery else ""
    notify([req["requester"]] + store, f"#{req_id} ordered from {vendor}{when}.\n{req_summary(req_id)}", exclude=user["phone"])
    return {"status": "ordered", "summary": req_summary(req_id)}


def record_receipt(user: dict, req_id: int, received: list[dict] | None = None) -> dict:
    """Goods arrived. received=None means everything arrived as ordered."""
    require(user, "store_keeper", "purchase_manager", "requester")
    req = get_req(req_id)
    if req["status"] not in ("ordered", "approved"):
        raise OpsError(f"#{req_id} is {req['status']}; only ordered requests can be received.")
    got = {}
    for r in received or []:
        item = resolve_item(r["item"])
        if not item:
            raise OpsError(f"Unknown item {r['item']}.")
        got[item["code"]] = float(r["qty"])
    ts = db.now_iso()
    short = []
    for l in req["lines"]:
        qty = got.get(l["item_code"], l["qty"]) if received else l["qty"]
        db.execute("UPDATE req_lines SET received_qty=? WHERE id=?", (qty, l["id"]))
        if qty < l["qty"]:
            short.append(f"{l['item_name']} short by {l['qty'] - qty:g} {l['unit'] or ''}")
        if qty:
            db.execute(
                "INSERT INTO stock_moves(at,kind,from_loc,to_loc,item_code,qty,ref,actor) VALUES (?,?,?,?,?,?,?,?)",
                (ts, "receipt", "supplier", req["receive_into"], l["item_code"], qty, f"REQ-{req_id}", user["phone"]),
            )
    db.execute("UPDATE requisitions SET status='received', updated_at=? WHERE id=?", (ts, req_id))
    db.log_event("received", user["phone"], "; ".join(short), req_id=req_id)
    pms = [u["phone"] for u in db.users_with_role("purchase_manager")]
    note = ("\nShort: " + "; ".join(short)) if short else ""
    notify([req["requester"]] + pms, f"#{req_id} received into {req['receive_into']}.{note}", exclude=user["phone"])
    return {"status": "received", "received_into": req["receive_into"], "short": short,
            "next_step": "Ask for a photo of the supplier bill so it can be matched.", "summary": req_summary(req_id)}


def push_to_petpooja(user: dict, req_id: int | None = None, bill_id: int | None = None) -> dict:
    require(user, "purchase_manager")
    bill = get_bill(bill_id) if bill_id else None
    if bill and not req_id:
        req_id = bill["req_id"]
    if not req_id:
        raise OpsError("Give a requisition or bill number to push.")
    req = get_req(req_id)
    if req["status"] not in ("received", "closed"):
        raise OpsError(f"#{req_id} is {req['status']}; push after goods are received.")
    if req["petpooja_ref"]:
        return {"already_pushed": True, "petpooja_ref": req["petpooja_ref"]}
    if not bill:
        bill = db.query_one("SELECT * FROM bills WHERE req_id=? ORDER BY id DESC", (req_id,))
    if bill and bill["status"] == "mismatch":
        raise OpsError(f"Bill #{bill['id']} has unresolved differences: {bill['match_notes']}. Resolve or override first.")
    lines = [{"item_code": l["item_code"], "item_name": l["item_name"], "qty": l["received_qty"] or 0,
              "unit": l["unit"], "rate": l["rate"]} for l in req["lines"]]
    if bill:
        rates = {bl.get("item_code"): bl.get("rate") for bl in json.loads(bill["lines_json"] or "[]")}
        for l in lines:
            if rates.get(l["item_code"]):
                l["rate"] = rates[l["item_code"]]
    purchase = {"reference": f"REQ{req_id}", "outlet": req["outlet"], "vendor": (bill or {}).get("vendor") or req["vendor"],
                "invoice_no": (bill or {}).get("invoice_no"), "invoice_date": (bill or {}).get("invoice_date"),
                "location": req["receive_into"], "lines": lines}
    ad = petpooja.adapter()
    ref = ad.push_purchase(purchase)
    ts = db.now_iso()
    db.execute("UPDATE requisitions SET petpooja_ref=?, status='closed', updated_at=? WHERE id=?", (ref, ts, req_id))
    db.log_event("petpooja_pushed", user["phone"], ref, req_id=req_id)
    for l in lines:  # keep item rates current
        if l["rate"]:
            db.execute("UPDATE items SET rate=? WHERE code=?", (l["rate"], l["item_code"]))
    result = {"petpooja_ref": ref, "mode": ad.name}
    if bill:
        db.execute("UPDATE bills SET petpooja_ref=?, status='in_petpooja', updated_at=? WHERE id=?", (ref, ts, bill["id"]))
        accounts = db.cfg("accounts", {}).get("notify") or [u["phone"] for u in db.users_with_role("accounts")]
        notify(accounts, f"Bill ready to verify\n{bill_summary(bill['id'])}\nReply verified {bill['id']} or query {bill['id']} with a note.")
        result["accounts_notified"] = True
    if ad.name == "manual":
        result["note"] = "Petpooja API not connected yet: added to today's Petpooja upload file."
    return result


def record_issue(user: dict, department: str, lines: list[dict], note: str = "") -> dict:
    require(user, "store_keeper")
    clean, unknown = _lines_from_input(lines)
    if unknown:
        return {"issued": False, "unknown_items": unknown}
    ts = db.now_iso()
    for l in clean:
        db.execute(
            "INSERT INTO stock_moves(at,kind,from_loc,to_loc,item_code,qty,ref,actor) VALUES (?,?,?,?,?,?,?,?)",
            (ts, "issue", "store", department, l["item_code"], l["qty"], note, user["phone"]),
        )
    db.log_event("issued", user["phone"], f"{department}: " + ", ".join(f"{l['item_name']} {l['qty']:g}" for l in clean))
    receivers = [u["phone"] for u in db.query("SELECT phone FROM users WHERE department=? AND active=1", (department,))]
    text = f"Issued to {department} by {user['name']}:\n" + "\n".join(f"• {l['item_name']}: {l['qty']:g} {l['unit']}" for l in clean)
    notify(receivers, text, exclude=user["phone"])
    return {"issued": True, "lines": clean}


def chase_overdue() -> int:
    """Remind approvers and escalate requests nobody has acted on."""
    count = 0
    now = db.now()
    for r in db.query("SELECT id FROM requisitions WHERE status IN ('pending_approval','approved')"):
        req = get_req(r["id"])
        mins = req["escalate_after"]
        if not mins:
            continue
        last = datetime.fromisoformat(req["last_chased_at"] or req["updated_at"])
        if now - last < timedelta(minutes=mins):
            continue
        waiting_on = ([req["approvers"][req["approval_step"]]] if req["status"] == "pending_approval"
                      else req["then_notify"])
        notify(waiting_on, f"Reminder: still waiting on you\n{req_summary(req['id'])}")
        notify(req["escalate_to"], f"Escalation: #{req['id']} has waited over {mins} minutes for {', '.join(label(p) for p in waiting_on)}.\n{req_summary(req['id'])}")
        db.execute("UPDATE requisitions SET last_chased_at=? WHERE id=?", (db.now_iso(), req["id"]))
        count += 1
    # Payments that purchase has not entered in Petpooja within a day.
    stale = db.query("SELECT * FROM payments WHERE status='awaiting_petpooja_update' AND updated_at<?",
                     ((now - timedelta(hours=24)).isoformat(timespec="seconds"),))
    for p in stale:
        notify([u["phone"] for u in db.users_with_role("purchase_manager")],
               f"Reminder: payment #{p['id']} to {p['vendor']} ({money(p['amount'])}) is not yet updated in Petpooja. "
               f"Reply 'payment {p['id']} updated' once done.")
        db.execute("UPDATE payments SET updated_at=? WHERE id=?", (db.now_iso(), p["id"]))
        count += 1
    return count + deadline_alerts()


# ------------------------------------------------- deadlines (cost controller)

DEADLINE_DEFAULTS = {
    "alert_to": ["role:cost_controller"],
    "approval_hours": 4,          # requisition waiting for an approver
    "order_hours": 4,             # approved but not ordered
    "delivery_grace_hours": 2,    # past its "needed by" time and not received
    "count_by": "09:00",          # morning count not finished by this time
    "bill_days": 2,               # goods received but no bill, or a bill left with differences
    "tally_days": 3,              # verified bill not posted to Tally
    "payment_update_hours": 24,   # payment not entered in Petpooja
}


def deadline_settings() -> dict:
    return {**DEADLINE_DEFAULTS, **(db.cfg("deadlines", {}) or {})}


def _on(value) -> bool:
    return value not in (None, "", False)


def _hours_since(iso: str | None) -> float:
    if not iso:
        return 0.0
    return (db.now() - datetime.fromisoformat(iso)).total_seconds() / 3600


def _when(value) -> datetime | None:
    text = str(value or "").strip().replace("T", " ")
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if len(text) <= 10:  # a date only: due by the end of that day
        dt = dt.replace(hour=23, minute=59)
    return dt if dt.tzinfo else dt.replace(tzinfo=db.tz())


def _ago(hours: float) -> str:
    return f"{hours:.0f} h" if hours < 48 else f"{hours / 24:.0f} days"


def overdue_items() -> list[dict]:
    """Everything that has missed its deadline right now, one line each."""
    d = deadline_settings()
    now = db.now()
    out: list[dict] = []

    def add(key: str, kind: str, text: str) -> None:
        out.append({"key": key, "kind": kind, "text": text})

    for r in db.query("SELECT * FROM requisitions WHERE status IN ('pending_approval','approved','ordered') ORDER BY id"):
        title = f"#{r['id']} {r['department']} {r['request_type'].replace('_', ' ')} ({money(r['est_value'] or 0)})"
        waited = _hours_since(r["updated_at"])
        if r["status"] == "pending_approval" and _on(d["approval_hours"]) and waited >= float(d["approval_hours"]):
            steps = json.loads(r["approvers_json"] or "[]")
            step = steps[r["approval_step"]] if r["approval_step"] < len(steps) else None
            add(f"approval:{r['id']}:{r['approval_step']}", "approval",
                f"{title}: waiting {_ago(waited)} for approval by {label(step)}")
        if r["status"] == "approved" and _on(d["order_hours"]) and waited >= float(d["order_hours"]):
            add(f"order:{r['id']}", "order",
                f"{title}: approved {_ago(waited)} ago, not ordered yet ({label('role:purchase_manager')})")
        due = _when(json.loads(r["fields_json"] or "{}").get("needed_by"))
        if due and _on(d["delivery_grace_hours"]) and now >= due + timedelta(hours=float(d["delivery_grace_hours"])):
            vendor = f" from {r['vendor']}" if r["vendor"] else ""
            add(f"delivery:{r['id']}", "delivery",
                f"{title}: needed by {due:%d %b %H:%M}, not received yet (status: {r['status'].replace('_', ' ')}{vendor})")

    if _on(d["count_by"]):
        h, m = (int(x) for x in str(d["count_by"]).split(":"))
        if now >= now.replace(hour=h, minute=m, second=0, microsecond=0):
            today = now.strftime("%Y-%m-%d")
            for loc, who in (db.cfg("stock_count", {}) or {}).get("counters", {}).items():
                meta = db.query_one("SELECT status FROM count_meta WHERE count_date=? AND location=?", (today, loc))
                if not meta or meta["status"] != "complete":
                    add(f"count:{today}:{loc}", "count",
                        f"{loc.capitalize()} stock count not finished by {d['count_by']} "
                        f"(counter: {', '.join(label(w) for w in who) or 'not set'})")

    if _on(d["bill_days"]):
        limit = float(d["bill_days"]) * 24
        for r in db.query("SELECT r.* FROM requisitions r WHERE r.status IN ('received','closed') "
                          "AND NOT EXISTS (SELECT 1 FROM bills b WHERE b.req_id=r.id) ORDER BY r.id"):
            if _hours_since(r["updated_at"]) >= limit:
                add(f"bill:{r['id']}", "bill",
                    f"#{r['id']} {r['department']}: goods received {_ago(_hours_since(r['updated_at']))} ago, no supplier bill yet")
        for b in db.query("SELECT * FROM bills WHERE status='mismatch' ORDER BY id"):
            if _hours_since(b["updated_at"]) >= limit:
                add(f"mismatch:{b['id']}", "bill",
                    f"Bill #{b['id']} {b['vendor']} {money(b['total'])}: differences unresolved for {_ago(_hours_since(b['updated_at']))}")
    if _on(d["tally_days"]):
        for b in db.query("SELECT * FROM bills WHERE status='verified' AND tally_status='ready' ORDER BY id"):
            if _hours_since(b["updated_at"]) >= float(d["tally_days"]) * 24:
                add(f"tally:{b['id']}", "tally",
                    f"Bill #{b['id']} {b['vendor']} {money(b['total'])}: verified {_ago(_hours_since(b['updated_at']))} ago, not in Tally yet")
    if _on(d["payment_update_hours"]):
        for p in db.query("SELECT * FROM payments WHERE status='awaiting_petpooja_update' ORDER BY id"):
            if _hours_since(p["created_at"]) >= float(d["payment_update_hours"]):
                add(f"payment:{p['id']}", "payment",
                    f"Payment #{p['id']} to {p['vendor']} {money(p['amount'])}: not entered in Petpooja after {_ago(_hours_since(p['created_at']))}")
    return out


def deadline_alerts() -> int:
    """Tell the cost controller about each newly missed deadline, once."""
    new = [i for i in overdue_items()
           if not db.query_one("SELECT 1 AS x FROM events WHERE action='deadline_alert' AND note=?", (i["key"],))]
    if not new:
        return 0
    to = deadline_settings().get("alert_to") or []
    if not recipients(to):
        to = ["role:admin"]
    notify(to, "Deadline delays:\n" + "\n".join(f"• {i['text']}" for i in new)
           + "\n\nReply 'show delays' for everything that is late right now.")
    for i in new:
        db.log_event("deadline_alert", None, i["key"])
    return len(new)


def list_delays(user: dict) -> dict:
    require(user, "cost_controller", "stakeholder", "purchase_manager", "accounts", "approver")
    items = overdue_items()
    return {"delays": [i["text"] for i in items]} if items else {"message": "Nothing is late right now."}


# ------------------------------------------------- scenario 2: stock counts

def items_for_location(location: str) -> list[dict]:
    if location == "store":
        return db.query("SELECT * FROM items ORDER BY category, name")
    cats = db.cfg("stock_count", {}).get("location_categories", {}).get(location, [])
    marks = ",".join("?" * len(cats)) or "''"
    return db.query(
        "SELECT * FROM items WHERE code IN (SELECT item_code FROM stock_moves WHERE to_loc=? "
        f"UNION SELECT item_code FROM counts WHERE location=?) OR category IN ({marks}) ORDER BY category, name",
        (location, location, *cats),
    )


def count_sheet(location: str) -> dict:
    items = items_for_location(location)
    by_cat: dict[str, list[str]] = {}
    for i in items:
        by_cat.setdefault(i["category"] or "other", []).append(f"{i['name']} ({i['unit']})")
    return {"location": location, "categories": by_cat, "item_count": len(items),
            "needs_rooms_occupied": location == "housekeeping"}


def _last_count(location: str, before_date: str) -> tuple[str | None, dict[str, float], str | None]:
    meta = db.query_one(
        "SELECT count_date, at FROM count_meta WHERE location=? AND count_date<? AND status='complete' "
        "ORDER BY count_date DESC LIMIT 1", (location, before_date))
    if not meta:
        return None, {}, None
    rows = db.query("SELECT item_code, qty FROM counts WHERE location=? AND count_date=?", (location, meta["count_date"]))
    return meta["count_date"], {r["item_code"]: r["qty"] for r in rows}, meta["at"]


def _moves(location: str, start: str | None, end: str) -> tuple[dict[str, float], dict[str, float]]:
    ins: dict[str, float] = {}
    outs: dict[str, float] = {}
    params = (location, start or "", end)
    for r in db.query("SELECT item_code, SUM(qty) q FROM stock_moves WHERE to_loc=? AND at>? AND at<=? GROUP BY item_code", params):
        ins[r["item_code"]] = r["q"]
    for r in db.query("SELECT item_code, SUM(qty) q FROM stock_moves WHERE from_loc=? AND at>? AND at<=? GROUP BY item_code", params):
        outs[r["item_code"]] = r["q"]
    return ins, outs


def stock_on_hand(item: str | None = None, location: str | None = None) -> dict:
    """Stock now: each department's last complete count plus what came in and went out since.
    Kitchen and bar use during the day is only known at the next count."""
    locs = [location] if location else db.cfg("locations", ["store", "kitchen", "bar", "housekeeping"])
    if location and location not in db.cfg("locations", []):
        raise OpsError(f"Unknown department {location}.")
    only = None
    if item:
        found = find_items(item, 5)
        if not found:
            raise OpsError(f"No item matches {item}.")
        only = {i["code"] for i in found}
    items = {i["code"]: i for i in db.query("SELECT code, name, unit, rate FROM items")}
    rows: dict[str, dict] = {}
    counted_on = {}
    for loc in locs:
        date, opening, at = _last_count(loc, "9999-12-31")
        counted_on[loc] = date
        ins, outs = _moves(loc, at, db.now_iso())
        for code in set(opening) | set(ins) | set(outs):
            if only is not None and code not in only:
                continue
            qty = opening.get(code, 0) + ins.get(code, 0) - outs.get(code, 0)
            it = items.get(code, {"name": code, "unit": "", "rate": 0})
            r = rows.setdefault(code, {"item": it["name"], "unit": it["unit"], "total": 0.0, "by_department": {},
                                       "value": 0.0})
            r["by_department"][loc] = round(qty, 3)
            r["total"] = round(r["total"] + qty, 3)
            r["value"] = round(r["total"] * float(it.get("rate") or 0), 2)
    if only is not None:
        for code in only - set(rows):
            it = items[code]
            rows[code] = {"item": it["name"], "unit": it["unit"], "total": 0.0, "by_department": {}, "value": 0.0}
    return {"as_of": db.now_iso(), "last_count": counted_on,
            "note": "Last morning count plus stock received or issued since. Use in kitchen and bar since the count is not deducted until the next count.",
            "items": sorted(rows.values(), key=lambda r: r["item"].lower())}


def submit_count(user: dict, location: str, lines: list[dict], rooms_occupied: int | None = None,
                 final: bool = True) -> dict:
    require(user, "counter", "store_keeper")
    counters = db.cfg("stock_count", {}).get("counters", {}).get(location, [])
    if counters and user["phone"] not in recipients(counters) and "admin" not in user["roles"]:
        raise OpsError(f"{user['name']} is not assigned to count {location}.")
    today = db.now().strftime("%Y-%m-%d")
    ts = db.now_iso()
    unknown = []
    for line in lines:
        item = resolve_item(line["item"])
        if not item:
            unknown.append(line["item"])
            continue
        db.execute(
            "INSERT INTO counts(count_date,location,item_code,qty,counted_by,at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(count_date,location,item_code) DO UPDATE SET qty=excluded.qty, counted_by=excluded.counted_by, at=excluded.at",
            (today, location, item["code"], float(line["qty"]), user["phone"], ts),
        )
    counted = {r["item_code"]: r["qty"] for r in db.query(
        "SELECT item_code, qty FROM counts WHERE count_date=? AND location=?", (today, location))}
    expected_items = {i["code"]: i for i in items_for_location(location)}
    missing = [i["name"] for c, i in expected_items.items() if c not in counted]
    if location == "housekeeping" and rooms_occupied is None:
        meta = db.query_one("SELECT rooms_occupied FROM count_meta WHERE count_date=? AND location=?", (today, location))
        rooms_occupied = meta["rooms_occupied"] if meta else None
    # Sanity check against book stock.
    _, opening, since = _last_count(location, today)
    ins, outs = _moves(location, since, ts)
    checks = []
    for code, qty in counted.items():
        book = opening.get(code, 0) + ins.get(code, 0) - outs.get(code, 0)
        if since and qty > book + 1e-9:
            checks.append(f"{expected_items.get(code, {'name': code})['name']}: counted {qty:g} but only {book:g} available on book. Please recheck.")
    complete = final and not missing and not (location == "housekeeping" and rooms_occupied is None)
    before = db.query_one("SELECT status FROM count_meta WHERE count_date=? AND location=?", (today, location))
    db.execute(
        "INSERT INTO count_meta(count_date,location,status,rooms_occupied,submitted_by,at) VALUES (?,?,?,?,?,?) "
        "ON CONFLICT(count_date,location) DO UPDATE SET status=excluded.status, "
        "rooms_occupied=COALESCE(excluded.rooms_occupied, count_meta.rooms_occupied), submitted_by=excluded.submitted_by, at=excluded.at",
        (today, location, "complete" if complete else "in_progress", rooms_occupied, user["phone"], ts),
    )
    result = {"location": location, "items_counted": len(counted), "still_missing": missing, "unknown_items": unknown,
              "please_recheck": checks, "rooms_occupied_needed": location == "housekeeping" and rooms_occupied is None,
              "status": "complete" if complete else "in_progress"}
    if complete and not (before and before["status"] == "complete"):
        # As soon as a location's count is complete, compare with Petpooja and alert.
        data = location_variance(location, today)
        if data and "rows" in data:
            result["variance_alerts_sent_to"] = [name_of(p) for p in send_variance_alerts(location, today, data)]
            result["flagged_items"] = [r["item"] for r in data["flagged"]]
        elif data:
            result["note"] = data.get("note")
    return result


def _thresholds(item: dict, location: str) -> tuple[float | None, float | None]:
    """Per-product threshold (percent of expected, or quantity), else the location default."""
    pct, qty = item.get("variance_pct"), item.get("variance_qty")
    if pct is None and qty is None:
        pct = float(db.cfg("stock_count", {}).get("tolerance", {}).get(location, 0.02))
    return pct, qty


def _expected(location: str, prev_date: str, date: str, rooms: int | None,
              items: dict[str, dict], since: str | None = None, until: str | None = None) -> tuple[dict[str, dict], str | None]:
    """Expected use per item code: {"qty": float, "portions": {menu item: count}}."""
    if location == "store":
        return {}, None
    if location == "housekeeping":
        if rooms is None:
            return {}, None
        norms = db.cfg("stock_count", {}).get("housekeeping_norms_per_occupied_room", {})
        return {code: {"qty": per * rooms, "basis": f"{rooms} rooms x {per:g}"} for code, per in norms.items()}, None
    if sales.has_recipes() and until:
        # Dishes Petpooja reported sold between the two counts, times our recipes.
        return sales.expected_use(location, since, until), None
    by_pp = {i["petpooja_code"] or i["code"]: i["code"] for i in items.values()}
    outlet = (db.cfg("outlets", [{}]) or [{}])[0].get("code", "")
    try:
        raw = petpooja.adapter().get_expected_consumption(outlet, prev_date, date)
    except Exception as exc:
        return {}, f"Petpooja consumption for {location} could not be fetched: {exc}"
    out = {}
    for k, v in raw.items():
        v = v if isinstance(v, dict) else {"qty": v}
        out[by_pp.get(k, k)] = {"qty": float(v.get("qty") or 0), "portions": v.get("portions") or {}}
    return out, None


def location_variance(location: str, date: str) -> dict | None:
    """Actual use vs expected use for one location's count date."""
    meta = db.query_one("SELECT * FROM count_meta WHERE location=? AND count_date=? AND status='complete'", (location, date))
    if not meta:
        return None
    prev_date, opening, since = _last_count(location, date)
    if not prev_date:
        return {"note": "First count recorded; consumption starts from the next count."}
    items = {i["code"]: i for i in db.query("SELECT * FROM items")}
    closing = {r["item_code"]: r["qty"] for r in db.query(
        "SELECT item_code, qty FROM counts WHERE location=? AND count_date=?", (location, date))}
    ins, outs = _moves(location, since, meta["at"])
    expected, error = _expected(location, prev_date, date, meta["rooms_occupied"], items, since, meta["at"])
    days = max((datetime.fromisoformat(meta["at"]) - datetime.fromisoformat(since)).total_seconds() / 86400, 1e-9)
    rows, flagged, leak_value = [], [], 0.0
    for code in sorted(set(opening) | set(ins) | set(closing)):
        item = items.get(code, {"name": code, "rate": 0, "unit": ""})
        open_q, in_q, out_q, close_q = opening.get(code, 0), ins.get(code, 0), outs.get(code, 0), closing.get(code, 0)
        used = open_q + in_q - out_q - close_q
        rate = float(item.get("rate") or 0)
        row = {"item": item["name"], "code": code, "unit": item.get("unit") or "", "opening": open_q, "in": in_q,
               "out": out_q, "closing": close_q, "actual_used": round(used, 3)}
        if used > 0 and location != "store":
            row["days_of_stock_left"] = round(close_q / (used / days), 1)
        exp = {"qty": 0.0} if location == "store" else expected.get(code)
        if exp is not None:
            var = used - exp["qty"]
            pct, qty_limit = _thresholds(item, location)
            limit = qty_limit if qty_limit is not None else (pct or 0) * exp["qty"]
            row.update({"expected": round(exp["qty"], 3), "variance": round(var, 3),
                        "variance_pct": round(var / exp["qty"] * 100, 1) if exp["qty"] else None,
                        "variance_value": round(var * rate, 2), "threshold": round(limit, 3),
                        "portions": exp.get("portions") or {}, "basis": exp.get("basis")})
            if abs(var) > limit + 1e-9:
                flagged.append(row)
                if var > 0:
                    leak_value += var * rate
        rows.append(row)
    return {"rows": rows, "flagged": flagged, "leakage_value": round(leak_value, 2), "error": error,
            "rooms_occupied": meta["rooms_occupied"], "window": f"{since} to {meta['at']}", "counted_by": meta["submitted_by"]}


def _variance_line(row: dict) -> str:
    unit = row["unit"]
    direction = "more" if row["variance"] > 0 else "less"
    pct = f", {abs(row['variance_pct']):g}%" if row.get("variance_pct") is not None else ""
    basis = ""
    if row.get("portions"):
        basis = " (" + ", ".join(f"{name} x{n:g}" for name, n in list(row["portions"].items())[:3]) + ")"
    elif row.get("basis"):
        basis = f" ({row['basis']})"
    left = f" {row['closing']:g} {unit} left, about {row['days_of_stock_left']:g} days." if "days_of_stock_left" in row else ""
    return (f"• {row['item']}: counted use {row['actual_used']:g} {unit}, expected {row['expected']:g} {unit}{basis}. "
            f"{abs(row['variance']):g} {unit} {direction}{pct}, {money(abs(row['variance_value']))}.{left}")


def send_variance_alerts(location: str, date: str, data: dict) -> list[str]:
    """Message the concerned people about items beyond their threshold."""
    if not data.get("flagged"):
        return []
    scfg = db.cfg("stock_count", {})
    default = scfg.get("alert_to", {}).get(location) or scfg.get("report_to", [])
    items = {i["code"]: i for i in db.query("SELECT code, alert_to FROM items")}
    per_person: dict[str, list[str]] = {}
    for row in data["flagged"]:
        extra = [p for p in (items.get(row["code"], {}).get("alert_to") or "").split(",") if p]
        for p in recipients(default + extra):
            per_person.setdefault(p, []).append(_variance_line(row))
    who = name_of(data["counted_by"]) if data.get("counted_by") else "the counter"
    sent = []
    for phone, lines in per_person.items():
        sent += notify([phone], f"{location.capitalize()} variance, count of {date} by {who}:\n" + "\n".join(lines))
    db.log_event(f"variance_alert_{location}", None, f"{len(data['flagged'])} items to {len(sent)} people")
    return sent


def set_variance_threshold(user: dict, item: str, percent: float | None = None, quantity: float | None = None,
                           alert_to: list[str] | None = None) -> dict:
    require(user, "admin", "purchase_manager")
    it = resolve_item(item)
    if not it:
        raise OpsError(f"Unknown item {item}.")
    db.execute("UPDATE items SET variance_pct=?, variance_qty=? WHERE code=?",
               (percent / 100 if percent is not None else None, quantity, it["code"]))
    if alert_to is not None:
        db.execute("UPDATE items SET alert_to=? WHERE code=?",
                   (",".join(db.normalize_recipient(p) for p in alert_to), it["code"]))
    return {"saved": True, "item": db.query_one("SELECT code,name,unit,variance_pct,variance_qty,alert_to FROM items WHERE code=?", (it["code"],))}


def consumption_report(date: str | None = None) -> dict:
    date = date or db.now().strftime("%Y-%m-%d")
    report: dict = {"date": date, "petpooja_mode": petpooja.adapter().name, "locations": {}, "not_counted": [],
                     "expected_from": "petpooja sales x recipes" if sales.has_recipes() else petpooja.adapter().name}
    for location in db.cfg("locations", ["store", "kitchen", "bar", "housekeeping"]):
        data = location_variance(location, date)
        if data is None:
            report["not_counted"].append(location)
            continue
        if data.get("error"):
            report.setdefault("errors", []).append(data["error"])
        report["locations"][location] = data
    return report


def report_text(report: dict) -> str:
    out = [f"Stock report {report['date']}"]
    if report["not_counted"]:
        out.append("Not counted yet: " + ", ".join(report["not_counted"]))
    for loc, data in report["locations"].items():
        if "note" in data:
            out.append(f"\n{loc.capitalize()}: {data['note']}")
            continue
        out.append(f"\n{loc.capitalize()}: leakage {money(data['leakage_value'])}")
        out += [_variance_line(row) for row in data["flagged"][:10]]
        if not data["flagged"]:
            used = [r for r in data["rows"] if r["actual_used"]]
            out.append(f"No variance above threshold. {len(used)} items used.")
    for err in report.get("errors", []):
        out.append(f"\n{err}")
    if report["petpooja_mode"] == "manual" and not sales.has_recipes():
        out.append("\nKitchen and bar expected use needs recipes (admin panel, Recipes); showing actual use only.")
    return "\n".join(out)


# ------------------------------------------------- scenario 3: bills

def get_bill(bill_id: int) -> dict:
    bill = db.query_one("SELECT * FROM bills WHERE id=?", (bill_id,))
    if not bill:
        raise OpsError(f"Bill #{bill_id} not found.")
    return bill


def bill_summary(bill_id: int) -> str:
    b = get_bill(bill_id)
    req = f" · Req #{b['req_id']}" if b["req_id"] else ""
    pp = f" · Petpooja {b['petpooja_ref']}" if b["petpooja_ref"] else ""
    notes = f"\nNotes: {b['match_notes']}" if b["match_notes"] else ""
    return (f"Bill #{b['id']} · {b['vendor']} · Inv {b['invoice_no']} dated {b['invoice_date']}{req}{pp}\n"
            f"Taxable {money(b['taxable'])} + GST {money((b['cgst'] or 0) + (b['sgst'] or 0) + (b['igst'] or 0))} = {money(b['total'])}\n"
            f"Status: {b['status'].replace('_', ' ')} · Tally: {b['tally_status']}{notes}")


def record_bill(user: dict, vendor: str, invoice_no: str, invoice_date: str, lines: list[dict],
                taxable: float, total: float, cgst: float = 0, sgst: float = 0, igst: float = 0,
                gstin: str = "", req_id: int | None = None, media_url: str = "", media_type: str = "") -> dict:
    require(user, "store_keeper", "purchase_manager", "accounts")
    dup = db.query_one("SELECT id FROM bills WHERE lower(vendor)=lower(?) AND invoice_no=?", (vendor, invoice_no))
    if dup:
        raise OpsError(f"Duplicate: invoice {invoice_no} from {vendor} is already bill #{dup['id']}.")
    req = get_req(req_id) if req_id else None
    if not req:
        cand = db.query_one("SELECT id FROM requisitions WHERE status='received' AND lower(COALESCE(vendor,''))=lower(?) "
                            "ORDER BY updated_at DESC LIMIT 1", (vendor,))
        req = get_req(cand["id"]) if cand else None
    acfg = db.cfg("accounts", {})
    rate_tol, qty_tol = float(acfg.get("rate_tolerance", 0.02)), float(acfg.get("qty_tolerance", 0))
    clean_lines, notes = [], []
    for bl in lines:
        item = resolve_item(bl["item"])
        qty, rate = float(bl["qty"]), float(bl.get("rate") or 0)
        clean_lines.append({"item_code": item["code"] if item else None, "item_name": item["name"] if item else bl["item"],
                            "qty": qty, "unit": bl.get("unit") or (item or {}).get("unit"), "rate": rate,
                            "amount": float(bl.get("amount") or qty * rate)})
        if not item:
            notes.append(f"{bl['item']} is not in the item master")
            continue
        if req:
            rl = next((l for l in req["lines"] if l["item_code"] == item["code"]), None)
            if not rl:
                notes.append(f"{item['name']} billed but not on requisition #{req['id']}")
                continue
            got = rl["received_qty"] if rl["received_qty"] is not None else rl["qty"]
            if qty > got * (1 + qty_tol) + 1e-9:
                notes.append(f"{item['name']}: billed {qty:g}, received {got:g}")
            agreed = rl["rate"] or item["rate"] or 0
            if agreed and rate > agreed * (1 + rate_tol):
                notes.append(f"{item['name']}: rate {rate:g} vs agreed {agreed:g}")
    if abs(taxable + cgst + sgst + igst - total) > 1.0:
        notes.append(f"Totals do not add up: {taxable} + tax {cgst + sgst + igst} vs {total}")
    if not req:
        notes.append("No matching received requisition found")
    status = "matched" if not notes else "mismatch"
    ts = db.now_iso()
    cur = db.execute(
        "INSERT INTO bills(req_id,outlet,vendor,gstin,invoice_no,invoice_date,taxable,cgst,sgst,igst,total,lines_json,"
        "media_url,media_type,status,match_notes,captured_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        ((req or {}).get("id"), user.get("outlet"), vendor, gstin, invoice_no, invoice_date, taxable, cgst, sgst, igst, total,
         json.dumps(clean_lines), media_url, media_type, status, "; ".join(notes), user["phone"], ts, ts),
    )
    bill_id = cur.lastrowid
    db.log_event("bill_recorded", user["phone"], status, req_id=(req or {}).get("id"), bill_id=bill_id)
    pms = [u["phone"] for u in db.users_with_role("purchase_manager")]
    if status == "matched":
        notify(pms, f"Bill matched\n{bill_summary(bill_id)}\nReply push {bill_id} to record it in Petpooja.", exclude=user["phone"])
    else:
        notify(pms, f"Bill needs checking\n{bill_summary(bill_id)}\nReply override {bill_id} with a reason to accept it.", exclude=user["phone"])
    return {"bill_id": bill_id, "status": status, "differences": notes, "summary": bill_summary(bill_id)}


def override_bill(user: dict, bill_id: int, reason: str) -> dict:
    require(user, "purchase_manager")
    bill = get_bill(bill_id)
    if bill["status"] != "mismatch":
        raise OpsError(f"Bill #{bill_id} is {bill['status']}, nothing to override.")
    db.execute("UPDATE bills SET status='matched', match_notes=?, updated_at=? WHERE id=?",
               (f"{bill['match_notes']} | Accepted by {user['name']}: {reason}", db.now_iso(), bill_id))
    db.log_event("bill_override", user["phone"], reason, bill_id=bill_id)
    return {"status": "matched", "summary": bill_summary(bill_id)}


def accounts_review(user: dict, bill_id: int, decision: str, note: str = "") -> dict:
    require(user, "accounts")
    bill = get_bill(bill_id)
    if bill["status"] not in ("in_petpooja", "queried"):
        raise OpsError(f"Bill #{bill_id} is {bill['status']}; accounts reviews bills once they are in Petpooja.")
    ts = db.now_iso()
    if decision == "verified":
        db.execute("UPDATE bills SET status='verified', tally_status='ready', verified_by=?, updated_at=? WHERE id=?",
                   (user["phone"], ts, bill_id))
        db.log_event("bill_verified", user["phone"], note, bill_id=bill_id)
        return {"status": "verified", "summary": bill_summary(bill_id)}
    db.execute("UPDATE bills SET status='queried', match_notes=COALESCE(match_notes,'') || ? , updated_at=? WHERE id=?",
               (f" | Accounts query: {note}", ts, bill_id))
    db.log_event("bill_queried", user["phone"], note, bill_id=bill_id)
    pms = [u["phone"] for u in db.users_with_role("purchase_manager")]
    notify(pms, f"Accounts query on bill #{bill_id} from {user['name']}: {note}\n{bill_summary(bill_id)}")
    return {"status": "queried", "summary": bill_summary(bill_id)}


def tally_post(user: dict) -> dict:
    """Send all verified bills to Tally (file or direct push)."""
    require(user, "accounts")
    bills = db.query("SELECT * FROM bills WHERE status='verified' AND tally_status='ready' ORDER BY id")
    if not bills:
        return {"message": "No verified bills waiting for Tally."}
    mode = db.cfg("tally", {}).get("mode", "export_file")
    ids = [b["id"] for b in bills]
    marks = ",".join("?" * len(ids))
    ts = db.now_iso()
    if mode == "direct_push":
        response = tally.push(bills)
        ok = "<CREATED>" in response and "<ERRORS>0</ERRORS>" in response.replace(" ", "")
        if not ok:
            return {"posted": False, "tally_response": response[:1500]}
        db.execute(f"UPDATE bills SET tally_status='posted', status='posted', updated_at=? WHERE id IN ({marks})", [ts, *ids])
        return {"posted": True, "bills": ids}
    export_dir = Path(settings.export_dir)
    export_dir.mkdir(parents=True, exist_ok=True)
    name = f"tally_purchases_{db.now().strftime('%Y%m%d_%H%M%S')}.xml"
    (export_dir / name).write_text(tally.envelope(bills), encoding="utf-8")
    db.execute(f"UPDATE bills SET tally_status='exported', status='posted', updated_at=? WHERE id IN ({marks})", [ts, *ids])
    return {"exported": True, "bills": ids, "download_link": sign_link(f"/exports/{name}"),
            "how_to_import": "In TallyPrime: Import > Transactions, choose this XML file."}


def accounts_digest() -> str | None:
    rows = db.query("SELECT id FROM bills WHERE status IN ('in_petpooja','queried') ORDER BY id")
    ready = db.query("SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM bills WHERE status='verified' AND tally_status='ready'")[0]
    if not rows and not ready["n"]:
        return None
    parts = [f"Accounts digest {db.now().strftime('%d %b')}"]
    if rows:
        parts.append(f"{len(rows)} bills to verify:")
        parts += [bill_summary(r["id"]) for r in rows[:8]]
    if ready["n"]:
        parts.append(f"{ready['n']} verified bills ({money(ready['t'])}) ready for Tally. Reply 'post to Tally'.")
    return "\n\n".join(parts)


def purchases_summary(period: str = "month") -> dict:
    start = db.now().strftime("%Y-%m-01") if period == "month" else db.now().strftime("%Y-%m-%d")
    by_dept = db.query(
        "SELECT r.department, ROUND(SUM(COALESCE(l.received_qty,0)*l.rate),2) value FROM requisitions r "
        "JOIN req_lines l ON l.req_id=r.id WHERE r.status IN ('received','closed') AND r.updated_at>=? GROUP BY r.department",
        (start,))
    by_vendor = db.query(
        "SELECT vendor, COUNT(*) bills, ROUND(SUM(total),2) total, "
        "ROUND(SUM(CASE WHEN status!='posted' THEN total ELSE 0 END),2) not_in_tally "
        "FROM bills WHERE invoice_date>=? GROUP BY vendor ORDER BY total DESC", (start,))
    return {"from": start, "received_value_by_department": by_dept, "bills_by_vendor": by_vendor}


# ------------------------------------------------- vendor payments

def _match_vendor(vendor: str) -> str:
    """Best match among vendors the agent has seen, else the name as typed."""
    known = [r["vendor"] for r in db.query(
        "SELECT DISTINCT vendor FROM bills UNION SELECT DISTINCT vendor FROM requisitions WHERE vendor IS NOT NULL "
        "UNION SELECT DISTINCT vendor FROM payments")]
    exact = [v for v in known if v.lower() == vendor.lower().strip()]
    if exact:
        return exact[0]
    contains = [v for v in known if vendor.lower().strip() in v.lower()]
    if len(contains) == 1:
        return contains[0]
    close = difflib.get_close_matches(vendor, known, n=1, cutoff=0.6)
    return close[0] if close else vendor


def vendor_pending(user: dict, vendor: str) -> dict:
    """Pending amount for a vendor: from Petpooja when connected, else from the agent's bills."""
    require(user, "accounts", "purchase_manager")
    name = _match_vendor(vendor)
    outlet = user.get("outlet") or (db.cfg("outlets", [{}]) or [{}])[0].get("code", "")
    error = None
    try:
        invoices = petpooja.adapter().get_vendor_payables(outlet, name)
    except Exception as exc:
        invoices, error = None, f"Petpooja could not be reached ({exc}); showing the agent's own records."
    # Payments recorded here that purchase has not yet entered in Petpooja.
    unposted = db.query("SELECT * FROM payments WHERE lower(vendor)=lower(?) AND status='awaiting_petpooja_update'", (name,))
    unposted_total = sum(p["amount"] for p in unposted)
    if invoices is not None:
        pending = sum(i["pending"] for i in invoices)
        result = {"vendor": name, "source": "Petpooja", "invoices": [i for i in invoices if i["pending"]],
                  "pending_in_petpooja": round(pending, 2)}
        if unposted:
            result["payments_not_yet_in_petpooja"] = round(unposted_total, 2)
            result["pending_after_those_payments"] = round(pending - unposted_total, 2)
        return result
    bills = db.query("SELECT invoice_no, invoice_date, total, status FROM bills WHERE lower(vendor)=lower(?) "
                     "AND status NOT IN ('mismatch') ORDER BY invoice_date", (name,))
    paid = db.query_one("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE lower(vendor)=lower(?)", (name,))["s"]
    billed = sum(b["total"] for b in bills)
    return {"vendor": name, "source": "agent records (Petpooja payables not connected)" if not error else "agent records",
            "note": error, "bills": bills, "billed": round(billed, 2), "paid": round(paid, 2),
            "pending": round(billed - paid, 2)}


def record_payment(user: dict, vendor: str, amount: float, mode: str, reference: str = "",
                   paid_on: str = "", invoices: list[str] | None = None) -> dict:
    """Accounts records a payment; purchase is asked to enter it in Petpooja."""
    require(user, "accounts")
    if amount <= 0:
        raise OpsError("Payment amount must be more than zero.")
    name = _match_vendor(vendor)
    ts = db.now_iso()
    paid_on = paid_on or db.now().strftime("%Y-%m-%d")
    cur = db.execute(
        "INSERT INTO payments(vendor,amount,mode,reference,paid_on,invoices_json,recorded_by,created_at,updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (name, amount, mode, reference, paid_on, json.dumps(invoices or []), user["phone"], ts, ts),
    )
    pid = cur.lastrowid
    db.log_event("payment_recorded", user["phone"], f"{name} {amount} {mode} {reference}")
    inv = f" against invoice {', '.join(invoices)}" if invoices else ""
    ref = f", ref {reference}" if reference else ""
    pms = [u["phone"] for u in db.users_with_role("purchase_manager")]
    sent = notify(pms, f"Payment #{pid}: {user['name']} paid {name} {money(amount)} by {mode}{ref} on {paid_on}{inv}.\n"
                       f"Please record it in Petpooja, then reply 'payment {pid} updated'.", exclude=user["phone"])
    return {"payment_id": pid, "vendor": name, "amount": amount, "notified": [name_of(p) for p in sent]}


def confirm_payment_updated(user: dict, payment_id: int) -> dict:
    require(user, "purchase_manager")
    pay = db.query_one("SELECT * FROM payments WHERE id=?", (payment_id,))
    if not pay:
        raise OpsError(f"Payment #{payment_id} not found.")
    db.execute("UPDATE payments SET status='updated_in_petpooja', confirmed_by=?, updated_at=? WHERE id=?",
               (user["phone"], db.now_iso(), payment_id))
    db.log_event("payment_in_petpooja", user["phone"], str(payment_id))
    notify([pay["recorded_by"]], f"Payment #{payment_id} to {pay['vendor']} ({money(pay['amount'])}) is now updated in Petpooja by {user['name']}.")
    return {"payment_id": payment_id, "status": "updated_in_petpooja"}


# ------------------------------------------------- admin

EDITABLE = {"business", "locations", "routing", "formats", "stock_count", "deadlines", "reminders",
            "accounts", "tally", "agent_instructions", "custom_roles"}
FIELD_TYPES = ["text", "number", "date", "datetime", "choice", "image"]
WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
_SLUG = re.compile(r"^[a-z][a-z0-9_]*$")
_TIME = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_PHONE = re.compile(r"^\+\d{8,15}$")


def _bad(where: str, why: str) -> None:
    raise OpsError(f"{where}: {why}")


def _check_recipients(where: str, value) -> list[str]:
    if value in (None, ""):
        return []
    if not isinstance(value, list):
        _bad(where, "must be a list of people or roles")
    roles, locs = all_roles(), db.cfg("locations", []) or []
    out = []
    for e in value:
        e = str(e).strip()
        if e.startswith("role:"):
            role, _, dept = e[5:].partition("@")
            if role not in roles:
                _bad(where, f"unknown role {role}")
            if dept and dept not in locs:
                _bad(where, f"unknown department {dept}")
        elif not _PHONE.match(db.normalize_phone(e)):
            _bad(where, f"{e} is not a phone number like +919812345678")
        else:
            e = db.normalize_phone(e)
        out.append(e)
    return out


def _check_time(where: str, value, optional: bool = False) -> None:
    if optional and value in (None, ""):
        return
    if not isinstance(value, str) or not _TIME.match(value):
        _bad(where, "must be a time like 07:30")


def _check_number(where: str, value, optional: bool = True) -> None:
    if optional and value in (None, ""):
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
        _bad(where, "must be a number, 0 or more")


def validate_section(section: str, value):
    """Check a settings section before it is saved. Returns the cleaned value."""
    locs = db.cfg("locations", []) or []
    if section not in EDITABLE:
        raise OpsError(f"Section {section} cannot be edited.")
    if section == "agent_instructions":
        if not isinstance(value, str) or len(value) > 6000:
            _bad("Agent rules", "must be text of at most 6,000 characters")
        return value.strip()
    if section == "business":
        if not isinstance(value, dict) or not str(value.get("name", "")).strip():
            _bad("Business", "needs a name")
        return value
    if section == "locations":
        if not isinstance(value, list) or "store" not in value or not all(isinstance(v, str) and _SLUG.match(v) for v in value):
            _bad("Departments", "must include store, in lower case without spaces (use _ instead)")
        return list(dict.fromkeys(value))
    if section == "custom_roles":
        if not isinstance(value, list):
            _bad("Extra roles", "must be a list")
        for r in value:
            if not _SLUG.match(str(r.get("key", ""))) or r["key"] in ROLES:
                _bad("Extra roles", f"'{r.get('key')}' must be a new name in lower case without spaces")
        return value
    if section == "routing":
        if not isinstance(value, list) or not value:
            _bad("Routing", "needs at least one rule")
        for i, r in enumerate(value, 1):
            where = f"Routing rule {i} ({r.get('name') or 'no name'})"
            if not isinstance(r, dict) or not str(r.get("name", "")).strip() or not isinstance(r.get("match", {}), dict):
                _bad(where, "needs a name")
            r.setdefault("match", {})
            if r["match"].get("department") and r["match"]["department"] not in locs:
                _bad(where, f"unknown department {r['match']['department']}")
            _check_number(where + " minimum value", r["match"].get("min_value"))
            for k in ("approvers", "then_notify", "escalate_to"):
                r[k] = _check_recipients(f"{where} {k.replace('_', ' ')}", r.get(k, []))
            _check_number(where + " escalate after", r.get("escalate_after_minutes"))
        return value
    if section == "formats":
        if not isinstance(value, dict) or not value:
            _bad("Requisition types", "need at least one type")
        for key, fmt in value.items():
            dept, _, rtype = key.partition("/")
            if key != "default" and (dept not in locs or not _SLUG.match(rtype or "")):
                _bad(f"Requisition type {key}", "must be department/type, type in lower case without spaces")
            if fmt.get("receive_into", "store") not in locs:
                _bad(f"Requisition type {key}", "goods must go to a known department")
            names = set()
            for f in fmt.get("fields", []):
                if not _SLUG.match(str(f.get("name", ""))) or f["name"] in names:
                    _bad(f"Requisition type {key}", f"field '{f.get('name')}' needs a unique lower-case name")
                if f.get("type", "text") not in FIELD_TYPES:
                    _bad(f"Requisition type {key}", f"field {f['name']} has an unknown type")
                names.add(f["name"])
        return value
    if section == "stock_count":
        if not isinstance(value, dict):
            _bad("Stock count", "must be a set of settings")
        for k in ("send_sheets_at", "reminder_at", "report_at"):
            _check_time(f"Stock count {k.replace('_', ' ')}", value.get(k))
        value["report_to"] = _check_recipients("Stock report goes to", value.get("report_to"))
        for k in ("counters", "alert_to"):
            value[k] = {loc: _check_recipients(f"{loc} {k.replace('_', ' ')}", v) for loc, v in (value.get(k) or {}).items()}
        for loc, t in (value.get("tolerance") or {}).items():
            _check_number(f"{loc} tolerance", t, optional=False)
        return value
    if section == "deadlines":
        if not isinstance(value, dict):
            _bad("Deadlines", "must be a set of settings")
        value["alert_to"] = _check_recipients("Deadline alerts go to", value.get("alert_to"))
        for k in ("approval_hours", "order_hours", "delivery_grace_hours", "bill_days", "tally_days", "payment_update_hours"):
            _check_number(f"Deadlines {k.replace('_', ' ')}", value.get(k))
        _check_time("Deadlines count by", value.get("count_by"), optional=True)
        return value
    if section == "reminders":
        if not isinstance(value, list):
            _bad("Reminders", "must be a list")
        for i, r in enumerate(value, 1):
            where = f"Reminder {i} ({r.get('name') or 'no name'})"
            if not str(r.get("name", "")).strip() or not str(r.get("message", "")).strip():
                _bad(where, "needs a name and a message")
            _check_time(where, r.get("time"))
            if any(d not in WEEKDAYS for d in r.get("days") or []):
                _bad(where, "days must be mon, tue, wed, thu, fri, sat or sun")
            r["to"] = _check_recipients(where, r.get("to"))
            if not r["to"]:
                _bad(where, "needs at least one person or role")
        return value
    if section == "accounts":
        _check_time("Accounts digest time", value.get("digest_at"), optional=True)
        value["notify"] = _check_recipients("Accounts notify", value.get("notify"))
        _check_number("Rate tolerance", value.get("rate_tolerance"))
        return value
    if section == "tally":
        if value.get("mode", "export_file") not in ("export_file", "direct_push"):
            _bad("Tally", "mode must be export_file or direct_push")
        return value
    return value


def get_settings(section: str) -> dict:
    if section == "users":
        return {"users": db.query("SELECT phone,name,roles,department,outlet,active FROM users")}
    if section == "items":
        return {"items": db.query("SELECT * FROM items ORDER BY category, name")}
    if section not in EDITABLE:
        raise OpsError(f"Unknown section {section}.")
    return {section: db.cfg(section)}


def update_settings(user: dict, section: str, value_json: str) -> dict:
    require(user, "admin")
    try:
        value = json.loads(value_json)
    except json.JSONDecodeError as exc:
        raise OpsError(f"Invalid JSON: {exc}") from exc
    value = validate_section(section, value)
    db.set_cfg(section, value, user["phone"])
    db.log_event(f"settings_{section}", user["phone"])
    return {"saved": True, section: value}


def upsert_user(user: dict, phone: str, name: str, roles: list[str], department: str = "", outlet: str = "") -> dict:
    require(user, "admin")
    unknown = [r for r in roles if r not in all_roles()]
    if unknown:
        raise OpsError(f"Unknown role {', '.join(unknown)}. Roles: {', '.join(all_roles())}.")
    db.upsert_user(phone, name, roles, department or None, outlet or user.get("outlet"))
    return {"saved": True, "user": db.get_user(phone)}


def deactivate_user(user: dict, phone: str) -> dict:
    require(user, "admin")
    db.execute("UPDATE users SET active=0 WHERE phone=?", (db.normalize_phone(phone),))
    return {"deactivated": phone}


def upsert_item(user: dict, code: str, name: str, unit: str, category: str, rate: float = 0) -> dict:
    require(user, "admin", "purchase_manager")
    db.execute("INSERT INTO items(code,name,unit,category,rate) VALUES (?,?,?,?,?) "
               "ON CONFLICT(code) DO UPDATE SET name=excluded.name, unit=excluded.unit, category=excluded.category, rate=excluded.rate",
               (code, name, unit, category, rate))
    return {"saved": True, "item": db.query_one("SELECT * FROM items WHERE code=?", (code,))}
