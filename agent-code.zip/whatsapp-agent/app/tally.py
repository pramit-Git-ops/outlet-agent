"""Tally purchase vouchers: an import file (default) or a direct push.

Vouchers are created in accounting-invoice style: supplier ledger credited,
purchase ledger(s) and GST ledgers debited, items listed in the narration.
Test the import on a copy of your Tally company before using it on live books.
"""
from __future__ import annotations

import json
from collections import defaultdict
from xml.sax.saxutils import escape

import httpx2 as httpx

from . import db


def _amt(value: float) -> str:
    return f"{value:.2f}"


def _ledger_entry(ledger: str, amount: float, debit: bool) -> str:
    # In Tally XML a debit is ISDEEMEDPOSITIVE=Yes with a negative amount.
    signed = -abs(amount) if debit else abs(amount)
    return (
        "<ALLLEDGERENTRIES.LIST>"
        f"<LEDGERNAME>{escape(ledger)}</LEDGERNAME>"
        f"<ISDEEMEDPOSITIVE>{'Yes' if debit else 'No'}</ISDEEMEDPOSITIVE>"
        f"<AMOUNT>{_amt(signed)}</AMOUNT>"
        "</ALLLEDGERENTRIES.LIST>"
    )


def voucher_xml(bill: dict) -> str:
    tcfg = db.cfg("tally", {})
    lines = json.loads(bill.get("lines_json") or "[]")
    by_ledger: dict[str, float] = defaultdict(float)
    item_cats = {r["code"]: r["category"] for r in db.query("SELECT code, category FROM items")}
    for line in lines:
        cat = item_cats.get(line.get("item_code") or "", "")
        ledger = tcfg.get("ledger_by_category", {}).get(cat, tcfg.get("purchase_ledger", "Purchase"))
        by_ledger[ledger] += float(line.get("amount") or line.get("qty", 0) * line.get("rate", 0))
    taxable = float(bill.get("taxable") or sum(by_ledger.values()))
    if not by_ledger:
        by_ledger[tcfg.get("purchase_ledger", "Purchase")] = taxable
    # Scale line totals to the bill's taxable value so the voucher balances.
    line_sum = sum(by_ledger.values()) or 1
    if abs(line_sum - taxable) > 0.01:
        by_ledger = {k: v * taxable / line_sum for k, v in by_ledger.items()}

    gst = tcfg.get("gst_ledgers", {})
    debits = [(k, round(v, 2)) for k, v in by_ledger.items()]
    for key in ("cgst", "sgst", "igst"):
        if float(bill.get(key) or 0):
            debits.append((gst.get(key, key.upper()), round(float(bill[key]), 2)))
    total = round(float(bill.get("total") or 0), 2)
    diff = round(total - sum(a for _, a in debits), 2)
    if diff:
        debits.append((tcfg.get("round_off_ledger", "Round Off"), diff))

    date = (bill.get("invoice_date") or db.now().strftime("%Y-%m-%d")).replace("-", "")
    narration = "; ".join(f"{l['item_name']} {l['qty']} {l.get('unit') or ''} @ {l.get('rate')}" for l in lines)
    narration = f"Agent bill #{bill['id']}. {narration}"
    entries = _ledger_entry(bill["vendor"], total, debit=False) + "".join(
        _ledger_entry(name, amt, debit=True) for name, amt in debits if amt
    )
    return (
        '<VOUCHER VCHTYPE="Purchase" ACTION="Create">'
        f"<DATE>{date}</DATE>"
        "<VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>"
        f"<REFERENCE>{escape(bill.get('invoice_no') or '')}</REFERENCE>"
        f"<PARTYLEDGERNAME>{escape(bill['vendor'])}</PARTYLEDGERNAME>"
        f"<NARRATION>{escape(narration)}</NARRATION>"
        f"{entries}"
        "</VOUCHER>"
    )


def envelope(bills: list[dict]) -> str:
    company = db.cfg("tally", {}).get("company", "")
    messages = "".join(f'<TALLYMESSAGE xmlns:UDF="TallyUDF">{voucher_xml(b)}</TALLYMESSAGE>' for b in bills)
    return (
        "<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>"
        "<BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME>"
        f"<STATICVARIABLES><SVCURRENTCOMPANY>{escape(company)}</SVCURRENTCOMPANY></STATICVARIABLES>"
        f"</REQUESTDESC><REQUESTDATA>{messages}</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>"
    )


def push(bills: list[dict]) -> str:
    """Direct push to TallyPrime's HTTP server (Tally must be open)."""
    url = db.cfg("tally", {}).get("push_url", "http://localhost:9000")
    with httpx.Client(timeout=60) as client:
        resp = client.post(url, content=envelope(bills).encode("utf-8"),
                           headers={"Content-Type": "text/xml"})
        resp.raise_for_status()
        return resp.text
