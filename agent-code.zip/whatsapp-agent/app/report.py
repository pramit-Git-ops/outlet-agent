"""The daily variance report: an Excel file emailed to the addresses set in the admin panel."""
from __future__ import annotations

import base64
import io
import logging
from typing import Callable

import httpx2 as httpx
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import db, stock, whatsapp
from .settings import settings

log = logging.getLogger(__name__)

# Tests replace this with a function that records emails.
send_hook: Callable[[list[str], str, str, bytes, str], None] | None = None

HEAD = Font(bold=True, color="FFFFFF")
HEAD_FILL = PatternFill("solid", fgColor="1F6F5C")
OVER = PatternFill("solid", fgColor="FDE2E1")
UNDER = PatternFill("solid", fgColor="FFF4DC")
COLUMNS = [("Item", 26), ("Unit", 8), ("Previous count", 14), ("Sent to kitchen", 15), ("Today's count", 14),
           ("Actual consumption", 19), ("Ideal consumption", 18), ("Variance qty", 13), ("Rate (Rs)", 11),
           ("Variance amount (Rs)", 20)]


def _sheet_header(ws, title: str, lines: list[str], columns: list[tuple[str, int]]) -> int:
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, size=14)
    for i, line in enumerate(lines, 2):
        ws.cell(row=i, column=1, value=line)
    row = len(lines) + 3
    for c, (name, width) in enumerate(columns, 1):
        cell = ws.cell(row=row, column=c, value=name)
        cell.font, cell.fill = HEAD, HEAD_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(c)].width = width
    ws.freeze_panes = ws.cell(row=row + 1, column=2)
    return row + 1


def build_excel(date: str) -> tuple[bytes, dict]:
    rep = stock.variance(date)
    wb = Workbook()
    ws = wb.active
    ws.title = "Variance"
    title = f"{rep['business']}: kitchen stock variance, {date}"
    if rep["first_count"]:
        r = _sheet_header(ws, title, [f"Counted by {rep['counted_by']}", rep["note"]], [("Item", 26), ("Unit", 8), ("Today's count", 14)])
        for row in rep["rows"]:
            ws.append([row["item"], row["unit"], row["closing"]])
    else:
        info = [f"Period: {rep['from'][:16].replace('T', ' ')} to {rep['to'][:16].replace('T', ' ')} "
                f"(count of {rep['previous_date']} to count of {date})",
                f"Counted by {rep['counted_by']}. Actual = previous count + sent to kitchen - today's count. "
                "Ideal = Petpooja sales x recipes. Variance = actual - ideal (positive means more was used than sales explain)."]
        r = _sheet_header(ws, title, info, COLUMNS)
        for row in rep["rows"]:
            ws.append([row["item"], row["unit"], row["opening"], row["issued"], row["closing"], row["actual"],
                       row["ideal"], row["variance"], row["rate"], row["variance_amount"]])
            fill = OVER if row["variance"] > 0 else UNDER if row["variance"] < 0 else None
            if fill:
                for c in (8, 10):
                    ws.cell(row=ws.max_row, column=c).fill = fill
        ws.append([])
        ws.append(["Total"] + [None] * 8 + [rep["total_variance_amount"]])
        ws.cell(row=ws.max_row, column=1).font = ws.cell(row=ws.max_row, column=10).font = Font(bold=True)
        for row in ws.iter_rows(min_row=r, min_col=3, max_col=10):
            for c in row:
                c.number_format = "#,##0.00" if c.column >= 9 else "0.###"
        ds = wb.create_sheet("Dishes sold")
        _sheet_header(ds, f"Dishes sold (Petpooja), {rep['from'][:10]} to {rep['to'][:10]}", [],
                      [("Dish", 36), ("Quantity", 10), ("Recipe entered", 15)])
        for d in rep["dishes_sold"]:
            ds.append([d["dish"], d["qty"], "yes" if d["has_recipe"] else "NO, add it in the admin panel"])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue(), rep


def filename(date: str) -> str:
    return f"kitchen-variance-{date}.xlsx"


def _summary_html(rep: dict) -> str:
    if rep["first_count"]:
        return f"<p>The first kitchen count was recorded on {rep['date']} by {rep['counted_by']}. It is the opening stock; " \
               "the comparison starts with the next count.</p>"
    top = sorted(rep["rows"], key=lambda r: -abs(r["variance_amount"]))[:5]
    items = "".join(f"<li>{r['item']}: actual {r['actual']:g} {r['unit']}, ideal {r['ideal']:g}, variance {r['variance']:+g} "
                    f"({r['variance_amount']:+,.0f} Rs)</li>" for r in top if r["variance"])
    missing = [d["dish"] for d in rep["dishes_sold"] if not d["has_recipe"]]
    note = f"<p>{len(missing)} dishes sold have no recipe yet, so their raw materials are not in the ideal figure.</p>" if missing else ""
    return (f"<p>Kitchen stock variance for {rep['date']} (counted by {rep['counted_by']}). "
            f"Total variance: <b>{rep['total_variance_amount']:+,.0f} Rs</b>.</p>"
            + (f"<p>Biggest differences:</p><ul>{items}</ul>" if items else "<p>No differences.</p>")
            + note + "<p>The full table is in the attached Excel file.</p>")


def send_email(to: list[str], subject: str, html: str, attachment: bytes | None = None, name: str = "") -> dict:
    status, error = "sent", None
    try:
        if not to:
            raise RuntimeError("No email addresses are set in the admin panel (Daily report).")
        if send_hook is not None:
            send_hook(to, subject, html, attachment or b"", name)
        else:
            if not settings.brevo_api_key or not settings.email_from:
                raise RuntimeError("Email is not set up: add BREVO_API_KEY and EMAIL_FROM in Railway Variables.")
            body = {"sender": {"email": settings.email_from, "name": settings.email_from_name},
                    "to": [{"email": e} for e in to], "subject": subject, "htmlContent": html}
            if attachment:
                body["attachment"] = [{"content": base64.b64encode(attachment).decode(), "name": name}]
            with httpx.Client(timeout=30) as client:
                resp = client.post("https://api.brevo.com/v3/smtp/email", json=body,
                                   headers={"api-key": settings.brevo_api_key, "accept": "application/json"})
                if resp.status_code >= 300:
                    raise RuntimeError(f"Brevo said {resp.status_code}: {resp.text[:300]}")
    except Exception as exc:
        status, error = "failed", str(exc)
        log.warning("Email failed: %s", exc)
    db.execute("INSERT INTO emails(at,to_list,subject,status,error) VALUES (?,?,?,?,?)",
               (db.now_iso(), ", ".join(to), subject, status, error))
    return {"status": status, "error": error}


def email_report(date: str, to: list[str] | None = None) -> dict:
    data, rep = build_excel(date)
    subject = f"{rep['business']}: kitchen stock variance {date}"
    result = send_email(to if to is not None else (db.get("report_emails") or []), subject, _summary_html(rep), data, filename(date))
    if result["status"] == "sent":
        db.execute("UPDATE count_days SET emailed_at=? WHERE count_date=?", (db.now_iso(), date))
        db.log_event("report_emailed", "system", date)
    else:
        for admin in db.people_with("admin"):
            whatsapp.send(admin["phone"], f"The kitchen variance report for {date} could not be emailed: {result['error']}")
    return result


def due(now=None) -> bool:
    now = now or db.now()
    return now.strftime("%H:%M") >= (db.get("report_at") or "11:00")


def send_if_due(now=None) -> dict | None:
    """Email today's report once the count is finished and the report time has come."""
    now = now or db.now()
    date = now.strftime("%Y-%m-%d")
    day = stock.day_status(date)
    if not day or day["status"] != "complete" or day["emailed_at"] or not due(now):
        return None
    if not db.claim_once(f"report:{date}"):
        return None
    return email_report(date)
