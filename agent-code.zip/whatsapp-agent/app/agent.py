"""The Claude agent loop: one WhatsApp message in, one reply out."""
from __future__ import annotations

import base64
import json
import logging
import threading
from datetime import datetime, timedelta

import anthropic

from . import db, whatsapp
from .prompts import SYSTEM_PROMPT
from .settings import settings
from .tools import TOOLS, run_tool, to_json

log = logging.getLogger(__name__)

MAX_STEPS = 15
SESSION_IDLE = timedelta(hours=3)
SESSION_MAX_MESSAGES = 60
# Models that accept the server-side refusal fallback ("default" routing).
FALLBACK_MODELS = {"claude-opus-5-5", "claude-opus-5", "claude-fable-5-1", "claude-sonnet-5-5"}

_client: anthropic.Anthropic | None = None
_user_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()


def client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=settings.anthropic_api_key or None)
    return _client


def set_client(c) -> None:
    """Tests inject a fake client here."""
    global _client
    _client = c


def _lock_for(phone: str) -> threading.Lock:
    with _locks_guard:
        return _user_locks.setdefault(phone, threading.Lock())


def _load_history(phone: str) -> list[dict]:
    row = db.query_one("SELECT messages_json, updated_at FROM conversations WHERE phone=?", (phone,))
    if not row:
        return []
    messages = json.loads(row["messages_json"])
    # Start a fresh conversation after a quiet spell or once it gets long. The
    # history is never edited in place, only replaced as a whole, which keeps
    # Claude's earlier reasoning valid.
    if db.now() - datetime.fromisoformat(row["updated_at"]) > SESSION_IDLE or len(messages) > SESSION_MAX_MESSAGES:
        return []
    return messages


def _save_history(phone: str, messages: list[dict]) -> None:
    db.execute(
        "INSERT INTO conversations(phone,messages_json,updated_at) VALUES (?,?,?) "
        "ON CONFLICT(phone) DO UPDATE SET messages_json=excluded.messages_json, updated_at=excluded.updated_at",
        (phone, json.dumps(messages), db.now_iso()),
    )


def _sender_block(user: dict) -> str:
    return (
        "<sender>\n"
        f"name: {user['name']}\nphone: {user['phone']}\nroles: {', '.join(user['roles'])}\n"
        f"department: {user.get('department') or '-'}\noutlet: {user.get('outlet') or '-'}\n"
        f"local time: {db.now().strftime('%A %d %b %Y, %H:%M')}\n"
        "</sender>"
    )


def _media_blocks(media: list[dict]) -> list[dict]:
    blocks = []
    for m in media:
        ctype = (m.get("type") or "").split(";")[0]
        try:
            data, real_type = (m["bytes"], ctype) if "bytes" in m else whatsapp.download_media(m["url"])
            ctype = ctype or real_type
        except Exception as exc:
            blocks.append({"type": "text", "text": f"[An attachment could not be downloaded: {exc}]"})
            continue
        b64 = base64.standard_b64encode(data).decode()
        if ctype in ("image/jpeg", "image/png", "image/webp", "image/gif"):
            blocks.append({"type": "image", "source": {"type": "base64", "media_type": ctype, "data": b64}})
        elif ctype == "application/pdf":
            blocks.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": b64}})
        elif ctype.startswith("audio/"):
            blocks.append({"type": "text", "text": "[The person sent a voice note. Voice transcription is not "
                                                   "switched on yet, so ask them to type it or send a photo.]"})
        else:
            blocks.append({"type": "text", "text": f"[Unsupported attachment type {ctype}]"})
    return blocks


def _dump(block) -> dict:
    return block.model_dump(mode="json", by_alias=True, exclude_none=True)


def _create(messages: list[dict]):
    system = [{"type": "text", "text": SYSTEM_PROMPT}]
    rules = (db.cfg("agent_instructions", "") or "").strip()
    if rules:
        system.append({"type": "text", "text": f"<house_rules>\n{rules}\n</house_rules>"})
    system[-1]["cache_control"] = {"type": "ephemeral"}
    kwargs = dict(
        model=settings.claude_model,
        max_tokens=16000,
        system=system,
        tools=TOOLS,
        messages=messages,
        thinking={"type": "adaptive"},
        output_config={"effort": settings.claude_effort},
    )
    if settings.claude_model in FALLBACK_MODELS:
        kwargs.update(betas=["server-side-fallback-2026-07-01"], fallbacks="default")
    return client().beta.messages.create(**kwargs)


def handle_message(phone: str, text: str, media: list[dict] | None = None) -> str:
    """Process one inbound WhatsApp message and return the reply text."""
    phone = db.normalize_phone(phone)
    user = db.get_user(phone)
    if not user:
        return ("Hello! This number is not registered yet. Please ask your manager to add you, "
                "then message again.")
    with _lock_for(phone):
        messages = _load_history(phone)
        content: list[dict] = [{"type": "text", "text": _sender_block(user)}]
        content += _media_blocks(media or [])
        content.append({"type": "text", "text": text or "(no text, see attachment)"})
        messages.append({"role": "user", "content": content})
        first_media = (media or [None])[0]
        reply_parts: list[str] = []
        for _ in range(MAX_STEPS):
            try:
                response = _create(messages)
            except anthropic.RateLimitError:
                log.warning("Rate limited")
                return "I'm a bit busy right now. Please send that again in a minute."
            except anthropic.APIStatusError as exc:
                log.exception("Claude API error %s", exc.status_code)
                return "Sorry, something went wrong on my side. Please try again shortly."
            except anthropic.APIConnectionError:
                log.exception("Claude connection error")
                return "I could not reach my AI service. Please try again shortly."
            messages.append({"role": "assistant", "content": [_dump(b) for b in response.content]})
            texts = [b.text for b in response.content if b.type == "text" and b.text.strip()]
            if response.stop_reason == "refusal":
                _save_history(phone, [])  # do not carry a declined exchange forward
                return "Sorry, I can't help with that request."
            if response.stop_reason == "pause_turn":
                continue
            if response.stop_reason != "tool_use":
                reply_parts += texts
                break
            reply_parts += texts
            results = []
            for block in response.content:
                if block.type != "tool_use":
                    continue
                result = run_tool(block.name, block.input, user,
                                  {"url": first_media.get("url", ""), "type": first_media.get("type", "")} if first_media else None)
                log.info("tool %s by %s -> %s", block.name, phone, to_json(result)[:300])
                results.append({"type": "tool_result", "tool_use_id": block.id, "content": to_json(result),
                                **({"is_error": True} if isinstance(result, dict) and "error" in result else {})})
            messages.append({"role": "user", "content": results})
        else:
            reply_parts.append("That took more steps than expected. Please check the status with 'pending'.")
        _save_history(phone, messages)
        # Only the last text the model wrote is the reply; earlier texts were progress notes.
        return reply_parts[-1] if reply_parts else "Done."
