"""Kitchen stock: what was sent to the kitchen, the stock keeper's daily count,
and the comparison of actual use with ideal use.

    actual use = previous count + issued since then - today's count
    ideal use  = dishes Petpooja sold in the same period x recipes (Petpooja's own
                 recipes through its Consumption API, or recipes entered in the admin panel)
    variance   = actual - ideal  (positive: more used than the sales explain)
"""
from __future__ import annotations

from . import db, petpooja, sales


class StockError(ValueError):
    pass


def has_role(user: dict, *roles: str) -> bool:
    return "admin" in user["roles"] or any(r in user["roles"] for r in roles)


def require(user: dict, *roles: str) -> None:
    if not has_role(user, *roles):
        names = ", ".join(db.ROLES[r].split(":")[0].lower() for r in roles)
        raise StockError(f"{user['name']} cannot do this. It needs an administrator or {names}.")


# ------------------------------------------------------------ items

def find_items(text: str, limit: int = 8) -> list[dict]:
    t = " ".join(str(text or "").lower().split())
    rows = db.query("SELECT * FROM items ORDER BY name")
    exact = [i for i in rows if t in (i["code"].lower(), i["name"].lower())]
    if exact:
        return exact
    words = t.split()
    return [i for i in rows if all(w in f"{i['code']} {i['name']}".lower() for w in words)][:limit]


def resolve_item(text: str) -> dict | None:
    found = find_items(text, 2)
    return found[0] if len(found) == 1 else None


def count_list() -> list[dict]:
    return db.query("SELECT code, name, unit FROM items WHERE count_daily=1 ORDER BY name")


def _lines(lines: list[dict]) -> tuple[list[tuple[dict, float]], list[str]]:
    clean, problems = [], []
    for line in lines or []:
        item = resolve_item(str(line.get("item", "")))
        try:
            qty = float(line.get("qty"))
        except (TypeError, ValueError):
            qty = -1
        if not item:
            matches = [i["name"] for i in find_items(str(line.get("item", "")))]
            problems.append(f"{line.get('item')}: " + (f"which one? {', '.join(matches)}" if matches else "not in the item list"))
        elif qty < 0:
            problems.append(f"{item['name']}: quantity missing")
        else:
            clean.append((item, qty))
    return clean, problems


# ------------------------------------------------------------ stock sent to the kitchen

def record_issue(actor: str, lines: list[dict], note: str = "") -> dict:
    clean, problems = _lines(lines)
    if problems:
        return {"saved": False, "problems": problems}
    at = db.now_iso()
    for item, qty in clean:
        db.execute("INSERT INTO issues(at,item_code,qty,note,entered_by) VALUES (?,?,?,?,?)",
                   (at, item["code"], qty, note or None, actor))
    text = ", ".join(f"{i['name']} {q:g} {i['unit']}" for i, q in clean)
    db.log_event("issued_to_kitchen", actor, text)
    return {"saved": True, "issued": [{"item": i["name"], "qty": q, "unit": i["unit"]} for i, q in clean]}


def recent_issues(limit: int = 100) -> list[dict]:
    return db.query("SELECT s.id, s.at, s.qty, s.note, s.entered_by, i.name AS item, i.unit FROM issues s "
                    "LEFT JOIN items i ON i.code=s.item_code ORDER BY s.at DESC, s.id DESC LIMIT ?", (limit,))


def delete_issue(issue_id: int, actor: str) -> None:
    row = db.query_one("SELECT * FROM issues WHERE id=?", (issue_id,))
    if not row:
        raise StockError("That entry no longer exists.")
    db.execute("DELETE FROM issues WHERE id=?", (issue_id,))
    db.log_event("issue_deleted", actor, f"{row['item_code']} {row['qty']:g} of {row['at'][:16]}")


# ------------------------------------------------------------ daily count

def today() -> str:
    return db.now().strftime("%Y-%m-%d")


def day_status(date: str) -> dict | None:
    return db.query_one("SELECT * FROM count_days WHERE count_date=?", (date,))


def submit_count(user: dict, lines: list[dict], finished: bool = False) -> dict:
    """Save counted quantities for today. When the stock keeper says they are
    finished, every item on the count list must have a quantity."""
    require(user, "stock_keeper")
    date = today()
    clean, problems = _lines(lines)
    at = db.now_iso()
    for item, qty in clean:
        db.execute("INSERT INTO counts(count_date,item_code,qty,counted_by,at) VALUES (?,?,?,?,?) "
                   "ON CONFLICT(count_date,item_code) DO UPDATE SET qty=excluded.qty, counted_by=excluded.counted_by, at=excluded.at",
                   (date, item["code"], qty, user["name"], at))
    day = day_status(date)
    if not day:
        db.execute("INSERT INTO count_days(count_date,status,counted_by) VALUES (?,?,?)", (date, "in_progress", user["name"]))
    counted = {r["item_code"] for r in db.query("SELECT item_code FROM counts WHERE count_date=?", (date,))}
    missing = [f"{i['name']} ({i['unit']})" for i in count_list() if i["code"] not in counted]
    result = {"date": date, "saved": [f"{i['name']} {q:g} {i['unit']}" for i, q in clean], "problems": problems,
              "still_missing": missing}
    if day and day["status"] == "complete":
        result["status"] = "complete"
        result["note"] = "Today's count was already finished; these quantities were corrected."
        if day["emailed_at"]:
            result["note"] += " The report was already emailed; an administrator can send it again from the admin panel."
        return result
    if finished and not missing and not problems:
        petpooja.sync_quietly()   # latest transfers and bills before working out the use
        db.execute("UPDATE count_days SET status='complete', counted_by=?, completed_at=? WHERE count_date=?",
                   (user["name"], db.now_iso(), date))
        db.log_event("count_finished", user["name"], f"{len(counted)} items")
        result["status"] = "complete"
        rep = variance(date)
        if not rep.get("first_count"):
            top = sorted(rep["rows"], key=lambda r: -abs(r["variance_amount"]))[:3]
            result["biggest_differences"] = [
                f"{r['item']}: used {r['actual']:g} {r['unit']}, ideal {r['ideal']:g}, difference {r['variance']:+g} ({r['variance_amount']:+,.0f} Rs)"
                for r in top if r["variance"]]
    else:
        result["status"] = "in_progress"
    return result


def last_complete(before: str | None = None) -> dict | None:
    sql = "SELECT * FROM count_days WHERE status='complete'"
    if before:
        return db.query_one(sql + " AND count_date<? ORDER BY count_date DESC LIMIT 1", (before,))
    return db.query_one(sql + " ORDER BY count_date DESC LIMIT 1")


def _counts(date: str) -> dict[str, float]:
    return {r["item_code"]: r["qty"] for r in db.query("SELECT item_code, qty FROM counts WHERE count_date=?", (date,))}


def _issued(start: str | None, end: str) -> dict[str, float]:
    return {r["item_code"]: r["q"] for r in db.query(
        "SELECT item_code, SUM(qty) q FROM issues WHERE at>? AND at<=? GROUP BY item_code", (start or "", end))}


def variance(date: str) -> dict:
    """Actual vs ideal use for the period ending with this day's finished count."""
    day = day_status(date)
    if not day or day["status"] != "complete":
        raise StockError(f"The count for {date} is not finished.")
    prev = last_complete(before=date)
    items = {i["code"]: i for i in db.query("SELECT * FROM items")}
    closing = _counts(date)
    base = {"date": date, "counted_by": day["counted_by"], "completed_at": day["completed_at"],
            "business": db.get("business_name")}
    if not prev:
        rows = [{"item": items[c]["name"], "unit": items[c]["unit"], "closing": q} for c, q in sorted(closing.items()) if c in items]
        return {**base, "first_count": True, "rows": rows,
                "note": "This is the first count, so it is the opening stock. Use is worked out from the next count."}
    start, end = prev["completed_at"], day["completed_at"]
    opening, issued = _counts(prev["count_date"]), _issued(start, end)
    from_petpooja = petpooja.use_for_ideal()
    ideal = (petpooja if from_petpooja else sales).ideal_use(start, end)
    # Items counted on either day; an item added to the list later starts from its first count.
    codes = sorted(set(closing) | set(opening), key=lambda c: items.get(c, {}).get("name", c).lower())
    rows = []
    for code in codes:
        if code not in items:
            continue
        it = items[code]
        o, i, c = opening.get(code, 0.0), issued.get(code, 0.0), closing.get(code, 0.0)
        actual = o + i - c
        ide = ideal.get(code, {}).get("qty", 0.0)
        var = actual - ide
        rows.append({"item": it["name"], "code": code, "unit": it["unit"], "opening": round(o, 3), "issued": round(i, 3),
                     "closing": round(c, 3), "actual": round(actual, 3), "ideal": round(ide, 3),
                     "variance": round(var, 3), "rate": it["rate"], "variance_amount": round(var * (it["rate"] or 0), 2),
                     "dishes": ideal.get(code, {}).get("dishes", {}),
                     "not_counted_before": code not in opening})
    return {**base, "first_count": False, "previous_date": prev["count_date"], "from": start, "to": end, "rows": rows,
            "total_variance_amount": round(sum(r["variance_amount"] for r in rows), 2),
            "ideal_source": "Petpooja recipes" if from_petpooja else "recipes in the admin panel",
            "dishes_sold": (petpooja if from_petpooja else sales).dishes_sold(start, end),
            "not_matched": petpooja.unmatched_consumption(start, end) if from_petpooja else []}


def kitchen_stock(item: str | None = None) -> dict:
    """Last finished count plus stock sent to the kitchen since. Use since the count shows at the next count."""
    last = last_complete()
    counts = _counts(last["count_date"]) if last else {}
    issued = _issued(last["completed_at"] if last else None, db.now_iso())
    items = {i["code"]: i for i in db.query("SELECT * FROM items")}
    codes = set(counts) | set(issued)
    if item:
        found = {i["code"] for i in find_items(item)}
        if not found:
            raise StockError(f"No item matches {item}.")
        codes = found
    rows = [{"item": items[c]["name"], "unit": items[c]["unit"], "last_count": counts.get(c),
             "issued_since": issued.get(c, 0.0), "in_kitchen": round(counts.get(c, 0.0) + issued.get(c, 0.0), 3)}
            for c in codes if c in items]
    return {"last_count_date": last["count_date"] if last else None, "rows": sorted(rows, key=lambda r: r["item"].lower()),
            "note": "Last finished count plus stock sent to the kitchen since. Use since then shows at the next count."}
