"""Web admin panel: the administrator manages people, roles and every setting
from a browser at /admin, protected by the ADMIN_PASSWORD environment variable."""
from __future__ import annotations

import hashlib
import hmac
import time
from collections import defaultdict, deque
from pathlib import Path

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from . import db, ops, sales
from .settings import settings

router = APIRouter(prefix="/admin")

COOKIE = "admin_session"
SESSION_SECONDS = 12 * 3600
PAGE = Path(__file__).with_name("admin_page.html")
SAMPLE_PREFIX = "+9198000000"
# Sections shown in the panel, with the default used when nothing is saved yet.
SECTIONS = {
    "business": {}, "locations": [], "routing": [], "formats": {}, "stock_count": {},
    "deadlines": ops.DEADLINE_DEFAULTS, "reminders": [], "accounts": {}, "tally": {},
    "agent_instructions": "", "custom_roles": [],
}
_failures: dict[str, deque] = defaultdict(deque)


# ---------------------------------------------------------------- sign-in

def _sign(expires: int) -> str:
    # The password is part of the signature, so changing it signs everyone out.
    key = f"{settings.link_secret}:{settings.admin_password}".encode()
    return hmac.new(key, f"admin:{expires}".encode(), hashlib.sha256).hexdigest()


def _signed_in(request: Request) -> bool:
    if not settings.admin_password:
        return False
    token = request.cookies.get(COOKIE, "")
    expires, _, sig = token.partition(".")
    return expires.isdigit() and int(expires) > time.time() and hmac.compare_digest(sig, _sign(int(expires)))


def _guard(request: Request, write: bool = False) -> None:
    if not _signed_in(request):
        raise HTTPException(status_code=401, detail="Please sign in again.")
    # Browsers only send this header from our own page, which blocks forged
    # form posts from other sites.
    if write and request.headers.get("X-Admin-Request") != "1":
        raise HTTPException(status_code=403, detail="Bad request origin.")


def _too_many(ip: str) -> bool:
    q = _failures[ip]
    while q and q[0] < time.time() - 900:
        q.popleft()
    return len(q) >= 10


def _message_page(title: str, body: str, form: bool = False, error: str = "") -> HTMLResponse:
    login = (
        '<form method="post" action="/admin/login"><label>Admin password<br>'
        '<input type="password" name="password" autofocus required></label>'
        '<button type="submit">Sign in</button></form>' if form else ""
    )
    err = f'<p class="err">{error}</p>' if error else ""
    return HTMLResponse(
        "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title}</title><style>body{{font-family:system-ui,sans-serif;background:#f5f6f8;color:#1d2330;"
        "display:flex;justify-content:center;padding:60px 16px}main{background:#fff;border-radius:12px;padding:28px;"
        "max-width:380px;width:100%;box-shadow:0 1px 3px #0002}input{width:100%;padding:10px;margin:6px 0 14px;"
        "border:1px solid #ccd;border-radius:8px;font-size:16px;box-sizing:border-box}button{background:#1f6f5c;color:#fff;"
        "border:0;border-radius:8px;padding:10px 18px;font-size:15px;cursor:pointer}.err{color:#b42318}</style></head>"
        f"<body><main><h2>{title}</h2><p>{body}</p>{err}{login}</main></body></html>"
    )


@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
def panel(request: Request) -> HTMLResponse:
    if not settings.admin_password:
        return _message_page("Admin panel is off",
                             "Add a variable called ADMIN_PASSWORD on your server (in Railway: Variables), "
                             "then open this page again.")
    if not _signed_in(request):
        return _message_page("Outlet agent admin", "Sign in to manage people, roles and settings.", form=True)
    return HTMLResponse(PAGE.read_text(encoding="utf-8"))


@router.post("/login")
def login(request: Request, password: str = Form("")):
    ip = request.client.host if request.client else "?"
    if not settings.admin_password:
        return RedirectResponse("/admin", status_code=303)
    if _too_many(ip):
        return _message_page("Outlet agent admin", "Too many wrong attempts. Try again in 15 minutes.")
    if not hmac.compare_digest(password.encode(), settings.admin_password.encode()):
        _failures[ip].append(time.time())
        return _message_page("Outlet agent admin", "Sign in to manage people, roles and settings.",
                             form=True, error="Wrong password.")
    expires = int(time.time()) + SESSION_SECONDS
    resp = RedirectResponse("/admin", status_code=303)
    resp.set_cookie(COOKIE, f"{expires}.{_sign(expires)}", max_age=SESSION_SECONDS, httponly=True,
                    samesite="strict", secure=settings.public_base_url.startswith("https://"))
    db.log_event("admin_sign_in", "admin panel", ip)
    return resp


@router.post("/logout")
def logout():
    resp = RedirectResponse("/admin", status_code=303)
    resp.delete_cookie(COOKIE)
    return resp


# ---------------------------------------------------------------- data

def _state() -> dict:
    users = db.query("SELECT phone,name,roles,department,outlet,active FROM users ORDER BY active DESC, name")
    for u in users:
        u["roles"] = [r for r in u["roles"].split(",") if r]
        u["active"] = bool(u["active"])
    items = db.query("SELECT code,name,unit,category,rate,petpooja_code,variance_pct,variance_qty,alert_to "
                     "FROM items ORDER BY category, name")
    for it in items:
        it["alert_to"] = [p for p in (it["alert_to"] or "").split(",") if p]
    sections = {k: db.cfg(k, default) for k, default in SECTIONS.items()}
    sections["deadlines"] = ops.deadline_settings()
    return {
        "users": users,
        "items": items,
        "sections": sections,
        "roles": ops.all_roles(),
        "outlets": db.cfg("outlets", []),
        "field_types": ops.FIELD_TYPES,
        "weekdays": ops.WEEKDAYS,
        "sample_people": sum(1 for u in users if u["active"] and u["phone"].startswith(SAMPLE_PREFIX)),
        "delays": [i["text"] for i in ops.overdue_items()],
        "webhook": settings.public_base_url.rstrip("/") + "/whatsapp",
        "recipes": sales.recipes(),
        "petpooja": {**sales.status(), "dishes_without_recipe": sales.dishes_without_recipe()[:50],
                     "today": sales.sales_summary()},
    }


def _fail(exc: Exception) -> JSONResponse:
    return JSONResponse({"error": str(exc)}, status_code=400)


@router.get("/api/state")
def state(request: Request) -> dict:
    _guard(request)
    return _state()


@router.post("/api/people")
async def save_people(request: Request):
    _guard(request, write=True)
    rows = (await request.json()).get("people", [])
    roles = ops.all_roles()
    locs = db.cfg("locations", []) or []
    seen: set[str] = set()
    try:
        clean = []
        for i, r in enumerate(rows, 1):
            name = str(r.get("name", "")).strip()
            phone = db.normalize_phone(str(r.get("phone", "")))
            where = f"Row {i} ({name or 'no name'})"
            if not name:
                raise ops.OpsError(f"{where}: needs a name")
            if not ops._PHONE.match(phone):
                raise ops.OpsError(f"{where}: {r.get('phone')} is not a WhatsApp number like +919812345678")
            if phone in seen:
                raise ops.OpsError(f"{where}: {phone} is listed twice. Give one person several roles instead.")
            seen.add(phone)
            bad = [x for x in r.get("roles", []) if x not in roles]
            if bad:
                raise ops.OpsError(f"{where}: unknown role {', '.join(bad)}")
            if r.get("department") and r["department"] not in locs:
                raise ops.OpsError(f"{where}: unknown department {r['department']}")
            clean.append((r, name, phone))
        if not any(r.get("active", True) and "admin" in r.get("roles", []) for r, _, _ in clean):
            raise ops.OpsError("Keep at least one active person with the admin role.")
    except ops.OpsError as exc:
        return _fail(exc)
    for r, name, phone in clean:
        original = db.normalize_phone(str(r.get("original_phone") or ""))
        if original and original != phone:
            db.execute("UPDATE users SET active=0 WHERE phone=?", (original,))
        db.upsert_user(phone, name, r.get("roles", []), r.get("department") or None, r.get("outlet") or None)
        if not r.get("active", True):
            db.execute("UPDATE users SET active=0 WHERE phone=?", (phone,))
    listed = {phone for _, _, phone in clean}
    for u in db.query("SELECT phone FROM users WHERE active=1"):
        if u["phone"] not in listed:  # removed from the table
            db.execute("UPDATE users SET active=0 WHERE phone=?", (u["phone"],))
    db.log_event("admin_people_saved", "admin panel", f"{len(clean)} people")
    return _state()


@router.post("/api/items")
async def save_items(request: Request):
    _guard(request, write=True)
    rows = (await request.json()).get("items", [])
    seen: set[str] = set()
    try:
        for i, r in enumerate(rows, 1):
            code = str(r.get("code", "")).strip().upper()
            where = f"Item row {i} ({r.get('name') or 'no name'})"
            if not code or not str(r.get("name", "")).strip() or not str(r.get("unit", "")).strip():
                raise ops.OpsError(f"{where}: needs a code, a name and a unit")
            if code in seen:
                raise ops.OpsError(f"{where}: code {code} is used twice")
            seen.add(code)
            for k in ("rate", "variance_pct", "variance_qty"):
                ops._check_number(f"{where} {k.replace('_', ' ')}", r.get(k))
            r["code"] = code
            r["alert_to"] = ops._check_recipients(f"{where} alert to", r.get("alert_to"))
        existing = {x["code"] for x in db.query("SELECT code FROM items")}
        removed = existing - seen
        used = [c for c in removed if db.query_one(
            "SELECT 1 AS x FROM stock_moves WHERE item_code=? UNION SELECT 1 FROM req_lines WHERE item_code=? "
            "UNION SELECT 1 FROM counts WHERE item_code=?", (c, c, c))]
        if used:
            raise ops.OpsError(f"Items already used in records cannot be removed: {', '.join(sorted(used))}")
    except ops.OpsError as exc:
        return _fail(exc)
    for c in removed:
        db.execute("DELETE FROM items WHERE code=?", (c,))
    for r in rows:
        num = lambda k: float(r[k]) if r.get(k) not in (None, "") else None  # noqa: E731
        db.execute(
            "INSERT INTO items(code,name,unit,category,rate,petpooja_code,variance_pct,variance_qty,alert_to) "
            "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(code) DO UPDATE SET name=excluded.name, unit=excluded.unit, "
            "category=excluded.category, rate=excluded.rate, petpooja_code=excluded.petpooja_code, "
            "variance_pct=excluded.variance_pct, variance_qty=excluded.variance_qty, alert_to=excluded.alert_to",
            (r["code"], r["name"].strip(), r["unit"].strip(), (r.get("category") or "").strip() or None,
             num("rate") or 0, r.get("petpooja_code") or None, num("variance_pct"), num("variance_qty"),
             ",".join(r["alert_to"]) or None),
        )
    db.log_event("admin_items_saved", "admin panel", f"{len(rows)} items")
    return _state()


@router.post("/api/recipes")
async def save_recipes(request: Request):
    _guard(request, write=True)
    rows = (await request.json()).get("recipes", [])
    try:
        n = sales.save_recipes(rows)
    except sales.SalesError as exc:
        return _fail(exc)
    db.log_event("admin_recipes_saved", "admin panel", f"{n} recipe lines")
    return _state()


@router.post("/api/settings/{section}")
async def save_section(section: str, request: Request):
    _guard(request, write=True)
    value = (await request.json()).get("value")
    try:
        value = ops.validate_section(section, value)
    except ops.OpsError as exc:
        return _fail(exc)
    db.set_cfg(section, value, "admin panel")
    db.log_event(f"settings_{section}", "admin panel")
    return _state()


@router.post("/api/test-message")
async def test_message(request: Request):
    """Send a WhatsApp test message to one person."""
    _guard(request, write=True)
    phone = db.normalize_phone((await request.json()).get("phone", ""))
    if not db.get_user(phone):
        return _fail(ops.OpsError("That number is not an active person."))
    ops.notify([phone], "Test message from your outlet agent's admin panel. Reply 'hi' to start.")
    row = db.query_one("SELECT status, error FROM outbox WHERE phone=? ORDER BY id DESC", (phone,))
    return {"status": (row or {}).get("status", "sent"), "error": (row or {}).get("error")}


@router.get("/api/stock")
def stock(request: Request) -> dict:
    _guard(request)
    return ops.stock_on_hand()


@router.post("/api/stock")
async def set_stock(request: Request):
    _guard(request, write=True)
    body = await request.json()
    try:
        done = ops.set_stock("admin panel", str(body.get("location") or ""), body.get("lines") or [])
    except ops.OpsError as exc:
        return _fail(exc)
    return {**ops.stock_on_hand(), "saved": done}


@router.get("/api/activity")
def activity(request: Request) -> dict:
    _guard(request)
    rows = db.query("SELECT at, actor, action, note, req_id, bill_id FROM events ORDER BY id DESC LIMIT 200")
    for r in rows:
        r["actor"] = ops.name_of(r["actor"]) if r["actor"] and r["actor"].startswith("+") else (r["actor"] or "system")
    return {"events": rows}
