"""Web admin panel at /admin, protected by the ADMIN_PASSWORD variable.
The administrator manages people, items, recipes, report settings and sees the reports here."""
from __future__ import annotations

import hashlib
import hmac
import re
import time
from collections import defaultdict, deque
from pathlib import Path

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

from . import db, report, sales, stock, whatsapp
from .settings import settings

router = APIRouter(prefix="/admin")

COOKIE = "admin_session"
SESSION_SECONDS = 12 * 3600
PAGE = Path(__file__).with_name("admin_page.html")
_failures: dict[str, deque] = defaultdict(deque)
_PHONE = re.compile(r"^\+\d{10,15}$")
_TIME = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------------------------------------------------------------- sign-in

def _sign(expires: int) -> str:
    # The password is part of the signature, so changing it signs everyone out.
    key = f"{settings.link_secret}:{settings.admin_password}".encode()
    return hmac.new(key, f"admin:{expires}".encode(), hashlib.sha256).hexdigest()


def _signed_in(request: Request) -> bool:
    if not settings.admin_password:
        return False
    token = request.cookies.get(COOKIE, "")
    expires, _, sig = token.partition(".")
    return expires.isdigit() and int(expires) > time.time() and hmac.compare_digest(sig, _sign(int(expires)))


def _guard(request: Request, write: bool = False) -> None:
    if not _signed_in(request):
        raise HTTPException(status_code=401, detail="Please sign in again.")
    # Browsers only send this header from our own page, which blocks forged
    # form posts from other sites.
    if write and request.headers.get("X-Admin-Request") != "1":
        raise HTTPException(status_code=403, detail="Bad request origin.")


def _too_many(ip: str) -> bool:
    q = _failures[ip]
    while q and q[0] < time.time() - 900:
        q.popleft()
    return len(q) >= 10


def _message_page(title: str, body: str, form: bool = False, error: str = "") -> HTMLResponse:
    login = (
        '<form method="post" action="/admin/login"><label>Admin password<br>'
        '<input type="password" name="password" autofocus required></label>'
        '<button type="submit">Sign in</button></form>' if form else ""
    )
    err = f'<p class="err">{error}</p>' if error else ""
    return HTMLResponse(
        "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title}</title><style>body{{font-family:system-ui,sans-serif;background:#f5f6f8;color:#1d2330;"
        "display:flex;justify-content:center;padding:60px 16px}main{background:#fff;border-radius:12px;padding:28px;"
        "max-width:380px;width:100%;box-shadow:0 1px 3px #0002}input{width:100%;padding:10px;margin:6px 0 14px;"
        "border:1px solid #ccd;border-radius:8px;font-size:16px;box-sizing:border-box}button{background:#1f6f5c;color:#fff;"
        "border:0;border-radius:8px;padding:10px 18px;font-size:15px;cursor:pointer}.err{color:#b42318}</style></head>"
        f"<body><main><h2>{title}</h2><p>{body}</p>{err}{login}</main></body></html>"
    )


@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
def panel(request: Request) -> HTMLResponse:
    if not settings.admin_password:
        return _message_page("Admin panel is off",
                             "Add a variable called ADMIN_PASSWORD on your server (in Railway: Variables), "
                             "then open this page again.")
    if not _signed_in(request):
        return _message_page("Stock agent admin", "Sign in to manage the stock agent.", form=True)
    return HTMLResponse(PAGE.read_text(encoding="utf-8"))


@router.post("/login")
def login(request: Request, password: str = Form("")):
    ip = request.client.host if request.client else "?"
    if not settings.admin_password:
        return RedirectResponse("/admin", status_code=303)
    if _too_many(ip):
        return _message_page("Stock agent admin", "Too many wrong attempts. Try again in 15 minutes.")
    if not hmac.compare_digest(password.encode(), settings.admin_password.encode()):
        _failures[ip].append(time.time())
        return _message_page("Stock agent admin", "Sign in to manage the stock agent.",
                             form=True, error="Wrong password.")
    expires = int(time.time()) + SESSION_SECONDS
    resp = RedirectResponse("/admin", status_code=303)
    resp.set_cookie(COOKIE, f"{expires}.{_sign(expires)}", max_age=SESSION_SECONDS, httponly=True,
                    samesite="strict", secure=settings.public_base_url.startswith("https://"))
    db.log_event("admin_sign_in", "admin panel", ip)
    return resp


@router.post("/logout")
def logout():
    resp = RedirectResponse("/admin", status_code=303)
    resp.delete_cookie(COOKIE)
    return resp



# ---------------------------------------------------------------- data

class Invalid(ValueError):
    pass


def _fail(exc: Exception) -> JSONResponse:
    return JSONResponse({"error": str(exc)}, status_code=400)


def _state() -> dict:
    users = db.query("SELECT phone, name, roles, active FROM users ORDER BY active DESC, name")
    for u in users:
        u["roles"] = [r for r in u["roles"].split(",") if r]
        u["active"] = bool(u["active"])
    today = stock.today()
    counted = {r["item_code"] for r in db.query("SELECT item_code FROM counts WHERE count_date=?", (today,))}
    count_items = stock.count_list()
    day = stock.day_status(today)
    return {
        "users": users,
        "roles": db.ROLES,
        "items": db.query("SELECT code, name, unit, rate, count_daily FROM items ORDER BY name"),
        "settings": {k: db.get(k) for k in db.DEFAULTS},
        "recipes": sales.recipes(),
        "petpooja": {**sales.status(), "dishes_without_recipe": sales.dishes_without_recipe()[:50],
                     "today": sales.sales_summary()},
        "today": {"date": today, "status": day["status"] if day else "not started", "counted_by": day and day["counted_by"],
                  "emailed_at": day and day["emailed_at"], "items": len(count_items),
                  "missing": [i["name"] for i in count_items if i["code"] not in counted]},
        "days": db.query("SELECT count_date, status, counted_by, completed_at, emailed_at FROM count_days "
                         "ORDER BY count_date DESC LIMIT 60"),
        "issues": stock.recent_issues(),
        "kitchen_stock": stock.kitchen_stock(),
        "emails": db.query("SELECT at, to_list, subject, status, error FROM emails ORDER BY id DESC LIMIT 20"),
        "email_ready": bool(settings.brevo_api_key and settings.email_from),
        "whatsapp_webhook": settings.public_base_url.rstrip("/") + "/whatsapp",
    }


@router.get("/api/state")
def state(request: Request) -> dict:
    _guard(request)
    return _state()


@router.post("/api/people")
async def save_people(request: Request):
    _guard(request, write=True)
    rows = (await request.json()).get("people", [])
    try:
        clean, seen = [], set()
        for i, r in enumerate(rows, 1):
            name = str(r.get("name", "")).strip()
            raw = str(r.get("phone", "")).strip()
            digits = re.sub(r"\D", "", raw)
            # A 10-digit Indian mobile typed without the country code
            phone = "+91" + digits if len(digits) == 10 and not raw.startswith("+") else db.normalize_phone(raw)
            where = f"Row {i} ({name or 'no name'})"
            if not name:
                raise Invalid(f"{where}: needs a name")
            if not _PHONE.match(phone):
                raise Invalid(f"{where}: {r.get('phone')} is not a WhatsApp number like +919812345678")
            if phone in seen:
                raise Invalid(f"{where}: {phone} is listed twice")
            seen.add(phone)
            roles = [x for x in r.get("roles", []) if x in db.ROLES]
            clean.append((phone, name, roles, bool(r.get("active", True)), db.normalize_phone(str(r.get("original_phone") or ""))))
        if not any(active and "admin" in roles for _, _, roles, active, _ in clean):
            raise Invalid("Keep at least one active person who is an administrator.")
    except Invalid as exc:
        return _fail(exc)
    for phone, name, roles, active, original in clean:
        if original and original != phone:
            db.execute("DELETE FROM users WHERE phone=?", (original,))
        db.execute("INSERT INTO users(phone,name,roles,active) VALUES (?,?,?,?) ON CONFLICT(phone) DO UPDATE SET "
                   "name=excluded.name, roles=excluded.roles, active=excluded.active",
                   (phone, name, ",".join(roles), int(active)))
    keep = {c[0] for c in clean}
    for u in db.query("SELECT phone FROM users"):
        if u["phone"] not in keep:
            db.execute("DELETE FROM users WHERE phone=?", (u["phone"],))
    db.log_event("people_saved", "admin panel", f"{len(clean)} people")
    return _state()


def _code_for(name: str, taken: set[str]) -> str:
    base = re.sub(r"[^A-Z0-9]", "", name.upper())[:8] or "ITEM"
    code, n = base, 2
    while code in taken:
        code, n = f"{base}{n}", n + 1
    return code


@router.post("/api/items")
async def save_items(request: Request):
    _guard(request, write=True)
    rows = (await request.json()).get("items", [])
    try:
        clean, codes, names = [], set(), set()
        for i, r in enumerate(rows, 1):
            name, unit = " ".join(str(r.get("name", "")).split()), str(r.get("unit", "")).strip()
            if not name and not unit:
                continue
            where = f"Row {i} ({name or 'no name'})"
            if not name or not unit:
                raise Invalid(f"{where}: needs a name and a unit")
            if name.lower() in names:
                raise Invalid(f"{where}: {name} is listed twice")
            names.add(name.lower())
            try:
                rate = float(r.get("rate") or 0)
            except (TypeError, ValueError):
                raise Invalid(f"{where}: rate must be a number")
            if rate < 0:
                raise Invalid(f"{where}: rate cannot be negative")
            code = str(r.get("code") or "").strip().upper()
            if code in codes:
                raise Invalid(f"{where}: code {code} is used twice")
            if code:
                codes.add(code)
            clean.append({"code": code, "name": name, "unit": unit, "rate": rate, "count_daily": int(bool(r.get("count_daily")))})
        for c in clean:
            if not c["code"]:
                c["code"] = _code_for(c["name"], codes)
                codes.add(c["code"])
        removed = {x["code"] for x in db.query("SELECT code FROM items")} - codes
        used = [c for c in removed if db.query_one(
            "SELECT 1 AS x FROM counts WHERE item_code=? UNION SELECT 1 FROM issues WHERE item_code=? "
            "UNION SELECT 1 FROM recipes WHERE item_code=?", (c, c, c))]
        if used:
            names_used = [x["name"] for x in db.query(f"SELECT name FROM items WHERE code IN ({','.join('?' * len(used))})", used)]
            raise Invalid("These items are already in counts, kitchen entries or recipes, so they cannot be removed "
                          f"(untick 'Count daily' instead): {', '.join(names_used)}")
    except Invalid as exc:
        return _fail(exc)
    for c in removed:
        db.execute("DELETE FROM items WHERE code=?", (c,))
    for c in clean:
        db.execute("INSERT INTO items(code,name,unit,rate,count_daily) VALUES (?,?,?,?,?) ON CONFLICT(code) DO UPDATE SET "
                   "name=excluded.name, unit=excluded.unit, rate=excluded.rate, count_daily=excluded.count_daily",
                   (c["code"], c["name"], c["unit"], c["rate"], c["count_daily"]))
    db.log_event("items_saved", "admin panel", f"{len(clean)} items, {sum(c['count_daily'] for c in clean)} counted daily")
    return _state()


@router.post("/api/settings")
async def save_settings(request: Request):
    _guard(request, write=True)
    v = (await request.json()).get("settings", {})
    try:
        out = {"business_name": " ".join(str(v.get("business_name") or "").split()) or "My Restaurant",
               "house_rules": str(v.get("house_rules") or "").strip()[:4000]}
        for k, label in (("count_reminder_at", "Send count list at"), ("count_due_by", "Count due by"), ("report_at", "Email report at")):
            if not _TIME.match(str(v.get(k) or "")):
                raise Invalid(f"{label}: enter a time like 09:30")
            out[k] = v[k]
        emails = [e.strip() for e in (v.get("report_emails") or []) if str(e).strip()]
        bad = [e for e in emails if not _EMAIL.match(e)]
        if bad:
            raise Invalid(f"Not an email address: {', '.join(bad)}")
        out["report_emails"] = emails
    except Invalid as exc:
        return _fail(exc)
    for k, val in out.items():
        db.put(k, val)
    db.log_event("settings_saved", "admin panel")
    return _state()


@router.post("/api/recipes")
async def save_recipes(request: Request):
    _guard(request, write=True)
    try:
        n = sales.save_recipes((await request.json()).get("recipes", []))
    except sales.SalesError as exc:
        return _fail(exc)
    db.log_event("recipes_saved", "admin panel", f"{n} lines")
    return _state()


@router.post("/api/issues")
async def add_issue(request: Request):
    _guard(request, write=True)
    body = await request.json()
    lines = [{"item": r.get("item_code"), "qty": r.get("qty")} for r in body.get("lines", []) if r.get("item_code")]
    if not lines:
        return _fail(Invalid("Choose an item and enter the quantity."))
    result = stock.record_issue("admin panel", lines, str(body.get("note") or ""))
    if not result["saved"]:
        return _fail(Invalid("; ".join(result["problems"])))
    return _state()


@router.post("/api/issues/delete")
async def delete_issue(request: Request):
    _guard(request, write=True)
    try:
        stock.delete_issue(int((await request.json()).get("id")), "admin panel")
    except (stock.StockError, TypeError, ValueError) as exc:
        return _fail(exc)
    return _state()


@router.get("/api/report")
def report_json(request: Request, date: str):
    _guard(request)
    try:
        return stock.variance(date)
    except stock.StockError as exc:
        return _fail(exc)


@router.get("/api/report.xlsx")
def report_file(request: Request, date: str):
    _guard(request)
    try:
        data, _ = report.build_excel(date)
    except stock.StockError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{report.filename(date)}"'})


@router.post("/api/report/send")
async def report_send(request: Request):
    _guard(request, write=True)
    date = str((await request.json()).get("date") or "")
    try:
        result = report.email_report(date)
    except stock.StockError as exc:
        return _fail(exc)
    if result["status"] != "sent":
        return _fail(Invalid(result["error"]))
    return _state()


@router.post("/api/test-email")
async def test_email(request: Request):
    _guard(request, write=True)
    result = report.send_email(db.get("report_emails") or [], f"{db.get('business_name')}: test email from the stock agent",
                               "<p>This is a test. The daily kitchen variance report will arrive like this, with an Excel file attached.</p>")
    if result["status"] != "sent":
        return _fail(Invalid(result["error"]))
    return {"ok": True}


@router.post("/api/test-message")
async def test_message(request: Request):
    _guard(request, write=True)
    phone = db.normalize_phone((await request.json()).get("phone", ""))
    if not db.get_user(phone):
        return _fail(Invalid("That number is not an active person."))
    whatsapp.send(phone, "Test message from your stock agent. Reply 'hi' to start.")
    row = db.query_one("SELECT status, error FROM outbox WHERE phone=? ORDER BY id DESC", (phone,))
    return {"status": (row or {}).get("status", "sent"), "error": (row or {}).get("error")}


@router.get("/api/activity")
def activity(request: Request) -> dict:
    _guard(request)
    return {"events": db.query("SELECT at, actor, action, note FROM events ORDER BY id DESC LIMIT 200")}
