"""Web server: Twilio WhatsApp webhook, health check and signed downloads."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from twilio.request_validator import RequestValidator

from . import admin, agent, db, ops, scheduler, whatsapp
from .settings import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("agent")

EMPTY_TWIML = '<?xml version="1.0" encoding="UTF-8"?><Response></Response>'


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    sched = scheduler.start() if settings.run_scheduler else None
    yield
    if sched:
        sched.shutdown(wait=False)


app = FastAPI(title="Outlet Ops WhatsApp Agent", lifespan=lifespan)
app.include_router(admin.router)


PLACEHOLDER_PHONE = "+9198000000"


def setup_checks() -> dict:
    """What is still missing, for the person setting the agent up. No secret values."""
    users = db.query("SELECT phone FROM users WHERE active=1")
    placeholders = [u["phone"] for u in users if u["phone"].startswith(PLACEHOLDER_PHONE)]
    return {
        "claude_api_key": "ok" if settings.anthropic_api_key else "missing ANTHROPIC_API_KEY",
        "twilio_account": "ok" if settings.twilio_account_sid and settings.twilio_auth_token
        else "missing TWILIO_ACCOUNT_SID or TWILIO_AUTH_TOKEN",
        "twilio_sender": "ok" if settings.twilio_whatsapp_from.startswith("whatsapp:+")
        else "TWILIO_WHATSAPP_FROM must look like whatsapp:+14155238886",
        "public_url": "ok" if settings.public_base_url.startswith("https://")
        else "missing PUBLIC_BASE_URL (generate a domain first)",
        "webhook_to_paste_in_twilio": settings.public_base_url.rstrip("/") + "/whatsapp",
        "template_for_morning_messages": "ok" if settings.twilio_notice_content_sid
        else "not set yet (fine for testing; needed before going live)",
        "team_phone_numbers": "ok" if not placeholders
        else f"{len(placeholders)} sample numbers still in use; replace them in the admin panel (People)",
        "admin_panel": settings.public_base_url.rstrip("/") + "/admin" if settings.admin_password
        else "off: add an ADMIN_PASSWORD variable to turn it on",
        "petpooja": "connected" if settings.petpooja_enabled else "manual mode (daily upload file)",
    }


@app.get("/")
def home() -> dict:
    return {"message": "The WhatsApp agent is running. Open /health to see what is left to set up."}


@app.get("/health")
def health() -> dict:
    checks = setup_checks()
    ready = all(v == "ok" for k, v in checks.items()
                if k not in ("webhook_to_paste_in_twilio", "template_for_morning_messages", "petpooja", "admin_panel"))
    return {"ok": True, "ready_for_whatsapp": ready, "model": settings.claude_model, "setup": checks}


def process_inbound(phone: str, body: str, media: list[dict]) -> None:
    try:
        reply = agent.handle_message(phone, body, media)
    except Exception:
        log.exception("Failed to handle message from %s", phone)
        reply = "Sorry, something went wrong. Please try again."
    whatsapp.send(phone, reply)


@app.post("/whatsapp")
async def whatsapp_webhook(request: Request, background: BackgroundTasks) -> Response:
    form = await request.form()
    params = {k: str(v) for k, v in form.items()}
    if settings.validate_twilio_signature:
        validator = RequestValidator(settings.twilio_auth_token)
        url = settings.public_base_url.rstrip("/") + "/whatsapp"
        if not validator.validate(url, params, request.headers.get("X-Twilio-Signature", "")):
            raise HTTPException(status_code=403, detail="Invalid Twilio signature")
    phone = db.normalize_phone(params.get("From", ""))
    whatsapp.mark_inbound(phone)
    body = params.get("ButtonPayload") or params.get("Body", "")
    media = [
        {"url": params[f"MediaUrl{i}"], "type": params.get(f"MediaContentType{i}", "")}
        for i in range(int(params.get("NumMedia", "0") or 0))
        if params.get(f"MediaUrl{i}")
    ]
    # Twilio expects an answer within 15 seconds; Claude may take longer, so we
    # reply right away and send the real answer through the REST API.
    background.add_task(process_inbound, phone, body, media)
    return Response(content=EMPTY_TWIML, media_type="application/xml")


@app.get("/exports/{name}")
def download_export(name: str, sig: str = "") -> FileResponse:
    path = f"/exports/{name}"
    if "/" in name or ".." in name or not ops.check_link(path, sig):
        raise HTTPException(status_code=403, detail="Invalid link")
    file = Path(settings.export_dir) / name
    if not file.exists():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(file, filename=name)
