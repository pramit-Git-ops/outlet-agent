"""Web server: WhatsApp webhook (Twilio), Petpooja sales webhook, admin panel and setup check."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request, Response
from twilio.request_validator import RequestValidator

from . import admin, agent, db, petpooja, sales, scheduler, stock, whatsapp
from .settings import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("agent")

EMPTY_TWIML = '<?xml version="1.0" encoding="UTF-8"?><Response></Response>'


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    sched = scheduler.start() if settings.run_scheduler else None
    yield
    if sched:
        sched.shutdown(wait=False)


app = FastAPI(title="Kitchen stock agent", lifespan=lifespan)
app.include_router(admin.router)


def setup_checks() -> dict:
    """What is still missing, for the person setting the agent up. No secret values."""
    users = db.query("SELECT roles FROM users WHERE active=1")
    has = lambda role: any(role in u["roles"].split(",") for u in users)  # noqa: E731
    pp = sales.status()
    return {
        "claude_api_key": "ok" if settings.anthropic_api_key else "missing ANTHROPIC_API_KEY",
        "twilio": "ok" if settings.twilio_account_sid and settings.twilio_auth_token and settings.twilio_whatsapp_from.startswith("whatsapp:+")
        else "missing TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN or TWILIO_WHATSAPP_FROM",
        "admin_panel": "ok" if settings.admin_password else "missing ADMIN_PASSWORD",
        "email": "ok" if settings.brevo_api_key and settings.email_from else "missing BREVO_API_KEY or EMAIL_FROM",
        "administrator": "ok" if has("admin") else "add an administrator in the admin panel (People)",
        "stock_keeper": "ok" if has("stock_keeper") else "add a stock keeper in the admin panel (People)",
        "items_to_count": "ok" if stock.count_list() else "tick 'Count daily' for items in the admin panel (Items)",
        "report_emails": "ok" if db.get("report_emails") else "add email addresses in the admin panel (Daily report)",
        "petpooja_inventory": "ok" if settings.petpooja_ready else
        "missing PETPOOJA_APP_KEY, PETPOOJA_APP_SECRET, PETPOOJA_ACCESS_TOKEN or PETPOOJA_MENU_SHARING_CODE",
        "recipes": "ok" if pp["recipes"] or petpooja.use_for_ideal() else "add recipes in the admin panel (Recipes)",
        "petpooja_last_sync": _last_sync(),
        "petpooja_bills": f"{pp['bills_received']} received" if pp["bills_received"] else "none received yet",
        "whatsapp_webhook_for_twilio": settings.public_base_url.rstrip("/") + "/whatsapp",
        "admin_panel_address": settings.public_base_url.rstrip("/") + "/admin",
    }


def _last_sync() -> str:
    last = petpooja.status()["last_sync"]
    if not last:
        return "not yet"
    return last["at"][:16].replace("T", " ") + (" with problems: " + "; ".join(last["errors"]) if last["errors"] else " ok")


@app.get("/")
def home() -> dict:
    return {"message": "The kitchen stock agent is running. Open /health for the setup check and /admin for the admin panel."}


@app.get("/health")
def health() -> dict:
    checks = setup_checks()
    ready = all(v == "ok" for k, v in checks.items() if k not in ("petpooja_bills", "petpooja_last_sync", "whatsapp_webhook_for_twilio", "admin_panel_address"))
    return {"ok": True, "version": "2 (kitchen stock)", "everything_set_up": ready, "setup": checks}


def process_inbound(phone: str, body: str, media: list[dict]) -> None:
    try:
        reply = agent.handle_message(phone, body, media)
    except Exception:
        log.exception("Failed to handle message from %s", phone)
        reply = "Sorry, something went wrong. Please try again."
    whatsapp.send(phone, reply)


@app.post("/whatsapp")
async def whatsapp_webhook(request: Request, background: BackgroundTasks) -> Response:
    form = await request.form()
    params = {k: str(v) for k, v in form.items()}
    if settings.validate_twilio_signature:
        validator = RequestValidator(settings.twilio_auth_token)
        url = settings.public_base_url.rstrip("/") + "/whatsapp"
        if not validator.validate(url, params, request.headers.get("X-Twilio-Signature", "")):
            raise HTTPException(status_code=403, detail="Invalid Twilio signature")
    phone = db.normalize_phone(params.get("From", ""))
    whatsapp.mark_inbound(phone)
    body = params.get("ButtonPayload") or params.get("Body", "")
    media = [{"url": params[f"MediaUrl{i}"], "type": params.get(f"MediaContentType{i}", "")}
             for i in range(int(params.get("NumMedia", "0") or 0)) if params.get(f"MediaUrl{i}")]
    # Twilio wants an answer within 15 seconds; the real reply goes out through the REST API.
    background.add_task(process_inbound, phone, body, media)
    return Response(content=EMPTY_TWIML, media_type="application/xml")


@app.post("/petpooja/orders/{token}")
async def petpooja_orders(token: str, request: Request) -> dict:
    """Petpooja Global API: every printed bill is pushed here as JSON."""
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Expected JSON")
    if not isinstance(payload, dict) or not sales.token_ok(token, payload):
        raise HTTPException(status_code=403, detail="Invalid token")
    try:
        result = sales.record_order(payload)
    except sales.SalesError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    log.info("Petpooja bill %s", result)
    return {"status": "ok", **result}
