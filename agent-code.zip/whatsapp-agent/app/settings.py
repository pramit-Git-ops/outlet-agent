"""Environment variables and the YAML starting configuration."""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(ROOT / ".env")


@dataclass
class Settings:
    # Claude
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    claude_model: str = os.getenv("CLAUDE_MODEL", "claude-opus-5-5")
    claude_effort: str = os.getenv("CLAUDE_EFFORT", "low")

    # Twilio WhatsApp
    twilio_account_sid: str = os.getenv("TWILIO_ACCOUNT_SID", "")
    twilio_auth_token: str = os.getenv("TWILIO_AUTH_TOKEN", "")
    twilio_whatsapp_from: str = os.getenv("TWILIO_WHATSAPP_FROM", "")  # e.g. whatsapp:+14155238886
    # Approved WhatsApp template (Twilio Content SID) used when the person has
    # not messaged the agent in the last 24 hours. Body: "{{1}}" (one variable).
    twilio_notice_content_sid: str = os.getenv("TWILIO_NOTICE_CONTENT_SID", "")
    validate_twilio_signature: bool = os.getenv("VALIDATE_TWILIO_SIGNATURE", "true").lower() == "true"

    # Public URL of this server (used for Twilio signature checks and links).
    # On Railway it is filled in automatically from the generated domain.
    public_base_url: str = os.getenv("PUBLIC_BASE_URL") or (
        f"https://{os.environ['RAILWAY_PUBLIC_DOMAIN']}" if os.getenv("RAILWAY_PUBLIC_DOMAIN") else "http://localhost:8000"
    )
    # Secret used to sign download links (Tally / Petpooja export files).
    # If not set, it is derived from the Twilio auth token, which is also secret.
    link_secret: str = os.getenv("LINK_SECRET", "")

    # Password for the web admin panel at /admin (panel is off while blank)
    admin_password: str = os.getenv("ADMIN_PASSWORD", "")

    # Petpooja (leave blank to run in manual mode)
    petpooja_base_url: str = os.getenv("PETPOOJA_BASE_URL", "")
    petpooja_app_key: str = os.getenv("PETPOOJA_APP_KEY", "")
    petpooja_app_secret: str = os.getenv("PETPOOJA_APP_SECRET", "")
    petpooja_access_token: str = os.getenv("PETPOOJA_ACCESS_TOKEN", "")
    # One restID per outlet: "MAIN=abc123,BAR1=def456"
    petpooja_rest_ids: str = os.getenv("PETPOOJA_REST_IDS", "")

    database_path: str = os.getenv("DATABASE_PATH", str(ROOT / "data" / "agent.db"))
    export_dir: str = os.getenv("EXPORT_DIR", str(ROOT / "data" / "exports"))
    config_path: str = os.getenv("CONFIG_PATH", str(ROOT / "config.yaml"))
    run_scheduler: bool = os.getenv("RUN_SCHEDULER", "true").lower() == "true"

    config: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.config = load_config(self.config_path)
        if not self.link_secret:
            seed = self.twilio_auth_token or self.anthropic_api_key or "dev"
            self.link_secret = hashlib.sha256(f"links:{seed}".encode()).hexdigest()

    @property
    def petpooja_enabled(self) -> bool:
        return bool(self.petpooja_base_url and self.petpooja_access_token)

    def rest_id(self, outlet: str) -> str:
        pairs = dict(
            p.split("=", 1) for p in self.petpooja_rest_ids.split(",") if "=" in p
        )
        return pairs.get(outlet, "")


def load_config(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


settings = Settings()
