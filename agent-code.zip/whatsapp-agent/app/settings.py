"""Environment variables (set in Railway under Variables). Everything else is
set by the administrator in the admin panel and kept in the database."""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(ROOT / ".env")


@dataclass
class Settings:
    # Claude
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    claude_model: str = os.getenv("CLAUDE_MODEL", "claude-opus-5-5")
    claude_effort: str = os.getenv("CLAUDE_EFFORT", "low")

    # Twilio WhatsApp
    twilio_account_sid: str = os.getenv("TWILIO_ACCOUNT_SID", "")
    twilio_auth_token: str = os.getenv("TWILIO_AUTH_TOKEN", "")
    twilio_whatsapp_from: str = os.getenv("TWILIO_WHATSAPP_FROM", "")  # e.g. whatsapp:+14155238886
    # Approved WhatsApp template (Twilio Content SID, body "{{1}}") used when the
    # person has not messaged the agent in the last 24 hours.
    twilio_notice_content_sid: str = os.getenv("TWILIO_NOTICE_CONTENT_SID", "")
    validate_twilio_signature: bool = os.getenv("VALIDATE_TWILIO_SIGNATURE", "true").lower() == "true"

    # Public address of this server; on Railway it comes from the generated domain.
    public_base_url: str = os.getenv("PUBLIC_BASE_URL") or (
        f"https://{os.environ['RAILWAY_PUBLIC_DOMAIN']}" if os.getenv("RAILWAY_PUBLIC_DOMAIN") else "http://localhost:8000"
    )
    # Signs download links and the Petpooja address. Derived from the Twilio token if blank.
    link_secret: str = os.getenv("LINK_SECRET", "")

    # Admin panel at /admin (off while blank)
    admin_password: str = os.getenv("ADMIN_PASSWORD", "")

    # Email for the daily report, sent through Brevo's web API (Railway blocks
    # ordinary SMTP email on its cheaper plans).
    brevo_api_key: str = os.getenv("BREVO_API_KEY", "")
    email_from: str = os.getenv("EMAIL_FROM", "")          # a sender address verified in Brevo
    email_from_name: str = os.getenv("EMAIL_FROM_NAME", "Stock agent")

    # Petpooja live sales: secret part of the webhook address (derived if blank)
    petpooja_webhook_token: str = os.getenv("PETPOOJA_WEBHOOK_TOKEN", "")

    # Petpooja Inventory API: stock, purchases, transfers to the kitchen and
    # consumption by Petpooja's own recipes. The four values come from Petpooja.
    petpooja_app_key: str = os.getenv("PETPOOJA_APP_KEY", "")
    petpooja_app_secret: str = os.getenv("PETPOOJA_APP_SECRET", "")
    petpooja_access_token: str = os.getenv("PETPOOJA_ACCESS_TOKEN", "")
    petpooja_menu_sharing_code: str = os.getenv("PETPOOJA_MENU_SHARING_CODE", "")
    petpooja_api_base: str = os.getenv("PETPOOJA_API_BASE", "https://api.petpooja.com/V1/thirdparty")

    database_path: str = os.getenv("DATABASE_PATH", str(ROOT / "data" / "stock_agent.db"))
    old_database_path: str = os.getenv("OLD_DATABASE_PATH", str(ROOT / "data" / "agent.db"))
    timezone: str = os.getenv("TZ_NAME", "Asia/Kolkata")
    run_scheduler: bool = os.getenv("RUN_SCHEDULER", "true").lower() == "true"

    @property
    def petpooja_ready(self) -> bool:
        return all((self.petpooja_app_key, self.petpooja_app_secret, self.petpooja_access_token, self.petpooja_menu_sharing_code))

    def __post_init__(self) -> None:
        if not self.link_secret:
            seed = self.twilio_auth_token or self.anthropic_api_key or "dev"
            self.link_secret = hashlib.sha256(f"links:{seed}".encode()).hexdigest()


settings = Settings()
