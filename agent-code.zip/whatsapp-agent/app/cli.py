"""Command-line helpers: python -m app.cli <command>"""
from __future__ import annotations

import sys

from . import db, ops, petpooja, scheduler


def main() -> None:
    db.init_db()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    if cmd == "sync-items":
        outlet = sys.argv[2] if len(sys.argv) > 2 else (db.cfg("outlets", [{}])[0] or {}).get("code", "")
        items = petpooja.adapter().get_items(outlet)
        for it in items:
            db.execute(
                "INSERT INTO items(code,name,unit,category,rate,petpooja_code) VALUES (?,?,?,?,0,?) "
                "ON CONFLICT(code) DO UPDATE SET name=excluded.name, unit=excluded.unit, petpooja_code=excluded.petpooja_code",
                (it["code"], it["name"], it["unit"], "petpooja", it["code"]),
            )
        print(f"Synced {len(items)} items from Petpooja ({petpooja.adapter().name}).")
    elif cmd == "send-count-sheets":
        scheduler.send_count_sheets()
        print("Count sheets sent.")
    elif cmd == "stock-report":
        print(ops.report_text(ops.consumption_report(sys.argv[2] if len(sys.argv) > 2 else None)))
    elif cmd == "chase":
        print(f"Chased {ops.chase_overdue()} requests.")
    else:
        print("Commands: sync-items [outlet] | send-count-sheets | stock-report [YYYY-MM-DD] | chase")


if __name__ == "__main__":
    main()
