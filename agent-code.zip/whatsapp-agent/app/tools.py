"""Tools Claude can use, and the dispatcher that runs them with the sender's permissions."""
from __future__ import annotations

import json
from typing import Any

from . import db, report, sales, stock

LINE = {"type": "object",
        "properties": {"item": {"type": "string", "description": "Item name or code"}, "qty": {"type": "number"}},
        "required": ["item", "qty"]}
DATE = {"type": "string", "description": "YYYY-MM-DD; leave out for today"}


def _t(name: str, description: str, properties: dict, required: list[str] | None = None) -> dict:
    return {"name": name, "description": description,
            "input_schema": {"type": "object", "properties": properties, "required": required or []}}


TOOLS = [
    _t("search_items", "Find items in the item list by name or code.", {"query": {"type": "string"}}, ["query"]),
    _t("count_list", "The items the stock keeper must count in the kitchen today, and which are already counted.", {}),
    _t("save_count", "Save kitchen count quantities for today. Send what the stock keeper gave; set finished=true "
       "only when they say they have finished.",
       {"lines": {"type": "array", "items": LINE}, "finished": {"type": "boolean"}}, ["lines"]),
    _t("record_issue", "Record stock sent to the kitchen (for example 10 kg chicken issued today).",
       {"lines": {"type": "array", "items": LINE}, "note": {"type": "string"}}, ["lines"]),
    _t("kitchen_stock", "How much of an item (or every item) is in the kitchen: last count plus stock sent since.",
       {"item": {"type": "string"}}),
    _t("variance_report", "Actual vs ideal consumption for a finished count day, with variance quantity and amount.",
       {"date": DATE}),
    _t("email_report", "Administrator: email the Excel variance report for a day to the report list again.",
       {"date": DATE}),
    _t("sales_report", "Bills and dishes sold that Petpooja reported for a day.", {"date": DATE}),
]


def run_tool(name: str, a: dict[str, Any], user: dict) -> Any:
    handlers = {
        "search_items": lambda: stock.find_items(a["query"]),
        "count_list": lambda: _count_list(user),
        "save_count": lambda: _save_count(user, a.get("lines", []), bool(a.get("finished"))),
        "record_issue": lambda: _record_issue(user, a.get("lines", []), a.get("note", "")),
        "kitchen_stock": lambda: stock.kitchen_stock(a.get("item")),
        "variance_report": lambda: _variance(user, a.get("date")),
        "email_report": lambda: _email(user, a.get("date")),
        "sales_report": lambda: _sales(user, a.get("date")),
    }
    if name not in handlers:
        return {"error": f"Unknown tool {name}"}
    try:
        return handlers[name]()
    except (stock.StockError, sales.SalesError) as exc:
        return {"error": str(exc)}


def _count_list(user: dict) -> dict:
    stock.require(user, "stock_keeper")
    counted = {r["item_code"]: r["qty"] for r in db.query("SELECT item_code, qty FROM counts WHERE count_date=?", (stock.today(),))}
    day = stock.day_status(stock.today())
    return {"date": stock.today(), "status": day["status"] if day else "not started",
            "items": [{**i, "counted": counted.get(i["code"])} for i in stock.count_list()]}


def _save_count(user: dict, lines: list, finished: bool) -> dict:
    result = stock.submit_count(user, lines, finished)
    if result.get("status") == "complete" and "note" not in result:
        sent = report.send_if_due()
        result["report"] = ("emailed to " + ", ".join(db.get("report_emails") or [])) if sent and sent["status"] == "sent" \
            else f"will be emailed at {db.get('report_at')}" if sent is None else f"email failed: {sent['error']}"
    return result


def _record_issue(user: dict, lines: list, note: str) -> dict:
    stock.require(user, "stock_keeper")
    return stock.record_issue(user["name"], lines, note)


def _variance(user: dict, date: str | None) -> dict:
    stock.require(user, "manager", "stock_keeper")
    date = date or (stock.last_complete() or {}).get("count_date")
    if not date:
        return {"error": "No finished count yet."}
    rep = stock.variance(date)
    rep.pop("dishes_sold", None)
    return rep


def _email(user: dict, date: str | None) -> dict:
    stock.require(user, "admin")
    date = date or (stock.last_complete() or {}).get("count_date")
    if not date:
        return {"error": "No finished count yet."}
    return report.email_report(date)


def _sales(user: dict, date: str | None) -> dict:
    stock.require(user, "manager")
    return sales.sales_summary(date)


def to_json(result: Any) -> str:
    return json.dumps(result, default=str, ensure_ascii=False)
