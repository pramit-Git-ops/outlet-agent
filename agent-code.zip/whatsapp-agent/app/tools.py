"""Tool definitions given to Claude, and the dispatcher that runs them."""
from __future__ import annotations

import json
from typing import Any, Callable

from . import db, ops, sales

LINE = {
    "type": "object",
    "properties": {
        "item": {"type": "string", "description": "Item name or code as in the item master"},
        "qty": {"type": "number"},
        "unit": {"type": "string"},
    },
    "required": ["item", "qty"],
}

BILL_LINE = {
    "type": "object",
    "properties": {
        "item": {"type": "string"},
        "qty": {"type": "number"},
        "unit": {"type": "string"},
        "rate": {"type": "number", "description": "Rate per unit before tax"},
        "amount": {"type": "number", "description": "Line amount before tax"},
    },
    "required": ["item", "qty", "rate"],
}


def _t(name: str, description: str, properties: dict, required: list[str] | None = None) -> dict:
    return {
        "name": name,
        "description": description,
        "input_schema": {"type": "object", "properties": properties, "required": required or []},
    }


TOOLS = [
    _t("search_items", "Find items in the item master by name or code. Use before naming any item.",
       {"query": {"type": "string"}}, ["query"]),
    _t("get_request_format",
       "List the request types for a department and, when request_type is given, the fields that format needs.",
       {"department": {"type": "string", "enum": ["kitchen", "bar", "housekeeping", "store"]},
        "request_type": {"type": "string"}}, ["department"]),
    _t("create_requisition",
       "Create a requisition once all required fields are known and the sender has confirmed the summary. "
       "Routing to approvers and purchase is automatic.",
       {"department": {"type": "string"}, "request_type": {"type": "string"},
        "lines": {"type": "array", "items": LINE},
        "fields": {"type": "object", "description": "Values for the format's fields, keyed by field name",
                   "additionalProperties": True},
        "urgent": {"type": "boolean"}},
       ["department", "request_type", "lines"]),
    _t("list_pending", "Everything waiting on the sender: approvals, orders to place, deliveries, bills to verify, their own open requests.", {}),
    _t("get_requisition", "Show one requisition with its lines and status.",
       {"requisition_id": {"type": "integer"}}, ["requisition_id"]),
    _t("decide_requisition", "Approve or reject a requisition, optionally changing quantities before approving.",
       {"requisition_id": {"type": "integer"}, "decision": {"type": "string", "enum": ["approve", "reject"]},
        "note": {"type": "string"},
        "quantity_changes": {"type": "array", "items": {"type": "object", "properties": {
            "item": {"type": "string"}, "qty": {"type": "number"}}, "required": ["item", "qty"]}}},
       ["requisition_id", "decision"]),
    _t("mark_ordered", "Purchase manager: record that an approved requisition was ordered from a vendor.",
       {"requisition_id": {"type": "integer"}, "vendor": {"type": "string"},
        "expected_delivery": {"type": "string"}}, ["requisition_id", "vendor"]),
    _t("record_receipt",
       "Record goods received for an ordered requisition. Leave 'received' empty when everything arrived as "
       "ordered; otherwise list every item with the quantity actually received.",
       {"requisition_id": {"type": "integer"}, "received": {"type": "array", "items": LINE}}, ["requisition_id"]),
    _t("push_to_petpooja", "Purchase manager: record a received purchase in Petpooja. Give the requisition or bill number.",
       {"requisition_id": {"type": "integer"}, "bill_id": {"type": "integer"}}),
    _t("record_issue", "Store keeper: record stock issued from the main store to a department.",
       {"department": {"type": "string", "enum": ["kitchen", "bar", "housekeeping"]},
        "lines": {"type": "array", "items": LINE}, "note": {"type": "string"}}, ["department", "lines"]),
    _t("get_count_sheet", "The list of items to count at a location this morning.",
       {"location": {"type": "string", "enum": ["store", "kitchen", "bar", "housekeeping"]}}, ["location"]),
    _t("submit_count",
       "Save counted quantities for a location. Call with final=false for partial batches and final=true when "
       "the counter says they are done.",
       {"location": {"type": "string", "enum": ["store", "kitchen", "bar", "housekeeping"]},
        "lines": {"type": "array", "items": LINE},
        "rooms_occupied": {"type": "integer", "description": "Housekeeping only: rooms occupied last night"},
        "final": {"type": "boolean"}}, ["location", "lines"]),
    _t("stock_report", "Consumption and leakage report for a count date (default today).",
       {"date": {"type": "string", "description": "YYYY-MM-DD"}}),
    _t("stock_on_hand", "How much of an item (or every item) is in stock now, per department: the last morning "
       "count plus stock received or issued since.",
       {"item": {"type": "string", "description": "Item name or code; leave out for every item"},
        "department": {"type": "string", "description": "store, kitchen, bar, housekeeping; leave out for all"}}),
    _t("sales_report", "Sales Petpooja reported for a day (default today): bills, total, cancelled, by outlet, "
       "top dishes, and dishes sold that have no recipe yet.",
       {"date": {"type": "string", "description": "YYYY-MM-DD"}}),
    _t("record_bill", "Record a supplier bill read from a photo or PDF, and match it to the order and receipt.",
       {"vendor": {"type": "string"}, "gstin": {"type": "string"}, "invoice_no": {"type": "string"},
        "invoice_date": {"type": "string", "description": "YYYY-MM-DD"},
        "lines": {"type": "array", "items": BILL_LINE},
        "taxable": {"type": "number"}, "cgst": {"type": "number"}, "sgst": {"type": "number"},
        "igst": {"type": "number"}, "total": {"type": "number"},
        "requisition_id": {"type": "integer", "description": "If the sender said which requisition it belongs to"}},
       ["vendor", "invoice_no", "invoice_date", "lines", "taxable", "total"]),
    _t("override_bill", "Purchase manager: accept a bill with differences, giving the reason.",
       {"bill_id": {"type": "integer"}, "reason": {"type": "string"}}, ["bill_id", "reason"]),
    _t("accounts_review", "Accounts: mark a bill verified, or raise a query back to purchase.",
       {"bill_id": {"type": "integer"}, "decision": {"type": "string", "enum": ["verified", "query"]},
        "note": {"type": "string"}}, ["bill_id", "decision"]),
    _t("post_to_tally", "Accounts: send all verified bills to Tally (import file link, or direct push if configured).", {}),
    _t("purchases_summary", "Purchases by department and bills by vendor for today or this month.",
       {"period": {"type": "string", "enum": ["today", "month"]}}),
    _t("set_variance_threshold",
       "Admin or purchase manager: set the allowed difference between counted use and Petpooja's figure for one "
       "product, as a percent or a quantity in the item's unit, and optionally who else gets its alerts.",
       {"item": {"type": "string"}, "percent": {"type": "number"}, "quantity": {"type": "number"},
        "alert_to": {"type": "array", "items": {"type": "string"}, "description": "Phone numbers"}}, ["item"]),
    _t("vendor_pending", "Accounts or purchase: the amount pending for a vendor, fetched from Petpooja when connected.",
       {"vendor": {"type": "string"}}, ["vendor"]),
    _t("record_payment",
       "Accounts: record a payment made to a vendor. The purchase manager is asked to enter it in Petpooja.",
       {"vendor": {"type": "string"}, "amount": {"type": "number"},
        "mode": {"type": "string", "description": "NEFT, RTGS, UPI, cheque, cash"},
        "reference": {"type": "string", "description": "UTR, cheque number or transaction id"},
        "paid_on": {"type": "string", "description": "YYYY-MM-DD, default today"},
        "invoices": {"type": "array", "items": {"type": "string"}}}, ["vendor", "amount", "mode"]),
    _t("confirm_payment_updated", "Purchase manager: confirm a recorded payment has been entered in Petpooja.",
       {"payment_id": {"type": "integer"}}, ["payment_id"]),
    _t("list_delays", "Everything that has missed its deadline right now (approvals, orders, deliveries, "
       "stock counts, bills, Tally, payments). For the cost controller, stakeholders and managers.", {}, []),
    _t("get_settings", "Read current settings before changing them.",
       {"section": {"type": "string", "enum": sorted(ops.EDITABLE) + ["users", "items"]}},
       ["section"]),
    _t("update_settings",
       "Admin: replace a whole settings section with a new JSON value (read it first, change only what was asked).",
       {"section": {"type": "string", "enum": sorted(ops.EDITABLE)},
        "value_json": {"type": "string"}}, ["section", "value_json"]),
    _t("save_user", "Admin: add or update a person and their roles.",
       {"phone": {"type": "string", "description": "International format, e.g. +919812345678"},
        "name": {"type": "string"},
        "roles": {"type": "array", "items": {"type": "string"},
                  "description": "Roles: admin, requester, approver, purchase_manager, store_keeper, counter, "
                                 "accounts, cost_controller, stakeholder, or an extra role the admin added"},
        "department": {"type": "string"}, "outlet": {"type": "string"}}, ["phone", "name", "roles"]),
    _t("deactivate_user", "Admin: remove a person's access.", {"phone": {"type": "string"}}, ["phone"]),
    _t("save_item", "Admin or purchase manager: add or update an item in the item master.",
       {"code": {"type": "string"}, "name": {"type": "string"}, "unit": {"type": "string"},
        "category": {"type": "string"}, "rate": {"type": "number"}}, ["code", "name", "unit", "category"]),
]


def run_tool(name: str, args: dict, user: dict, media: dict | None = None) -> Any:
    """Execute one tool call for this user. Returns a JSON-serialisable result."""
    a = args or {}
    handlers: dict[str, Callable[[], Any]] = {
        "search_items": lambda: {"items": ops.find_items(a["query"])},
        "get_request_format": lambda: (
            ops.get_format(a["department"], a["request_type"]) if a.get("request_type")
            else {"department": a["department"], "request_types": ops.request_types(a["department"])}),
        "create_requisition": lambda: ops.create_requisition(
            user, a["department"], a["request_type"], a["lines"], a.get("fields"), bool(a.get("urgent"))),
        "list_pending": lambda: ops.pending_for(user),
        "get_requisition": lambda: {"summary": ops.req_summary(int(a["requisition_id"]))},
        "decide_requisition": lambda: ops.decide_requisition(
            user, int(a["requisition_id"]), a["decision"], a.get("note", ""), a.get("quantity_changes")),
        "mark_ordered": lambda: ops.mark_ordered(user, int(a["requisition_id"]), a["vendor"], a.get("expected_delivery", "")),
        "record_receipt": lambda: ops.record_receipt(user, int(a["requisition_id"]), a.get("received") or None),
        "push_to_petpooja": lambda: ops.push_to_petpooja(user, a.get("requisition_id"), a.get("bill_id")),
        "record_issue": lambda: ops.record_issue(user, a["department"], a["lines"], a.get("note", "")),
        "get_count_sheet": lambda: ops.count_sheet(a["location"]),
        "submit_count": lambda: ops.submit_count(user, a["location"], a["lines"], a.get("rooms_occupied"), a.get("final", True)),
        "stock_report": lambda: _stock_report(user, a.get("date")),
        "sales_report": lambda: _sales_report(user, a.get("date")),
        "stock_on_hand": lambda: _stock_on_hand(user, a.get("item"), a.get("department")),
        "record_bill": lambda: ops.record_bill(
            user, a["vendor"], a["invoice_no"], a["invoice_date"], a["lines"], float(a["taxable"]), float(a["total"]),
            float(a.get("cgst") or 0), float(a.get("sgst") or 0), float(a.get("igst") or 0), a.get("gstin", ""),
            a.get("requisition_id"), (media or {}).get("url", ""), (media or {}).get("type", "")),
        "override_bill": lambda: ops.override_bill(user, int(a["bill_id"]), a["reason"]),
        "accounts_review": lambda: ops.accounts_review(user, int(a["bill_id"]), a["decision"], a.get("note", "")),
        "post_to_tally": lambda: ops.tally_post(user),
        "purchases_summary": lambda: ops.purchases_summary(a.get("period", "month")),
        "set_variance_threshold": lambda: ops.set_variance_threshold(
            user, a["item"], a.get("percent"), a.get("quantity"), a.get("alert_to")),
        "vendor_pending": lambda: ops.vendor_pending(user, a["vendor"]),
        "record_payment": lambda: ops.record_payment(
            user, a["vendor"], float(a["amount"]), a["mode"], a.get("reference", ""), a.get("paid_on", ""), a.get("invoices")),
        "confirm_payment_updated": lambda: ops.confirm_payment_updated(user, int(a["payment_id"])),
        "list_delays": lambda: ops.list_delays(user),
        "get_settings": lambda: ops.get_settings(a["section"]),
        "update_settings": lambda: ops.update_settings(user, a["section"], a["value_json"]),
        "save_user": lambda: ops.upsert_user(user, a["phone"], a["name"], a["roles"], a.get("department", ""), a.get("outlet", "")),
        "deactivate_user": lambda: ops.deactivate_user(user, a["phone"]),
        "save_item": lambda: ops.upsert_item(user, a["code"], a["name"], a["unit"], a["category"], float(a.get("rate") or 0)),
    }
    if name not in handlers:
        return {"error": f"Unknown tool {name}"}
    try:
        return handlers[name]()
    except ops.OpsError as exc:
        return {"error": str(exc)}
    except KeyError as exc:
        return {"error": f"Missing required input {exc}"}


def _stock_report(user: dict, date: str | None) -> dict:
    ops.require(user, "approver", "store_keeper", "purchase_manager", "accounts", "cost_controller", "stakeholder")
    report = ops.consumption_report(date)
    return {"text": ops.report_text(report), "detail": report}


def _stock_on_hand(user: dict, item: str | None, department: str | None) -> dict:
    ops.require(user, "approver", "store_keeper", "purchase_manager", "accounts", "cost_controller", "stakeholder", "counter")
    return ops.stock_on_hand(item, department)


def _sales_report(user: dict, date: str | None) -> dict:
    ops.require(user, "approver", "purchase_manager", "accounts", "cost_controller", "stakeholder")
    return {**sales.sales_summary(date), "dishes_without_recipe": sales.dishes_without_recipe()[:10]}


def to_json(result: Any) -> str:
    return json.dumps(result, default=str, ensure_ascii=False)


__all__ = ["TOOLS", "run_tool", "to_json", "db"]
