"""Petpooja Inventory connection behind one small interface.

Two adapters:
  * ManualAdapter (default): no API needed. The agent keeps every record and
    writes a daily Petpooja-ready CSV that the purchase manager can upload.
  * HttpAdapter: used automatically once PETPOOJA_BASE_URL and
    PETPOOJA_ACCESS_TOKEN are set in .env. Endpoint paths and response field
    names come from config.yaml (petpooja section), so matching Petpooja's
    documentation is a config change, not a code change.
"""
from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Protocol

import httpx2 as httpx

from . import db
from .settings import settings

log = logging.getLogger(__name__)


class PetpoojaAdapter(Protocol):
    name: str

    def push_purchase(self, purchase: dict) -> str: ...
    def get_items(self, outlet: str) -> list[dict]: ...
    def get_expected_consumption(self, outlet: str, start: str, end: str) -> dict[str, dict]: ...
    def get_vendor_payables(self, outlet: str, vendor: str) -> list[dict] | None: ...


class ManualAdapter:
    name = "manual"

    def push_purchase(self, purchase: dict) -> str:
        export_dir = Path(settings.export_dir)
        export_dir.mkdir(parents=True, exist_ok=True)
        day = db.now().strftime("%Y-%m-%d")
        path = export_dir / f"petpooja_purchases_{day}.csv"
        new = not path.exists()
        with path.open("a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["reference", "outlet", "vendor", "invoice_no", "invoice_date",
                            "item_code", "item_name", "qty", "unit", "rate", "amount"])
            for line in purchase["lines"]:
                w.writerow([purchase["reference"], purchase.get("outlet"), purchase.get("vendor"),
                            purchase.get("invoice_no"), purchase.get("invoice_date"),
                            line.get("item_code"), line["item_name"], line["qty"], line.get("unit"),
                            line.get("rate"), round(line["qty"] * (line.get("rate") or 0), 2)])
        return f"MANUAL-{purchase['reference']}"

    def get_items(self, outlet: str) -> list[dict]:
        return []

    def get_expected_consumption(self, outlet: str, start: str, end: str) -> dict[str, dict]:
        # Without the API there is no recipe-based expected figure.
        return {}

    def get_vendor_payables(self, outlet: str, vendor: str) -> list[dict] | None:
        # None means "not available": the agent falls back to its own bill records.
        return None


class HttpAdapter:
    name = "petpooja_api"

    def __init__(self) -> None:
        self.cfg = settings.config.get("petpooja", {})
        self.endpoints = self.cfg.get("endpoints", {})
        self.keys = self.cfg.get("response_keys", {})

    def _post(self, endpoint_key: str, outlet: str, payload: dict) -> dict:
        body = {
            "app_key": settings.petpooja_app_key,
            "app_secret": settings.petpooja_app_secret,
            "access_token": settings.petpooja_access_token,
            "restID": settings.rest_id(outlet),
            **payload,
        }
        headers = {
            "app-key": settings.petpooja_app_key,
            "app-secret": settings.petpooja_app_secret,
            "access-token": settings.petpooja_access_token,
        }
        url = settings.petpooja_base_url.rstrip("/") + self.endpoints[endpoint_key]
        with httpx.Client(timeout=30) as client:
            resp = client.post(url, json=body, headers=headers)
            resp.raise_for_status()
            return resp.json()

    def push_purchase(self, purchase: dict) -> str:
        data = self._post("push_purchase", purchase.get("outlet", ""), {"purchase": purchase})
        return str(data.get(self.keys.get("purchase_ref", "purchase_id")) or data)

    def get_items(self, outlet: str) -> list[dict]:
        data = self._post("items", outlet, {})
        rows = data.get(self.keys.get("items_list", "data"), [])
        return [
            {
                "code": str(r.get(self.keys.get("item_code", "item_code"))),
                "name": r.get(self.keys.get("item_name", "item_name")),
                "unit": r.get(self.keys.get("item_unit", "unit")),
            }
            for r in rows
        ]

    def get_expected_consumption(self, outlet: str, start: str, end: str) -> dict[str, dict]:
        """Recipe-based raw-material use for the period, with the dishes behind it.

        Returns {raw material code: {"qty": float, "portions": {dish: portions sold}}}.
        """
        data = self._post("consumption", outlet, {"from_date": start, "to_date": end})
        k = self.keys
        out: dict[str, dict] = {}
        for r in data.get(k.get("consumption_list", "data"), []):
            portions = {}
            for p in r.get(k.get("consumption_portions", "menu_items"), []) or []:
                portions[str(p.get(k.get("portion_name", "name")))] = float(p.get(k.get("portion_count", "qty")) or 0)
            out[str(r.get(k.get("item_code", "item_code")))] = {
                "qty": float(r.get(k.get("consumption_qty", "consumed_qty")) or 0), "portions": portions}
        return out

    def get_vendor_payables(self, outlet: str, vendor: str) -> list[dict] | None:
        """Unpaid purchase invoices for a vendor, as Petpooja holds them."""
        if "vendor_payables" not in self.endpoints:
            return None
        data = self._post("vendor_payables", outlet, {"vendor_name": vendor})
        k = self.keys
        return [
            {"vendor": r.get(k.get("vendor_name", "vendor_name")), "invoice_no": r.get(k.get("invoice_no", "invoice_no")),
             "invoice_date": r.get(k.get("invoice_date", "invoice_date")),
             "amount": float(r.get(k.get("invoice_amount", "amount")) or 0),
             "pending": float(r.get(k.get("pending_amount", "pending_amount")) or 0)}
            for r in data.get(k.get("payables_list", "data"), [])
        ]


def adapter() -> PetpoojaAdapter:
    return HttpAdapter() if settings.petpooja_enabled else ManualAdapter()
