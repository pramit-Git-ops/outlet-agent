"""Petpooja Inventory API (version 3.1).

The agent asks Petpooja for:
  * consumption (get_orders_api): every bill with the raw materials Petpooja's own
    recipes used for it; this is the ideal consumption
  * internal transfers (get_sales, slType "transfer"): stock sent from the store to
    the kitchen, which counts towards actual consumption
  * purchases (get_purchase): the latest purchase price of each raw material, for
    the variance amount
  * stock (get_stock_api): Petpooja's store stock, shown beside the kitchen count

Raw materials are matched to our items by SAP code, then by the Petpooja name set
on the item, then by the item's own name.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Callable

import httpx2 as httpx

from . import db
from .settings import settings

log = logging.getLogger(__name__)

# Tests replace this with a function (endpoint, body) -> response dict.
post_hook: Callable[[str, dict], dict] | None = None
PAGE_SIZE = 50


class PetpoojaError(RuntimeError):
    pass


# ------------------------------------------------------------ calling the API

def _call(endpoint: str, extra: dict) -> dict:
    body = {"app_key": settings.petpooja_app_key, "app_secret": settings.petpooja_app_secret,
            "access_token": settings.petpooja_access_token, "menuSharingCode": settings.petpooja_menu_sharing_code, **extra}
    if post_hook is not None:
        data = post_hook(endpoint, body)
    else:
        if not settings.petpooja_ready:
            raise PetpoojaError("Petpooja is not set up: add the PETPOOJA_* variables in Railway.")
        url = settings.petpooja_api_base.rstrip("/") + "/" + endpoint
        with httpx.Client(timeout=60) as client:
            resp = client.post(url, json=body, headers={"Content-Type": "application/json"})
        if resp.status_code >= 300:
            raise PetpoojaError(f"Petpooja said {resp.status_code}: {resp.text[:300]}")
        try:
            data = resp.json()
        except ValueError:
            raise PetpoojaError(f"Petpooja sent something that is not JSON: {resp.text[:200]}")
    if str(data.get("success", "1")) != "1":
        raise PetpoojaError(f"Petpooja said: {data.get('message') or data}")
    return data


def _paged(endpoint: str, extra: dict, list_key: str, id_of: Callable[[dict], str]) -> list[dict]:
    """Petpooja returns 50 records at a time; the last record's id fetches the next 50."""
    out, ref = [], ""
    for _ in range(200):
        rows = _call(endpoint, {**extra, "refId": ref}).get(list_key) or []
        out.extend(rows)
        if len(rows) < PAGE_SIZE:
            break
        nxt = str(id_of(rows[-1]) or "")
        if not nxt or nxt == ref:
            break
        ref = nxt
    return out


def _dmy(date: str) -> str:
    return datetime.strptime(date, "%Y-%m-%d").strftime("%d-%m-%Y")


def _num(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _iso(petpooja_time: str) -> str:
    """'2026-02-17 11:44:54' (Indian time) in the form our own timestamps use."""
    try:
        t = datetime.strptime(str(petpooja_time)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        t = datetime.strptime(str(petpooja_time)[:10], "%Y-%m-%d")
    return t.replace(tzinfo=db.tz()).isoformat(timespec="seconds")


# ------------------------------------------------------------ units and item matching

_UNITS = {
    "kg": ("mass", 1000), "kgs": ("mass", 1000), "kilo": ("mass", 1000), "kilogram": ("mass", 1000), "kilograms": ("mass", 1000),
    "g": ("mass", 1), "gm": ("mass", 1), "gms": ("mass", 1), "gram": ("mass", 1), "grams": ("mass", 1), "gr": ("mass", 1),
    "mg": ("mass", 0.001),
    "l": ("volume", 1000), "lt": ("volume", 1000), "ltr": ("volume", 1000), "ltrs": ("volume", 1000), "litre": ("volume", 1000),
    "litres": ("volume", 1000), "liter": ("volume", 1000), "liters": ("volume", 1000),
    "ml": ("volume", 1), "mls": ("volume", 1),
    "nos": ("count", 1), "no": ("count", 1), "pc": ("count", 1), "pcs": ("count", 1), "piece": ("count", 1),
    "pieces": ("count", 1), "unit": ("count", 1), "units": ("count", 1), "each": ("count", 1), "dozen": ("count", 12),
}


def _unit(u) -> str:
    return "".join(ch for ch in str(u or "").lower() if ch.isalpha())


def convert(qty: float, from_unit, to_unit) -> float | None:
    """qty in from_unit expressed in to_unit, or None if the units cannot be converted."""
    a, b = _unit(from_unit), _unit(to_unit)
    if a == b or not a:
        return qty
    ua, ub = _UNITS.get(a), _UNITS.get(b)
    if ua and ub and ua[0] == ub[0]:
        return qty * ua[1] / ub[1]
    return None


def _line_qty(line: dict, qty: float, item_unit: str) -> float | None:
    """A Petpooja line quantity in our item's unit, trying its label unit, then its conversion unit."""
    q = convert(qty, line.get("lbl_unit") or line.get("unitname") or line.get("unit_name"), item_unit)
    if q is None and line.get("rmconv_unit") and _num(line.get("rmconv_qty")):
        q = convert(qty * _num(line["rmconv_qty"]), line["rmconv_unit"], item_unit)
    return q


def _key(s) -> str:
    return " ".join(str(s or "").lower().split())


class Matcher:
    """Finds our item for a Petpooja raw material, and remembers the ones it could not match."""

    def __init__(self) -> None:
        self.items = db.query("SELECT * FROM items")
        self.by_sap = {_key(i["sap_code"]): i for i in self.items if i.get("sap_code")}
        self.by_name = {_key(i["name"]): i for i in self.items}
        self.by_name.update({_key(i["petpooja_name"]): i for i in self.items if i.get("petpooja_name")})
        self.not_matched: set[str] = set()
        self.wrong_unit: set[str] = set()

    def item(self, name, sap_code=None) -> dict | None:
        found = (self.by_sap.get(_key(sap_code)) if sap_code else None) or self.by_name.get(_key(name))
        if not found and name:
            self.not_matched.add(str(name).strip())
        return found

    def qty(self, line: dict, qty: float, item: dict) -> float | None:
        q = _line_qty(line, qty, item["unit"])
        if q is None:
            self.wrong_unit.add(f"{item['name']} (Petpooja unit {line.get('lbl_unit') or line.get('unitname')}, ours {item['unit']})")
        return q


# ------------------------------------------------------------ consumption (ideal use)

def sync_consumption(date: str) -> int:
    """Bills of one day with the raw materials Petpooja's recipes used for each dish."""
    orders = _paged("get_orders_api/", {"order_date": date}, "order_json",
                    lambda o: (o.get("Order") or {}).get("orderID"))
    for o in orders:
        rest, order = o.get("Restaurant") or {}, o.get("Order") or {}
        key = f"{rest.get('restID') or rest.get('restaurantid') or ''}:{order.get('orderID')}"
        created = str(order.get("created_on") or f"{date} 00:00:00")[:19]
        db.execute("DELETE FROM pp_order_lines WHERE order_key=?", (key,))
        db.execute("DELETE FROM pp_consumption WHERE order_key=?", (key,))
        for n, it in enumerate(o.get("OrderItem") or []):
            db.execute("INSERT INTO pp_order_lines(order_key,line_no,created_on,status,dish,qty) VALUES (?,?,?,?,?,?)",
                       (key, n, created, str(order.get("status") or "Success"), str(it.get("name") or "").strip(), _num(it.get("quantity"))))
            for rm in it.get("consumed") or []:
                db.execute("INSERT INTO pp_consumption(order_key,line_no,name,sap_code,qty,unit) VALUES (?,?,?,?,?,?)",
                           (key, n, str(rm.get("rawmaterialname") or "").strip(), str(rm.get("rawmaterialsapcode") or ""),
                            _num(rm.get("rawmaterialquantity")), str(rm.get("unitname") or "")))
    return len(orders)


def _ts(iso: str | None) -> str:
    return (iso or "")[:19].replace("T", " ")


def ideal_use(start: str | None, end: str) -> dict[str, dict]:
    """{item code: {"qty", "dishes"}} from Petpooja's consumption between two times.
    Each raw-material quantity is taken as the total used for that bill line."""
    m = Matcher()
    out: dict[str, dict] = {}
    for r in db.query("SELECT l.dish, l.qty AS portions, c.name, c.sap_code, c.qty, c.unit FROM pp_consumption c "
                      "JOIN pp_order_lines l ON l.order_key=c.order_key AND l.line_no=c.line_no "
                      "WHERE l.status='Success' AND l.created_on>? AND l.created_on<=?", (_ts(start), _ts(end))):
        item = m.item(r["name"], r["sap_code"])
        if not item:
            continue
        q = m.qty({"unitname": r["unit"]}, r["qty"], item)
        if q is None:
            continue
        e = out.setdefault(item["code"], {"qty": 0.0, "dishes": {}})
        e["qty"] += q
        e["dishes"][r["dish"]] = e["dishes"].get(r["dish"], 0) + r["portions"]
    return out


def dishes_sold(start: str | None, end: str) -> list[dict]:
    rows = db.query("SELECT l.dish, l.qty, EXISTS(SELECT 1 FROM pp_consumption c WHERE c.order_key=l.order_key AND c.line_no=l.line_no) AS has_recipe "
                    "FROM pp_order_lines l WHERE l.status='Success' AND l.created_on>? AND l.created_on<=?", (_ts(start), _ts(end)))
    sold: dict[str, dict] = {}
    for r in rows:
        e = sold.setdefault(r["dish"], {"dish": r["dish"], "qty": 0.0, "has_recipe": False})
        e["qty"] += r["qty"]
        e["has_recipe"] = e["has_recipe"] or bool(r["has_recipe"])
    return sorted(sold.values(), key=lambda d: -d["qty"])


def sales_summary(date: str | None = None) -> dict:
    date = date or db.now().strftime("%Y-%m-%d")
    bills = db.query("SELECT DISTINCT order_key, status FROM pp_order_lines WHERE substr(created_on,1,10)=?", (date,))
    ok = [b for b in bills if b["status"] == "Success"]
    return {"date": date, "bills": len(ok), "cancelled": len(bills) - len(ok),
            "top_dishes": dishes_sold(f"{date} 00:00:00", f"{date} 23:59:59")[:10],
            "note": "From Petpooja's consumption data, synced every hour."}


def unmatched_consumption(start: str | None, end: str) -> list[str]:
    m = Matcher()
    for r in db.query("SELECT DISTINCT c.name, c.sap_code FROM pp_consumption c JOIN pp_order_lines l "
                      "ON l.order_key=c.order_key AND l.line_no=c.line_no WHERE l.created_on>? AND l.created_on<=?", (_ts(start), _ts(end))):
        m.item(r["name"], r["sap_code"])
    return sorted(m.not_matched)


def use_for_ideal() -> bool:
    return settings.petpooja_ready and db.get("ideal_source") == "petpooja"


# ------------------------------------------------------------ transfers to the kitchen (actual use)

def sync_transfers(start_date: str, end_date: str, m: Matcher | None = None) -> int:
    """Internal transfers in Petpooja become 'stock sent to the kitchen' entries.
    Re-syncing updates them; a transfer cancelled in Petpooja is removed."""
    m = m or Matcher()
    rows = _paged("get_sales/", {"from_date": _dmy(start_date), "to_date": _dmy(end_date), "slType": "transfer"},
                  "sales", lambda s: s.get("sale_id"))
    want = _key(db.get("kitchen_receiver"))
    saved = 0
    for s in rows:
        receiver = (((s.get("restaurant_details") or {}).get("receiver") or {}).get("receiver_name") or "").strip()
        keep = str(s.get("action_status") or "Active") == "Active" and (not want or want in _key(receiver))
        at = _iso(s.get("created_on") or s.get("invoice_date"))
        for n, line in enumerate(s.get("item_details") or []):
            ref = f"pp-transfer:{s.get('sale_id')}:{line.get('item_id') or n}"
            if not keep:
                db.execute("DELETE FROM issues WHERE source_ref=?", (ref,))
                continue
            item = m.item(line.get("itemname"), line.get("sap_code"))
            qty = m.qty(line, _num(line.get("qty")), item) if item else None
            if qty is None:
                continue
            note = f"Petpooja transfer {s.get('invoice_number') or s.get('sale_id')}" + (f" to {receiver}" if receiver else "")
            db.execute("INSERT INTO issues(at,item_code,qty,note,entered_by,source_ref) VALUES (?,?,?,?,?,?) "
                       "ON CONFLICT(source_ref) DO UPDATE SET at=excluded.at, item_code=excluded.item_code, qty=excluded.qty, note=excluded.note",
                       (at, item["code"], round(qty, 4), note, "Petpooja", ref))
            saved += 1
    return saved


# ------------------------------------------------------------ purchase rates

def sync_rates(start_date: str, end_date: str, m: Matcher | None = None) -> int:
    """Each item's rate becomes the price of its latest Petpooja purchase (weighted price, which includes tax)."""
    m = m or Matcher()
    rows = _paged("get_purchase/", {"from_date": _dmy(start_date), "to_date": _dmy(end_date)},
                  "purchases", lambda p: p.get("purchase_id"))
    latest: dict[str, tuple[str, float, str]] = {}
    for p in rows:
        if str(p.get("action_status") or "Active") != "Active":
            continue
        when = str(p.get("created_on") or p.get("invoice_date") or "")
        for line in p.get("item_details") or []:
            item = m.item(line.get("itemname"), line.get("sap_code"))
            price = _num(line.get("weighted_price")) or _num(line.get("price"))
            if not item or price <= 0:
                continue
            per_item_unit = m.qty(line, 1.0, item)   # 1 Petpooja unit in our unit
            if not per_item_unit:
                continue
            rate = price / per_item_unit
            if item["code"] not in latest or when > latest[item["code"]][0]:
                latest[item["code"]] = (when, rate, f"Petpooja purchase of {when[:10]}")
    for code, (_, rate, note) in latest.items():
        db.execute("UPDATE items SET rate=?, rate_note=? WHERE code=?", (round(rate, 2), note, code))
    return len(latest)


# ------------------------------------------------------------ Petpooja store stock

def sync_stock(date: str) -> int:
    rows = _call("get_stock_api/", {"date": date}).get("closing_json") or []
    db.execute("DELETE FROM pp_stock WHERE stock_date=?", (date,))
    for r in rows:
        db.execute("INSERT OR REPLACE INTO pp_stock(stock_date,name,sap_code,category,qty,unit,price) VALUES (?,?,?,?,?,?,?)",
                   (date, str(r.get("name") or "").strip(), str(r.get("sapcode") or ""), r.get("category"),
                    _num(r.get("qty")), r.get("unit"), _num(r.get("price"))))
    return len(rows)


def store_stock(date: str | None = None) -> dict:
    """Petpooja's stock list for a day (latest synced day if none), with our item where one matches."""
    date = date or (db.query_one("SELECT MAX(stock_date) AS d FROM pp_stock") or {}).get("d")
    m = Matcher()
    rows = []
    for r in db.query("SELECT * FROM pp_stock WHERE stock_date=? ORDER BY name", (date or "",)):
        item = m.item(r["name"], r["sap_code"])
        rows.append({**r, "item": item["name"] if item else None, "item_code": item["code"] if item else None})
    return {"date": date, "rows": rows}


def import_items() -> int:
    """Adds every raw material in Petpooja's stock list that is not an item yet (not ticked for counting)."""
    stock = store_stock()
    taken = {i["code"] for i in db.query("SELECT code FROM items")}
    names = {_key(i["name"]) for i in db.query("SELECT name FROM items")}
    added = 0
    for r in stock["rows"]:
        if r["item_code"] or not r["name"] or _key(r["name"]) in names:
            continue
        base = "".join(ch for ch in (r["sap_code"] or r["name"]).upper() if ch.isalnum())[:10] or "ITEM"
        code, n = base, 2
        while code in taken:
            code, n = f"{base}{n}", n + 1
        db.execute("INSERT INTO items(code,name,unit,rate,count_daily,petpooja_name,sap_code,rate_note) VALUES (?,?,?,?,0,?,?,?)",
                   (code, r["name"], r["unit"] or "kg", r["price"] or 0, r["name"], r["sap_code"] or None,
                    "Petpooja stock price" if r["price"] else None))
        taken.add(code)
        names.add(_key(r["name"]))
        added += 1
    if added:
        db.log_event("items_imported_from_petpooja", "admin panel", f"{added} items")
    return added


# ------------------------------------------------------------ the sync

def sync(now: datetime | None = None, days: int = 1) -> dict:
    """Fetches yesterday and today (or more days) from Petpooja. Each part runs even if another fails."""
    if not settings.petpooja_ready and post_hook is None:
        return {"status": "not set up"}
    now = now or db.now()
    today = now.strftime("%Y-%m-%d")
    first = (now - timedelta(days=days)).strftime("%Y-%m-%d")
    dates = [(now - timedelta(days=d)).strftime("%Y-%m-%d") for d in range(days, -1, -1)]
    m = Matcher()
    result: dict = {"at": db.now_iso(), "errors": []}
    parts = [("bills with consumption", lambda: sum(sync_consumption(d) for d in dates)),
             ("store stock", lambda: sync_stock(today))]
    if db.get("issues_from_petpooja"):
        parts.append(("transfers to kitchen", lambda: sync_transfers(first, today, m)))
    if db.get("rates_from_petpooja"):
        parts.append(("purchase rates", lambda: sync_rates((now - timedelta(days=30)).strftime("%Y-%m-%d"), today, m)))
    for name, fn in parts:
        try:
            result[name] = fn()
        except Exception as exc:
            log.warning("Petpooja %s failed: %s", name, exc)
            result["errors"].append(f"{name}: {exc}")
    result["not_matched"] = sorted(m.not_matched)[:100]
    result["unit_problems"] = sorted(m.wrong_unit)[:50]
    db.put("petpooja_last_sync", result)
    if result["errors"]:
        db.log_event("petpooja_sync_failed", "system", "; ".join(result["errors"])[:500])
    return result


def sync_quietly(now: datetime | None = None) -> None:
    try:
        sync(now)
    except Exception:
        log.exception("Petpooja sync failed")


def status() -> dict:
    return {"ready": settings.petpooja_ready, "last_sync": db.get("petpooja_last_sync"),
            "ideal_source": "petpooja" if use_for_ideal() else "panel"}
