"""Live sales from Petpooja's Global API, and recipes.

Petpooja pushes every printed bill to our webhook (event "orderdetails").
We keep the dishes sold, and the administrator's recipes turn them into the
raw materials each department should have used. That expected figure is what
the morning count is compared with.
"""
from __future__ import annotations

import hashlib
import hmac
from collections import defaultdict
from datetime import timedelta

from . import db
from .settings import settings


class SalesError(ValueError):
    pass


# ------------------------------------------------------------ webhook

def webhook_token() -> str:
    """Secret part of the webhook address. Set PETPOOJA_WEBHOOK_TOKEN to choose it."""
    if settings.petpooja_webhook_token:
        return settings.petpooja_webhook_token
    return hashlib.sha256(f"petpooja-webhook:{settings.link_secret}".encode()).hexdigest()[:24]


def webhook_url() -> str:
    return settings.public_base_url.rstrip("/") + "/petpooja/orders/" + webhook_token()


def token_ok(path_token: str, payload: dict) -> bool:
    expected = webhook_token()
    body_token = str(payload.get("token") or payload.get("Token") or "")
    return any(t and hmac.compare_digest(t, expected) for t in (path_token, body_token))


def outlet_for(rest_id: str) -> str:
    for code, rid in settings.rest_ids().items():
        if rid and rid == rest_id:
            return code
    for o in db.cfg("outlets", []) or []:
        if o.get("petpooja_rest_id") and o["petpooja_rest_id"] == rest_id:
            return o["code"]
    return rest_id


def _num(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def record_order(payload: dict) -> dict:
    """Store one pushed bill. The same order sent again (or later cancelled) replaces the earlier copy."""
    if payload.get("event", "orderdetails") != "orderdetails":
        return {"ignored": payload.get("event")}
    props = payload.get("properties") or {}
    rest, order = props.get("Restaurant") or {}, props.get("Order") or {}
    rest_id, order_id = str(rest.get("restID") or ""), str(order.get("orderID") or "")
    if not order_id:
        raise SalesError("order has no orderID")
    status = str(order.get("status") or "Success")
    created = str(order.get("created_on") or db.now().strftime("%Y-%m-%d %H:%M:%S"))[:19]
    db.execute(
        "INSERT INTO sales(rest_id,order_id,outlet,status,created_on,total,order_type,order_from,received_at) "
        "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(rest_id,order_id) DO UPDATE SET status=excluded.status, "
        "created_on=excluded.created_on, total=excluded.total, order_type=excluded.order_type, "
        "order_from=excluded.order_from, received_at=excluded.received_at",
        (rest_id, order_id, outlet_for(rest_id), status, created, _num(order.get("total")),
         order.get("order_type"), order.get("order_from"), db.now_iso()))
    db.execute("DELETE FROM sale_lines WHERE rest_id=? AND order_id=?", (rest_id, order_id))
    lines = 0
    for it in props.get("OrderItem") or []:
        qty = _num(it.get("quantity"))
        db.execute("INSERT INTO sale_lines(rest_id,order_id,name,code,petpooja_id,qty,addon) VALUES (?,?,?,?,?,?,0)",
                   (rest_id, order_id, str(it.get("name") or "").strip(), str(it.get("itemcode") or "").strip(),
                    str(it.get("itemid") or ""), qty))
        lines += 1
        for ad in it.get("addon") or []:
            # Add-on quantity is per dish, so two dishes with "2 x sauce" use four.
            db.execute("INSERT INTO sale_lines(rest_id,order_id,name,code,petpooja_id,qty,addon) VALUES (?,?,?,?,?,?,1)",
                       (rest_id, order_id, str(ad.get("name") or "").strip(), "", str(ad.get("addon_id") or ""),
                        _num(ad.get("quantity") or 1) * (qty or 1)))
            lines += 1
    return {"order_id": order_id, "status": status, "lines": lines}


# ------------------------------------------------------------ recipes

def _key(s) -> str:
    return " ".join(str(s or "").lower().split())


def recipes() -> list[dict]:
    rows = db.query("SELECT r.dish, r.item_code, r.qty, r.location, i.name AS item_name, i.unit "
                    "FROM recipes r LEFT JOIN items i ON i.code=r.item_code ORDER BY lower(r.dish), i.name")
    for r in rows:
        r["location"] = r["location"] or ""
    return rows


def has_recipes() -> bool:
    return bool(db.query_one("SELECT 1 AS x FROM recipes LIMIT 1"))


def save_recipes(rows: list[dict]) -> int:
    """Replace every recipe line. Items may be given by code or by exact name."""
    items = db.query("SELECT code, name FROM items")
    by_code = {i["code"].upper(): i["code"] for i in items}
    by_name = {_key(i["name"]): i["code"] for i in items}
    locs = set(db.cfg("locations", []) or [])
    clean, seen = [], set()
    for n, r in enumerate(rows, 1):
        dish = " ".join(str(r.get("dish") or "").split())
        raw = str(r.get("item_code") or r.get("item") or "").strip()
        if not dish and not raw:
            continue
        where = f"Recipe row {n} ({dish or 'no dish'})"
        if not dish:
            raise SalesError(f"{where}: needs the dish name or Petpooja item code")
        code = by_code.get(raw.upper()) or by_name.get(_key(raw))
        if not code:
            raise SalesError(f"{where}: {raw or 'no item'} is not in the Items list")
        qty = _num(r.get("qty"))
        if qty <= 0:
            raise SalesError(f"{where}: quantity per portion must be more than 0")
        loc = str(r.get("location") or "").strip()
        if loc and loc not in locs:
            raise SalesError(f"{where}: unknown department {loc}")
        if (_key(dish), code, loc) in seen:
            raise SalesError(f"{where}: {raw} is listed twice for this dish")
        seen.add((_key(dish), code, loc))
        clean.append((dish, code, qty, loc))
    db.execute("DELETE FROM recipes")
    for row in clean:
        db.execute("INSERT INTO recipes(dish,item_code,qty,location) VALUES (?,?,?,?)", row)
    return len(clean)


def _recipe_index() -> dict[str, list[dict]]:
    idx: dict[str, list[dict]] = defaultdict(list)
    for r in db.query("SELECT dish, item_code, qty, location FROM recipes"):
        idx[_key(r["dish"])].append(r)
    return idx


def _match(idx: dict, line: dict) -> list[dict] | None:
    for k in (line["code"], line["petpooja_id"], line["name"]):
        if k and _key(k) in idx:
            return idx[_key(k)]
    return None


def _ts(iso: str | None) -> str:
    """Our ISO timestamps as Petpooja writes created_on (local, 'YYYY-MM-DD HH:MM:SS')."""
    return (iso or "")[:19].replace("T", " ")


def _lines(start: str | None, end: str) -> list[dict]:
    return db.query(
        "SELECT l.name, l.code, l.petpooja_id, l.qty, l.addon FROM sale_lines l JOIN sales s "
        "ON s.rest_id=l.rest_id AND s.order_id=l.order_id WHERE s.status='Success' AND s.created_on>? AND s.created_on<=?",
        (_ts(start), _ts(end)))


def expected_use(location: str, start: str | None, end: str) -> dict[str, dict]:
    """Raw material each item should have used in a department between two counts:
    {item code: {"qty": float, "portions": {dish: portions sold}}}."""
    idx = _recipe_index()
    # Every item in a recipe is expected, so one used with no dishes sold still shows up.
    out: dict[str, dict] = {r["item_code"]: {"qty": 0.0, "portions": {}}
                            for rs in idx.values() for r in rs if not r["location"] or r["location"] == location}
    for line in _lines(start, end):
        for r in _match(idx, line) or []:
            if r["location"] and r["location"] != location:
                continue
            e = out.setdefault(r["item_code"], {"qty": 0.0, "portions": {}})
            e["qty"] += r["qty"] * line["qty"]
            e["portions"][line["name"]] = e["portions"].get(line["name"], 0) + line["qty"]
    for e in out.values():
        e["portions"] = dict(sorted(e["portions"].items(), key=lambda kv: -kv[1]))
    return out


def dishes_without_recipe(days: int = 7) -> list[dict]:
    """Dishes sold recently that no recipe covers, most sold first."""
    end = db.now()
    idx = _recipe_index()
    missing: dict[str, float] = defaultdict(float)
    for line in _lines((end - timedelta(days=days)).isoformat(), end.isoformat()):
        if _match(idx, line) is None and not line["addon"]:
            missing[line["name"]] += line["qty"]
    return [{"dish": d, "sold": q} for d, q in sorted(missing.items(), key=lambda kv: -kv[1])]


def sales_summary(date: str | None = None) -> dict:
    date = date or db.now().strftime("%Y-%m-%d")
    orders = db.query("SELECT outlet, status, total, order_from FROM sales WHERE substr(created_on,1,10)=?", (date,))
    ok = [o for o in orders if o["status"] == "Success"]
    by_outlet: dict[str, dict] = {}
    for o in ok:
        b = by_outlet.setdefault(o["outlet"] or "?", {"bills": 0, "total": 0.0})
        b["bills"] += 1
        b["total"] = round(b["total"] + o["total"], 2)
    dishes: dict[str, float] = defaultdict(float)
    for line in _lines(f"{date}T00:00:00", f"{date}T23:59:59"):
        if not line["addon"]:
            dishes[line["name"]] += line["qty"]
    top = sorted(dishes.items(), key=lambda kv: -kv[1])[:10]
    return {"date": date, "bills": len(ok), "total": round(sum(o["total"] for o in ok), 2),
            "cancelled": len(orders) - len(ok), "by_outlet": by_outlet,
            "top_dishes": [{"dish": d, "qty": q} for d, q in top]}


def status() -> dict:
    last = db.query_one("SELECT received_at, created_on FROM sales ORDER BY received_at DESC LIMIT 1")
    return {
        "webhook": webhook_url(),
        "last_bill_received": last["received_at"] if last else None,
        "bills_received": (db.query_one("SELECT COUNT(*) AS n FROM sales") or {}).get("n", 0),
        "rest_ids_seen": [r["rest_id"] for r in db.query("SELECT DISTINCT rest_id FROM sales")],
        "recipes": (db.query_one("SELECT COUNT(DISTINCT lower(dish)) AS n FROM recipes") or {}).get("n", 0),
    }
