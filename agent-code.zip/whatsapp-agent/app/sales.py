"""Petpooja live sales (Global API) and recipes.

Petpooja pushes every printed bill to our webhook (event "orderdetails").
Dishes sold x the recipes the administrator enters = the ideal use of each
raw material, which the daily count is compared with.
"""
from __future__ import annotations

import hashlib
import hmac
from collections import defaultdict
from datetime import timedelta

from . import db
from .settings import settings


class SalesError(ValueError):
    pass


# ------------------------------------------------------------ webhook

def webhook_token() -> str:
    if settings.petpooja_webhook_token:
        return settings.petpooja_webhook_token
    return hashlib.sha256(f"petpooja-webhook:{settings.link_secret}".encode()).hexdigest()[:24]


def webhook_url() -> str:
    return settings.public_base_url.rstrip("/") + "/petpooja/orders/" + webhook_token()


def token_ok(path_token: str, payload: dict) -> bool:
    expected = webhook_token()
    body_token = str(payload.get("token") or payload.get("Token") or "")
    return any(t and hmac.compare_digest(t, expected) for t in (path_token, body_token))


def _num(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def record_order(payload: dict) -> dict:
    """Store one bill. The same order sent again (for example cancelled) replaces the earlier copy."""
    if payload.get("event", "orderdetails") != "orderdetails":
        return {"ignored": payload.get("event")}
    props = payload.get("properties") or {}
    rest, order = props.get("Restaurant") or {}, props.get("Order") or {}
    rest_id, order_id = str(rest.get("restID") or ""), str(order.get("orderID") or "")
    if not order_id:
        raise SalesError("order has no orderID")
    status = str(order.get("status") or "Success")
    created = str(order.get("created_on") or db.now().strftime("%Y-%m-%d %H:%M:%S"))[:19]
    db.execute(
        "INSERT INTO sales(rest_id,order_id,status,created_on,total,order_from,received_at) VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(rest_id,order_id) DO UPDATE SET status=excluded.status, created_on=excluded.created_on, "
        "total=excluded.total, order_from=excluded.order_from, received_at=excluded.received_at",
        (rest_id, order_id, status, created, _num(order.get("total")), order.get("order_from"), db.now_iso()))
    db.execute("DELETE FROM sale_lines WHERE rest_id=? AND order_id=?", (rest_id, order_id))
    lines = 0
    for it in props.get("OrderItem") or []:
        qty = _num(it.get("quantity"))
        db.execute("INSERT INTO sale_lines(rest_id,order_id,name,code,petpooja_id,qty,addon) VALUES (?,?,?,?,?,?,0)",
                   (rest_id, order_id, str(it.get("name") or "").strip(), str(it.get("itemcode") or "").strip(),
                    str(it.get("itemid") or ""), qty))
        lines += 1
        for ad in it.get("addon") or []:
            # Add-on quantity is per dish: two dishes with "2 x sauce" use four.
            db.execute("INSERT INTO sale_lines(rest_id,order_id,name,code,petpooja_id,qty,addon) VALUES (?,?,?,?,?,?,1)",
                       (rest_id, order_id, str(ad.get("name") or "").strip(), "", str(ad.get("addon_id") or ""),
                        _num(ad.get("quantity") or 1) * (qty or 1)))
            lines += 1
    return {"order_id": order_id, "status": status, "lines": lines}


# ------------------------------------------------------------ recipes

def _key(s) -> str:
    return " ".join(str(s or "").lower().split())


def recipes() -> list[dict]:
    return db.query("SELECT r.dish, r.item_code, r.qty, i.name AS item_name, i.unit FROM recipes r "
                    "LEFT JOIN items i ON i.code=r.item_code ORDER BY lower(r.dish), i.name")


def save_recipes(rows: list[dict]) -> int:
    """Replace every recipe line. Raw materials may be given by code or by exact name."""
    items = db.query("SELECT code, name FROM items")
    by_code = {i["code"].upper(): i["code"] for i in items}
    by_name = {_key(i["name"]): i["code"] for i in items}
    clean, seen = [], set()
    for n, r in enumerate(rows, 1):
        dish = " ".join(str(r.get("dish") or "").split())
        raw = str(r.get("item_code") or r.get("item") or "").strip()
        if not dish and not raw:
            continue
        where = f"Recipe row {n} ({dish or 'no dish'})"
        if not dish:
            raise SalesError(f"{where}: needs the dish name or Petpooja item code")
        code = by_code.get(raw.upper()) or by_name.get(_key(raw))
        if not code:
            raise SalesError(f"{where}: {raw or 'no item'} is not in the Items list")
        qty = _num(r.get("qty"))
        if qty <= 0:
            raise SalesError(f"{where}: quantity per portion must be more than 0")
        if (_key(dish), code) in seen:
            raise SalesError(f"{where}: {raw} is listed twice for this dish")
        seen.add((_key(dish), code))
        clean.append((dish, code, qty))
    db.execute("DELETE FROM recipes")
    for row in clean:
        db.execute("INSERT INTO recipes(dish,item_code,qty) VALUES (?,?,?)", row)
    return len(clean)


def _recipe_index() -> dict[str, list[dict]]:
    idx: dict[str, list[dict]] = defaultdict(list)
    for r in db.query("SELECT dish, item_code, qty FROM recipes"):
        idx[_key(r["dish"])].append(r)
    return idx


def _match(idx: dict, line: dict) -> list[dict] | None:
    for k in (line["code"], line["petpooja_id"], line["name"]):
        if k and _key(k) in idx:
            return idx[_key(k)]
    return None


def _ts(iso: str | None) -> str:
    """Our ISO timestamps in Petpooja's created_on form (local 'YYYY-MM-DD HH:MM:SS')."""
    return (iso or "")[:19].replace("T", " ")


def _lines(start: str | None, end: str) -> list[dict]:
    return db.query(
        "SELECT l.name, l.code, l.petpooja_id, l.qty, l.addon FROM sale_lines l JOIN sales s "
        "ON s.rest_id=l.rest_id AND s.order_id=l.order_id WHERE s.status='Success' AND s.created_on>? AND s.created_on<=?",
        (_ts(start), _ts(end)))


def ideal_use(start: str | None, end: str) -> dict[str, dict]:
    """{item code: {"qty": ideal use, "dishes": {dish: portions sold}}} for bills between two times."""
    idx = _recipe_index()
    out: dict[str, dict] = {}
    for line in _lines(start, end):
        for r in _match(idx, line) or []:
            e = out.setdefault(r["item_code"], {"qty": 0.0, "dishes": {}})
            e["qty"] += r["qty"] * line["qty"]
            e["dishes"][line["name"]] = e["dishes"].get(line["name"], 0) + line["qty"]
    return out


def dishes_sold(start: str | None, end: str) -> list[dict]:
    idx = _recipe_index()
    sold: dict[str, dict] = {}
    for line in _lines(start, end):
        if line["addon"]:
            continue
        e = sold.setdefault(line["name"], {"dish": line["name"], "qty": 0.0, "has_recipe": _match(idx, line) is not None})
        e["qty"] += line["qty"]
    return sorted(sold.values(), key=lambda d: -d["qty"])


def dishes_without_recipe(days: int = 7) -> list[dict]:
    end = db.now()
    return [d for d in dishes_sold((end - timedelta(days=days)).isoformat(), end.isoformat()) if not d["has_recipe"]]


def sales_summary(date: str | None = None) -> dict:
    date = date or db.now().strftime("%Y-%m-%d")
    orders = db.query("SELECT status, total FROM sales WHERE substr(created_on,1,10)=?", (date,))
    ok = [o for o in orders if o["status"] == "Success"]
    return {"date": date, "bills": len(ok), "total": round(sum(o["total"] for o in ok), 2),
            "cancelled": len(orders) - len(ok),
            "top_dishes": dishes_sold(f"{date}T00:00:00", f"{date}T23:59:59")[:10]}


def status() -> dict:
    last = db.query_one("SELECT received_at FROM sales ORDER BY received_at DESC LIMIT 1")
    return {
        "webhook": webhook_url(),
        "last_bill_received": last["received_at"] if last else None,
        "bills_received": db.query_one("SELECT COUNT(*) AS n FROM sales")["n"],
        "recipes": db.query_one("SELECT COUNT(DISTINCT lower(dish)) AS n FROM recipes")["n"],
    }
