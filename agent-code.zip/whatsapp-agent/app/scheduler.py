"""Timed jobs: morning count sheets, reminders, reports, escalations, digests."""
from __future__ import annotations

import logging

from datetime import datetime, timedelta

from apscheduler.schedulers.background import BackgroundScheduler

from . import db, ops, whatsapp

log = logging.getLogger(__name__)


def send_count_sheets() -> None:
    for location, phones in db.cfg("stock_count", {}).get("counters", {}).items():
        sheet = ops.count_sheet(location)
        lines = [f"Good morning! Please count *{location}* stock now and reply with quantities."]
        for cat, names in sheet["categories"].items():
            lines.append(f"\n{cat.replace('_', ' ').capitalize()}:\n" + "\n".join(f"• {n}" for n in names))
        if sheet["needs_rooms_occupied"]:
            lines.append("\nAlso tell me how many rooms were occupied last night.")
        lines.append("\nYou can send it in parts, as a voice note or a photo. Say 'done' when finished.")
        ops.notify(phones, "\n".join(lines))


def count_reminders() -> None:
    today = db.now().strftime("%Y-%m-%d")
    for location, phones in db.cfg("stock_count", {}).get("counters", {}).items():
        meta = db.query_one("SELECT status FROM count_meta WHERE count_date=? AND location=?", (today, location))
        if not meta or meta["status"] != "complete":
            ops.notify(phones, f"Reminder: the {location} stock count is not finished yet. Please complete it now.")


def send_stock_report() -> None:
    report = ops.consumption_report()
    ops.notify(db.cfg("stock_count", {}).get("report_to", []), ops.report_text(report))


def send_accounts_digest() -> None:
    text = ops.accounts_digest()
    if text:
        accounts = db.cfg("accounts", {}).get("notify") or [u["phone"] for u in db.users_with_role("accounts")]
        ops.notify(accounts, text)


def send_reminder(reminder: dict) -> None:
    ops.notify(reminder.get("to", []), reminder["message"])


# Times are read from the settings every minute, so a change made in the admin
# panel takes effect the same day without a restart.
DAILY_JOBS = [
    ("count_sheets", send_count_sheets, "stock_count", "send_sheets_at", "07:00"),
    ("count_reminders", count_reminders, "stock_count", "reminder_at", "08:30"),
    ("stock_report", send_stock_report, "stock_count", "report_at", "09:15"),
    ("accounts_digest", send_accounts_digest, "accounts", "digest_at", "18:00"),
]
CATCH_UP = timedelta(minutes=30)  # a job missed by a restart still runs within this window


def _due(at: str, now: datetime) -> bool:
    try:
        h, m = (int(x) for x in str(at).split(":"))
    except ValueError:
        return False
    start = now.replace(hour=h, minute=m, second=0, microsecond=0)
    return start <= now < start + CATCH_UP


def tick(now: datetime | None = None) -> list[str]:
    """Run every daily job and custom reminder whose time has come today."""
    now = now or db.now()
    today = now.strftime("%Y-%m-%d")
    ran = []
    for name, fn, section, key, default in DAILY_JOBS:
        at = (db.cfg(section, {}) or {}).get(key, default)
        if at and _due(at, now) and db.claim_once(f"ran:{name}:{today}"):
            _safe(fn)()
            ran.append(name)
    weekday = now.strftime("%a").lower()
    for i, r in enumerate(db.cfg("reminders", []) or []):
        if r.get("active", True) is False or (r.get("days") and weekday not in r["days"]):
            continue
        if _due(r.get("time", ""), now) and db.claim_once(f"ran:reminder:{r.get('name') or i}:{today}"):
            try:
                send_reminder(r)
            except Exception:
                log.exception("Reminder %s failed", r.get("name"))
            ran.append(f"reminder:{r.get('name')}")
    return ran


def start() -> BackgroundScheduler:
    sched = BackgroundScheduler(timezone=db.tz())
    sched.add_job(_safe(tick), "interval", minutes=1, id="tick")
    sched.add_job(_safe(ops.chase_overdue), "interval", minutes=10, id="chase_overdue")
    sched.start()
    log.info("Scheduler started: %s", [j.id for j in sched.get_jobs()])
    return sched


def _safe(fn):
    def run():
        try:
            fn()
        except Exception:
            log.exception("Scheduled job %s failed", fn.__name__)
    run.__name__ = fn.__name__
    return run


__all__ = ["start", "tick", "send_count_sheets", "count_reminders", "send_stock_report", "send_accounts_digest", "whatsapp"]
