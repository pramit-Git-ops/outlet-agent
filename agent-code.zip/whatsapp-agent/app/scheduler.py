"""Timed jobs, checked every minute so times changed in the admin panel apply the same day."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from apscheduler.schedulers.background import BackgroundScheduler

from . import db, petpooja, report, stock, whatsapp

log = logging.getLogger(__name__)
CATCH_UP = timedelta(minutes=30)   # a job missed by a restart still runs within this window


def send_count_list() -> None:
    items = stock.count_list()
    if not items:
        return
    text = ("Good morning! Please count the kitchen stock now and send me the quantities:\n"
            + "\n".join(f"• {i['name']} ({i['unit']})" for i in items)
            + "\n\nYou can send them in parts. Say 'done' when you have finished.")
    for p in db.people_with("stock_keeper"):
        whatsapp.send(p["phone"], text)


def count_late() -> None:
    day = stock.day_status(stock.today())
    if day and day["status"] == "complete":
        return
    for p in db.people_with("stock_keeper"):
        whatsapp.send(p["phone"], "Reminder: today's kitchen count is not finished yet. Please complete it now.")
    for p in db.people_with("admin"):
        whatsapp.send(p["phone"], f"Today's kitchen count is not finished (due by {db.get('count_due_by')}). "
                                  "The report will be emailed as soon as it is.")


JOBS = [("count_list", send_count_list, "count_reminder_at"), ("count_late", count_late, "count_due_by")]


def _due(at: str, now: datetime) -> bool:
    try:
        h, m = (int(x) for x in str(at).split(":"))
    except ValueError:
        return False
    start = now.replace(hour=h, minute=m, second=0, microsecond=0)
    return start <= now < start + CATCH_UP


def tick(now: datetime | None = None) -> list[str]:
    now = now or db.now()
    today = now.strftime("%Y-%m-%d")
    ran = []
    for name, fn, key in JOBS:
        if _due(db.get(key), now) and db.claim_once(f"ran:{name}:{today}"):
            _safe(fn)()
            ran.append(name)
    # Petpooja transfers, bills and rates, once an hour
    if petpooja.status()["ready"] and db.claim_once(f"ran:petpooja:{now.strftime('%Y-%m-%dT%H')}"):
        _safe(petpooja.sync)(now)
        ran.append("petpooja")
    if report.send_if_due(now) is not None:
        ran.append("report")
    return ran


def start() -> BackgroundScheduler:
    sched = BackgroundScheduler(timezone=db.tz())
    sched.add_job(_safe(tick), "interval", minutes=1, id="tick")
    sched.start()
    return sched


def _safe(fn):
    def run(*a, **k):
        try:
            return fn(*a, **k)
        except Exception:
            log.exception("Scheduled job %s failed", fn.__name__)
    run.__name__ = fn.__name__
    return run
