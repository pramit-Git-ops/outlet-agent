"""Twilio WhatsApp: sending messages and downloading media."""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from typing import Callable

import httpx2 as httpx

from . import db
from .settings import settings

log = logging.getLogger(__name__)

# WhatsApp caps a single message at 4096 characters; keep a margin.
MAX_LEN = 1500

_client = None
# Tests replace this with a function that records messages.
send_hook: Callable[[str, str], None] | None = None


def _twilio():
    global _client
    if _client is None:
        from twilio.rest import Client

        _client = Client(settings.twilio_account_sid, settings.twilio_auth_token)
    return _client


def mark_inbound(phone: str) -> None:
    db.execute(
        "INSERT INTO contacts(phone,last_inbound_at) VALUES (?,?) "
        "ON CONFLICT(phone) DO UPDATE SET last_inbound_at=excluded.last_inbound_at",
        (db.normalize_phone(phone), db.now_iso()),
    )


def in_service_window(phone: str) -> bool:
    """WhatsApp allows free-form messages for 24h after the person last wrote."""
    row = db.query_one("SELECT last_inbound_at FROM contacts WHERE phone=?", (db.normalize_phone(phone),))
    if not row or not row["last_inbound_at"]:
        return False
    last = datetime.fromisoformat(row["last_inbound_at"])
    return db.now() - last < timedelta(hours=23, minutes=50)


def _chunks(text: str) -> list[str]:
    parts, buf = [], ""
    for para in text.split("\n"):
        if len(buf) + len(para) + 1 > MAX_LEN and buf:
            parts.append(buf)
            buf = ""
        buf = f"{buf}\n{para}" if buf else para
    if buf:
        parts.append(buf)
    return parts or [""]


def send(phone: str, text: str) -> None:
    """Send a message. Outside the 24h window, uses the approved notice template."""
    phone = db.normalize_phone(phone)
    window = in_service_window(phone)
    mode = "session" if window or not settings.twilio_notice_content_sid else "template"
    for part in _chunks(text):
        status, error = "sent", None
        try:
            if send_hook is not None:
                send_hook(phone, part)
            elif mode == "session":
                _twilio().messages.create(
                    from_=settings.twilio_whatsapp_from, to=f"whatsapp:{phone}", body=part
                )
            else:
                _twilio().messages.create(
                    from_=settings.twilio_whatsapp_from,
                    to=f"whatsapp:{phone}",
                    content_sid=settings.twilio_notice_content_sid,
                    content_variables=json.dumps({"1": part[:1000]}),
                )
        except Exception as exc:  # keep the agent running if one send fails
            status, error = "failed", str(exc)
            log.exception("WhatsApp send to %s failed", phone)
        db.execute(
            "INSERT INTO outbox(phone,body,mode,status,error,at) VALUES (?,?,?,?,?,?)",
            (phone, part, mode, status, error, db.now_iso()),
        )


def download_media(url: str) -> tuple[bytes, str]:
    """Twilio media URLs need the account credentials (HTTP basic auth)."""
    with httpx.Client(follow_redirects=True, timeout=30) as client:
        resp = client.get(url, auth=(settings.twilio_account_sid, settings.twilio_auth_token))
        resp.raise_for_status()
        return resp.content, resp.headers.get("content-type", "application/octet-stream")
