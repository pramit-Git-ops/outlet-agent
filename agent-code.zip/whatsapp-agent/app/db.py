"""SQLite storage: one file on the Railway volume, no database server needed."""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from .settings import settings

log = logging.getLogger(__name__)
_lock = threading.RLock()
_conn: sqlite3.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  phone TEXT PRIMARY KEY, name TEXT NOT NULL, roles TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS items (
  code TEXT PRIMARY KEY, name TEXT NOT NULL, unit TEXT NOT NULL, rate REAL NOT NULL DEFAULT 0,
  count_daily INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at TEXT
);
-- Stock sent to the kitchen
CREATE TABLE IF NOT EXISTS issues (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, item_code TEXT NOT NULL, qty REAL NOT NULL,
  note TEXT, entered_by TEXT
);
-- Daily kitchen count: one row per item per day, and one status row per day
CREATE TABLE IF NOT EXISTS counts (
  count_date TEXT NOT NULL, item_code TEXT NOT NULL, qty REAL NOT NULL, counted_by TEXT, at TEXT,
  PRIMARY KEY (count_date, item_code)
);
CREATE TABLE IF NOT EXISTS count_days (
  count_date TEXT PRIMARY KEY, status TEXT NOT NULL, counted_by TEXT, completed_at TEXT, emailed_at TEXT
);
-- Petpooja bills (Global API) and recipes
CREATE TABLE IF NOT EXISTS sales (
  rest_id TEXT NOT NULL, order_id TEXT NOT NULL, status TEXT NOT NULL, created_on TEXT NOT NULL,
  total REAL DEFAULT 0, order_from TEXT, received_at TEXT, PRIMARY KEY (rest_id, order_id)
);
CREATE INDEX IF NOT EXISTS sales_created ON sales(created_on);
CREATE TABLE IF NOT EXISTS sale_lines (
  rest_id TEXT NOT NULL, order_id TEXT NOT NULL, name TEXT NOT NULL, code TEXT, petpooja_id TEXT,
  qty REAL NOT NULL, addon INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS sale_lines_order ON sale_lines(rest_id, order_id);
-- Petpooja Inventory API: dishes billed with the raw materials Petpooja's recipes consumed,
-- and Petpooja's store stock by day
CREATE TABLE IF NOT EXISTS pp_order_lines (
  order_key TEXT NOT NULL, line_no INTEGER NOT NULL, created_on TEXT NOT NULL, status TEXT, dish TEXT, qty REAL,
  PRIMARY KEY (order_key, line_no)
);
CREATE INDEX IF NOT EXISTS pp_order_lines_created ON pp_order_lines(created_on);
CREATE TABLE IF NOT EXISTS pp_consumption (
  order_key TEXT NOT NULL, line_no INTEGER NOT NULL, name TEXT NOT NULL, sap_code TEXT, qty REAL NOT NULL, unit TEXT
);
CREATE INDEX IF NOT EXISTS pp_consumption_order ON pp_consumption(order_key);
CREATE TABLE IF NOT EXISTS pp_stock (
  stock_date TEXT NOT NULL, name TEXT NOT NULL, sap_code TEXT, category TEXT, qty REAL, unit TEXT, price REAL,
  PRIMARY KEY (stock_date, name)
);
CREATE TABLE IF NOT EXISTS recipes (
  dish TEXT NOT NULL, item_code TEXT NOT NULL, qty REAL NOT NULL
);
-- WhatsApp plumbing and history
CREATE TABLE IF NOT EXISTS contacts (phone TEXT PRIMARY KEY, last_inbound_at TEXT);
CREATE TABLE IF NOT EXISTS conversations (phone TEXT PRIMARY KEY, messages_json TEXT NOT NULL, updated_at TEXT);
CREATE TABLE IF NOT EXISTS outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT, body TEXT, mode TEXT, status TEXT, error TEXT, at TEXT
);
CREATE TABLE IF NOT EXISTS emails (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, to_list TEXT, subject TEXT, status TEXT, error TEXT
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, actor TEXT, action TEXT NOT NULL, note TEXT
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
"""

# Settings the administrator changes in the admin panel, with their starting values.
DEFAULTS: dict[str, Any] = {
    "business_name": "My Restaurant",
    "count_reminder_at": "09:00",   # the stock keeper gets the count list on WhatsApp
    "count_due_by": "10:00",        # admins are told if the count is not finished by then
    "report_at": "11:00",           # the Excel report is emailed (or as soon as the count finishes after this)
    "report_emails": [],
    "house_rules": "",
    # Petpooja Inventory API (used once the PETPOOJA_* variables are set)
    "ideal_source": "petpooja",          # "petpooja": Petpooja's recipes (Consumption API); "panel": recipes entered here
    "issues_from_petpooja": True,         # bring Petpooja internal transfers in as stock sent to the kitchen
    "kitchen_receiver": "",               # only transfers to a receiver whose name contains this (blank: all)
    "rates_from_petpooja": True,          # item rates from the latest Petpooja purchase
}

ROLES = {
    "admin": "Administrator: everything, and is told when the count is late",
    "stock_keeper": "Stock keeper: counts the kitchen and records stock sent to it",
    "manager": "Manager: can ask for the stock and variance report on WhatsApp",
}


def tz() -> ZoneInfo:
    return ZoneInfo(settings.timezone)


def now() -> datetime:
    return datetime.now(tz())


def now_iso() -> str:
    return now().isoformat(timespec="seconds")


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        Path(settings.database_path).parent.mkdir(parents=True, exist_ok=True)
        _conn = sqlite3.connect(settings.database_path, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
    return _conn


def reset_connection() -> None:
    global _conn
    if _conn is not None:
        _conn.close()
    _conn = None


def execute(sql: str, params: tuple | list = ()) -> sqlite3.Cursor:
    with _lock:
        cur = conn().execute(sql, params)
        conn().commit()
        return cur


def query(sql: str, params: tuple | list = ()) -> list[dict[str, Any]]:
    with _lock:
        return [dict(r) for r in conn().execute(sql, params).fetchall()]


def query_one(sql: str, params: tuple | list = ()) -> dict[str, Any] | None:
    rows = query(sql, params)
    return rows[0] if rows else None


def init_db() -> None:
    with _lock:
        fresh = not query_one("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        conn().executescript(SCHEMA)
        _add_columns()
        conn().commit()
    if fresh:
        _copy_from_old_agent()


# Columns added after the first release; older databases get them on start.
NEW_COLUMNS = {
    "items": [("petpooja_name", "TEXT"), ("sap_code", "TEXT"), ("rate_note", "TEXT")],
    "issues": [("source_ref", "TEXT")],
}


def _add_columns() -> None:
    for table, cols in NEW_COLUMNS.items():
        have = {r[1] for r in conn().execute(f"PRAGMA table_info({table})")}
        for name, kind in cols:
            if name not in have:
                conn().execute(f"ALTER TABLE {table} ADD COLUMN {name} {kind}")
    conn().execute("CREATE UNIQUE INDEX IF NOT EXISTS issues_source_ref ON issues(source_ref)")


def _copy_from_old_agent() -> None:
    """First start of this version: bring over people and items entered in the old agent."""
    old = Path(settings.old_database_path)
    if not old.exists() or old.resolve() == Path(settings.database_path).resolve():
        return
    try:
        src = sqlite3.connect(f"file:{old}?mode=ro", uri=True)
        src.row_factory = sqlite3.Row
        for u in src.execute("SELECT phone, name, roles FROM users WHERE active=1 AND phone NOT LIKE '+9198000000%'"):
            old_roles = set(u["roles"].split(","))
            roles = [r for r, olds in (("admin", {"admin"}), ("stock_keeper", {"store_keeper", "counter"}),
                                       ("manager", {"approver", "cost_controller", "stakeholder", "purchase_manager"}))
                     if old_roles & olds]
            execute("INSERT OR IGNORE INTO users(phone,name,roles) VALUES (?,?,?)", (u["phone"], u["name"], ",".join(roles)))
        for i in src.execute("SELECT code, name, unit, rate FROM items"):
            execute("INSERT OR IGNORE INTO items(code,name,unit,rate,count_daily) VALUES (?,?,?,?,0)",
                    (i["code"], i["name"], i["unit"], i["rate"] or 0))
        src.close()
        log_event("copied_from_old_agent", "system")
    except sqlite3.Error:
        log.exception("Could not read the old agent's database")


# ---- settings

def get(key: str) -> Any:
    row = query_one("SELECT value_json FROM settings WHERE key=?", (key,))
    return json.loads(row["value_json"]) if row else DEFAULTS.get(key)


def put(key: str, value: Any) -> None:
    execute("INSERT INTO settings(key,value_json,updated_at) VALUES (?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
            (key, json.dumps(value), now_iso()))


def claim_once(key: str) -> bool:
    """True the first time a key is claimed (for example a job for one day), False after."""
    with _lock:
        cur = conn().execute("INSERT OR IGNORE INTO meta(key,value) VALUES (?,?)", (key, now_iso()))
        conn().commit()
        return cur.rowcount == 1


def log_event(action: str, actor: str | None = None, note: str | None = None) -> None:
    execute("INSERT INTO events(at,actor,action,note) VALUES (?,?,?,?)", (now_iso(), actor, action, note))


# ---- people

def normalize_phone(phone: str) -> str:
    phone = (phone or "").replace("whatsapp:", "").replace(" ", "").replace("-", "").strip()
    if phone and not phone.startswith("+"):
        phone = "+" + phone
    return phone


def get_user(phone: str) -> dict | None:
    u = query_one("SELECT * FROM users WHERE phone=? AND active=1", (normalize_phone(phone),))
    if u:
        u["roles"] = [r for r in u["roles"].split(",") if r]
    return u


def people_with(role: str) -> list[dict]:
    out = []
    for u in query("SELECT * FROM users WHERE active=1"):
        u["roles"] = [r for r in u["roles"].split(",") if r]
        if role in u["roles"]:
            out.append(u)
    return out
