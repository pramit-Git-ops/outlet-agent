"""SQLite storage. One file, no server needed."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from .settings import settings

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  phone TEXT PRIMARY KEY, name TEXT NOT NULL, roles TEXT NOT NULL,
  department TEXT, outlet TEXT, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS contacts (
  phone TEXT PRIMARY KEY, last_inbound_at TEXT
);
CREATE TABLE IF NOT EXISTS items (
  code TEXT PRIMARY KEY, name TEXT NOT NULL, unit TEXT NOT NULL,
  category TEXT, rate REAL DEFAULT 0, petpooja_code TEXT
);
CREATE TABLE IF NOT EXISTS config_overrides (
  key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_by TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS requisitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  outlet TEXT, department TEXT NOT NULL, request_type TEXT NOT NULL,
  requester TEXT NOT NULL, urgent INTEGER DEFAULT 0, fields_json TEXT DEFAULT '{}',
  status TEXT NOT NULL, rule_name TEXT, approvers_json TEXT DEFAULT '[]',
  approval_step INTEGER DEFAULT 0, then_notify_json TEXT DEFAULT '[]',
  escalate_after INTEGER, escalate_to_json TEXT DEFAULT '[]',
  est_value REAL DEFAULT 0, receive_into TEXT DEFAULT 'store',
  vendor TEXT, petpooja_ref TEXT,
  created_at TEXT, updated_at TEXT, last_chased_at TEXT
);
CREATE TABLE IF NOT EXISTS req_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT, req_id INTEGER NOT NULL,
  item_code TEXT, item_name TEXT NOT NULL, qty REAL NOT NULL, unit TEXT,
  rate REAL DEFAULT 0, received_qty REAL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, req_id INTEGER, bill_id INTEGER,
  actor TEXT, action TEXT NOT NULL, note TEXT, at TEXT
);
CREATE TABLE IF NOT EXISTS stock_moves (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL,
  from_loc TEXT, to_loc TEXT, item_code TEXT NOT NULL, qty REAL NOT NULL,
  ref TEXT, actor TEXT
);
CREATE TABLE IF NOT EXISTS counts (
  count_date TEXT NOT NULL, location TEXT NOT NULL, item_code TEXT NOT NULL,
  qty REAL NOT NULL, counted_by TEXT, at TEXT,
  PRIMARY KEY (count_date, location, item_code)
);
CREATE TABLE IF NOT EXISTS count_meta (
  count_date TEXT NOT NULL, location TEXT NOT NULL, status TEXT NOT NULL,
  rooms_occupied INTEGER, submitted_by TEXT, at TEXT,
  PRIMARY KEY (count_date, location)
);
CREATE TABLE IF NOT EXISTS bills (
  id INTEGER PRIMARY KEY AUTOINCREMENT, req_id INTEGER, outlet TEXT,
  vendor TEXT, gstin TEXT, invoice_no TEXT, invoice_date TEXT,
  taxable REAL DEFAULT 0, cgst REAL DEFAULT 0, sgst REAL DEFAULT 0,
  igst REAL DEFAULT 0, total REAL DEFAULT 0, lines_json TEXT DEFAULT '[]',
  media_url TEXT, media_type TEXT, status TEXT NOT NULL, match_notes TEXT,
  petpooja_ref TEXT, tally_status TEXT DEFAULT 'pending', verified_by TEXT,
  captured_by TEXT, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, vendor TEXT NOT NULL, amount REAL NOT NULL,
  mode TEXT, reference TEXT, paid_on TEXT, invoices_json TEXT DEFAULT '[]',
  recorded_by TEXT, status TEXT NOT NULL DEFAULT 'awaiting_petpooja_update',
  confirmed_by TEXT, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS conversations (
  phone TEXT PRIMARY KEY, messages_json TEXT NOT NULL, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY, value TEXT
);
CREATE TABLE IF NOT EXISTS outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT, body TEXT, mode TEXT,
  status TEXT, error TEXT, at TEXT
);
"""


def tz() -> ZoneInfo:
    return ZoneInfo(settings.config.get("business", {}).get("timezone", "Asia/Kolkata"))


def now() -> datetime:
    return datetime.now(tz())


def now_iso() -> str:
    return now().isoformat(timespec="seconds")


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        Path(settings.database_path).parent.mkdir(parents=True, exist_ok=True)
        _conn = sqlite3.connect(settings.database_path, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA foreign_keys=ON")
    return _conn


def reset_connection() -> None:
    """Used by tests to point at a fresh database."""
    global _conn
    if _conn is not None:
        _conn.close()
    _conn = None


def execute(sql: str, params: tuple | list = ()) -> sqlite3.Cursor:
    with _lock:
        cur = conn().execute(sql, params)
        conn().commit()
        return cur


def query(sql: str, params: tuple | list = ()) -> list[dict[str, Any]]:
    with _lock:
        return [dict(r) for r in conn().execute(sql, params).fetchall()]


def query_one(sql: str, params: tuple | list = ()) -> dict[str, Any] | None:
    rows = query(sql, params)
    return rows[0] if rows else None


# Columns added after the first release; added to existing databases on start.
MIGRATIONS = [
    "ALTER TABLE items ADD COLUMN variance_pct REAL",
    "ALTER TABLE items ADD COLUMN variance_qty REAL",
    "ALTER TABLE items ADD COLUMN alert_to TEXT",
]


def init_db(seed: bool = True) -> None:
    with _lock:
        conn().executescript(SCHEMA)
        for sql in MIGRATIONS:
            try:
                conn().execute(sql)
            except sqlite3.OperationalError:
                pass  # column already exists
        conn().commit()
    if seed:
        seed_from_config()


def _changed(key: str, value: Any) -> bool:
    """True the first time, and whenever this part of config.yaml has been edited."""
    digest = hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()
    row = query_one("SELECT value FROM meta WHERE key=?", (key,))
    if row and row["value"] == digest:
        return False
    execute("INSERT INTO meta(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, digest))
    return True


def seed_from_config() -> None:
    """Load users and items from config.yaml on first start, and again whenever
    those sections of the file are edited. People and items added on WhatsApp
    are kept; a person listed in the file gets the file's details."""
    cfg = settings.config
    users = cfg.get("users", [])
    if _changed("seed:users", users):
        for u in users:
            upsert_user(u["phone"], u["name"], u.get("roles", []), u.get("department"), u.get("outlet"))
        listed = {normalize_phone(u["phone"]) for u in users}
        # Sample numbers shipped in config.yaml that have since been replaced.
        for row in query("SELECT phone FROM users WHERE phone LIKE '+9198000000%'"):
            if row["phone"] not in listed:
                execute("UPDATE users SET active=0 WHERE phone=?", (row["phone"],))
    items = cfg.get("items", [])
    if _changed("seed:items", items):
        for it in items:
            pct = it.get("variance_percent")
            execute(
                "INSERT OR REPLACE INTO items(code,name,unit,category,rate,petpooja_code,variance_pct,variance_qty,alert_to) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (it["code"], it["name"], it["unit"], it.get("category"), it.get("rate", 0), it.get("petpooja_code"),
                 pct / 100 if pct is not None else None, it.get("variance_qty"),
                 ",".join(normalize_recipient(p) for p in it.get("alert_to", [])) or None),
            )


def claim_once(key: str) -> bool:
    """True the first time a key is claimed (e.g. a job for one day), False after."""
    with _lock:
        cur = conn().execute("INSERT OR IGNORE INTO meta(key,value) VALUES (?,?)", (key, now_iso()))
        conn().commit()
        return cur.rowcount == 1


def normalize_recipient(entry: str) -> str:
    """A phone number, or a role reference such as role:purchase_manager."""
    entry = str(entry or "").strip()
    return entry if entry.startswith("role:") else normalize_phone(entry)


def normalize_phone(phone: str) -> str:
    phone = (phone or "").replace("whatsapp:", "").replace(" ", "").strip()
    if phone and not phone.startswith("+"):
        phone = "+" + phone
    return phone


def upsert_user(phone: str, name: str, roles: list[str], department: str | None, outlet: str | None) -> None:
    execute(
        "INSERT INTO users(phone,name,roles,department,outlet,active) VALUES (?,?,?,?,?,1) "
        "ON CONFLICT(phone) DO UPDATE SET name=excluded.name, roles=excluded.roles, "
        "department=excluded.department, outlet=excluded.outlet, active=1",
        (normalize_phone(phone), name, ",".join(roles), department, outlet),
    )


def get_user(phone: str) -> dict | None:
    u = query_one("SELECT * FROM users WHERE phone=? AND active=1", (normalize_phone(phone),))
    if u:
        u["roles"] = [r for r in u["roles"].split(",") if r]
    return u


def users_with_role(role: str) -> list[dict]:
    out = []
    for u in query("SELECT * FROM users WHERE active=1"):
        roles = u["roles"].split(",")
        if role in roles:
            u["roles"] = roles
            out.append(u)
    return out


# ---- effective configuration (YAML + admin overrides) ----

def cfg(key: str, default: Any = None) -> Any:
    row = query_one("SELECT value_json FROM config_overrides WHERE key=?", (key,))
    if row:
        return json.loads(row["value_json"])
    return settings.config.get(key, default)


def set_cfg(key: str, value: Any, by: str) -> None:
    execute(
        "INSERT INTO config_overrides(key,value_json,updated_by,updated_at) VALUES (?,?,?,?) "
        "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, "
        "updated_by=excluded.updated_by, updated_at=excluded.updated_at",
        (key, json.dumps(value), by, now_iso()),
    )


def log_event(action: str, actor: str | None = None, note: str | None = None,
              req_id: int | None = None, bill_id: int | None = None) -> None:
    execute(
        "INSERT INTO events(req_id,bill_id,actor,action,note,at) VALUES (?,?,?,?,?,?)",
        (req_id, bill_id, actor, action, note, now_iso()),
    )
