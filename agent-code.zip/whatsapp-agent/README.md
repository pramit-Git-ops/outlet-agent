# Kitchen stock agent (version 2)

A WhatsApp agent for the daily kitchen stock check, with a web admin panel.

1. Stock sent to the kitchen is recorded on WhatsApp ("issued 10 kg chicken") or in the admin panel.
2. Every day the stock keeper gets the count list on WhatsApp and sends the quantities.
3. Petpooja sends every printed bill to the agent; recipes turn dishes sold into ideal consumption.
4. Actual consumption = previous count + sent to kitchen - today's count. Variance = actual - ideal,
   valued at the item's rate.
5. An Excel file with these columns is emailed every day to the addresses set in the admin panel.

The administrator sets everything in the admin panel at `/admin`: people and roles, the items and which
are counted daily, rates, recipes, times, email addresses and house rules for the agent. `/health` shows
what is still missing.

Railway variables: see `.env.example`. Data is kept in `data/stock_agent.db` on the Railway volume; on the
first start, people and items from the earlier agent (`data/agent.db`) are copied in (items unticked).

Tests: `python3 -m pytest -q tests`
