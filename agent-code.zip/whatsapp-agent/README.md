# Kitchen stock agent (version 2)

A WhatsApp agent for the daily kitchen stock check, with a web admin panel.

1. Stock sent to the kitchen comes from Petpooja internal transfers (Inventory API), or is recorded on
   WhatsApp ("issued 10 kg chicken") or in the admin panel.
2. Every day the stock keeper gets the count list on WhatsApp and sends the quantities.
3. Ideal consumption comes from Petpooja's Consumption API (raw materials its recipes deduct per bill), or
   from bills pushed by the Global API x recipes entered in the admin panel.
4. Actual consumption = previous count + sent to kitchen - today's count. Variance = actual - ideal,
   valued at the item's rate (latest Petpooja purchase price when Petpooja is connected).
5. An Excel file with these columns is emailed every day to the addresses set in the admin panel.

The administrator sets everything in the admin panel at `/admin`: people and roles, the items and which
are counted daily, rates, recipes, times, email addresses and house rules for the agent. `/health` shows
what is still missing.

Petpooja Inventory API (`app/petpooja.py`) is fetched every hour, when the count finishes and before the
report. Raw materials match items by SAP code, then 'Name in Petpooja', then item name; units such as gm/kg
and ml/litre are converted.

Railway variables: see `.env.example`. Data is kept in `data/stock_agent.db` on the Railway volume; on the
first start, people and items from the earlier agent (`data/agent.db`) are copied in (items unticked).

Tests: `python3 -m pytest -q tests`
