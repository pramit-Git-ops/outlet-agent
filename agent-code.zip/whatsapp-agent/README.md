# Outlet Ops WhatsApp Agent

A WhatsApp-only agent for hotel and restaurant outlets. Staff chat with one WhatsApp number from their personal WhatsApp; the agent (Claude) runs three workflows with no paper:

1. **Purchase and requisition.** Kitchen, bar and housekeeping raise requests in plain words. The agent fills the configured format, routes it to the right approver, tells the purchase manager to order, records goods received, and pushes the purchase to Petpooja when the purchase manager replies `push 12`.
2. **Daily stock count.** At 7:00 each counter gets a count sheet on WhatsApp and replies with quantities (text, or a photo of their counting). The moment a location's count is complete, the agent works out each item's actual use for the previous day (opening + issued − closing), pulls Petpooja's recipe-based use (portions sold × recipe) and messages the concerned people about every item whose difference is beyond its own threshold. Example: arhar dal counted use 1.5 kg, Petpooja 1.2 kg, threshold 10% → alert. Thresholds are set per product (percent or quantity) in `config.yaml` or on WhatsApp. At 9:15 the owner also gets the full report.
3. **Vendor payments.** Accounts asks "what is pending for City Liquors?" and gets the open invoices and total from Petpooja (or from the agent's own bill records until Petpooja is connected). When accounts says a payment is done, the agent records it and tells the purchase manager to enter it in Petpooja; the purchase manager replies "payment 7 updated" and accounts is told. Unconfirmed payments are chased after 24 hours.
4. **Bills and accounts.** A photo of a supplier bill is read by the agent, matched to the order and the goods received, sent to accounts after it is in Petpooja, and posted to Tally (import file, or direct push).

The agent's own instructions are in [app/prompts.py](app/prompts.py). The prompt to rebuild or extend the agent with an AI coding tool is in [BUILD_PROMPT.md](BUILD_PROMPT.md).

## What you need

| Item | Where | Notes |
| --- | --- | --- |
| Anthropic API key | console.anthropic.com | Pay as you go |
| Twilio account, upgraded | console.twilio.com | Twilio adds about $0.005 per WhatsApp message, in and out, on top of Meta's fees |
| A phone number not already on WhatsApp | New SIM, landline, or a Twilio number | Must receive an SMS or call once for verification |
| Meta Business Portfolio | Created during Twilio sign-up | Business verification needed before production |
| A server with a public HTTPS URL | Railway, Render, AWS Lightsail, a VPS | One small instance; see Deploy |
| Petpooja inventory API credentials | Petpooja support / account manager | Optional at first: without them the agent writes a daily Petpooja upload file |
| TallyPrime on the accounts PC | Already in use | Version 7.0+ preferred |

## 1. Set up Twilio WhatsApp

1. **Try it in the sandbox first (10 minutes).** In the Twilio Console go to Messaging > Try it out > Send a WhatsApp message. Each tester joins the sandbox by sending the join code to the sandbox number. Set the sandbox's "When a message comes in" URL to `https://YOUR-SERVER/whatsapp` (method POST). Use `TWILIO_WHATSAPP_FROM=whatsapp:+14155238886` while testing.
2. **Register your own number for production.** Messaging > Senders > WhatsApp Senders > Create new sender. Pick your number, click Continue with Facebook, create or select your Meta Business Portfolio, create a new WhatsApp Business Account inside the Twilio flow, set the display name, and verify the number by SMS or call. Then complete Meta business verification.
3. **Point the sender at the agent.** Edit Sender > inbound message webhook: `https://YOUR-SERVER/whatsapp`, POST.
4. **Create one message template** for messages to people who have not written in the last 24 hours (count sheets, approvals, digests). Messaging > Content Template Builder > Create, type Text, category Utility, body `Update from your outlet assistant: {{1}}` (Meta usually rejects a body that is only a variable). Submit for WhatsApp approval and put its Content SID (starts with `HX`) in `TWILIO_NOTICE_CONTENT_SID`.

Team members do nothing except save the number and send it a message once (or join the sandbox while testing).

## 2. Configure

1. Copy `.env.example` to `.env` and fill in the Anthropic and Twilio values and `PUBLIC_BASE_URL` (your server's https address; automatic on Railway).
2. Edit [config.yaml](config.yaml): outlets, people and roles, routing rules, requisition formats, items, count times, tolerances, housekeeping norms, Tally ledger names. People and items in the file are loaded on first start and again whenever you edit them. Everything except outlets can be changed later by an admin on WhatsApp, for example "make Sunita a counter for housekeeping" or "bar requests above 5,000 need my approval".

Roles: `admin`, `requester`, `approver`, `purchase_manager`, `store_keeper`, `counter`, `accounts`, `cost_controller`, `stakeholder`, plus any extra roles added in the admin panel. A person can hold several.

## Petpooja live sales (Global API)

Petpooja pushes every printed bill to `/petpooja/orders/<token>` (the full
address is on `/health` and in the admin panel under "Petpooja & recipes").
Cancelled bills replace the earlier copy. Recipes entered in the admin panel
turn dishes sold between two morning counts into expected raw-material use,
which the count is compared with. The Global API carries sales only; purchase
push, stock and vendor dues still need Petpooja's inventory API (manual mode
until then).

## Admin panel

Set `ADMIN_PASSWORD` and open `https://YOUR-SERVER/admin`. The administrator manages everything there without touching files:

- **People & roles:** names, WhatsApp numbers and roles, including the cost controller, purchase manager, store keeper, accounts and stakeholders, plus extra roles you define.
- **Items**, **Requisition types** (new types and their fields), **Approval routing**, **Stock count** times, counters and leakage limits, **Accounts & Tally**.
- **Deadlines & alerts:** limits for approvals, ordering, delivery, the morning count, bills, Tally and Petpooja payment updates. Each missed deadline is sent once to the cost controller (`deadlines.alert_to`), and anyone authorised can ask the agent "show delays".
- **Reminders:** your own scheduled WhatsApp messages to people or roles.
- **House rules:** plain-language instructions the agent follows in every chat.
- **Activity** log and an **Advanced** raw editor for every section.

Settings that name a role (`role:purchase_manager`, `role:counter@kitchen`) follow whoever holds it, so changing a person's role re-routes their work. New kinds of behaviour beyond these settings still need a code change.

## 3. Connect Petpooja (when credentials arrive)

Put the values Petpooja gives you in `.env`:

```
PETPOOJA_BASE_URL=https://...
PETPOOJA_APP_KEY=...
PETPOOJA_APP_SECRET=...
PETPOOJA_ACCESS_TOKEN=...
PETPOOJA_REST_IDS=MAIN=xxxx,BAR1=yyyy
```

Then open the `petpooja:` section of `config.yaml` and set the endpoint paths and field names (raw-material list, stock, purchase entry, recipe-based consumption with portions sold, and vendor outstanding) to the ones in Petpooja's inventory API documentation (the shipped values are placeholders, because Petpooja does not publish this API). Restart, then run `python -m app.cli sync-items` to load the raw-material list. The adapter is in [app/petpooja.py](app/petpooja.py); if Petpooja's request format differs from the generic one there, only `HttpAdapter` needs adjusting.

The two read endpoints the worked examples depend on, recipe-based consumption and vendor outstanding, are not in any public Petpooja documentation, so confirm with Petpooja that they exist and what they return. If Petpooja has no vendor-outstanding endpoint, remove `vendor_payables` from the config and the agent keeps using its own bill and payment records.

Without credentials the agent still works: each `push` adds the purchase to `data/exports/petpooja_purchases_YYYY-MM-DD.csv`, and the stock report shows actual use without the expected-use comparison for kitchen and bar.

## 4. Tally

`tally.mode: export_file` (default): accounts replies "post to Tally" and gets a download link to an XML file of verified purchase vouchers; in TallyPrime use Import > Transactions. Test on a copy of your company first and make sure every ledger name in `config.yaml` exists in Tally.

`tally.mode: direct_push`: the agent posts vouchers straight to TallyPrime's HTTP server (Tally must be open, with its HTTP port, usually 9000, reachable from the agent through a secure tunnel such as Cloudflare Tunnel). Use this once the import file has been trusted for a few weeks.

## Run locally

```
python -m pip install -r requirements.txt
cp .env.example .env   # fill it in
uvicorn app.main:app --port 8000
```

Expose it with a tunnel (for example `cloudflared tunnel --url http://localhost:8000`) and use that https URL as `PUBLIC_BASE_URL` and as the Twilio webhook.

## Deploy

New to this? Follow the click-by-click Railway guide: https://claude.ai/code/artifact/e2d5b4a8-34d5-42de-8d61-eff04e626656. After deploying, open `https://YOUR-SERVER/health`: the `setup` section lists anything still missing, and `webhook_to_paste_in_twilio` is the exact URL for Twilio.

Any host that runs a Docker image or a Python web app. Use the [Dockerfile](Dockerfile), one instance, and a persistent volume mounted at `/app/data` (the SQLite database and export files live there). Run a single worker: the scheduler runs inside the app.

## Tests

```
python -m pytest -q tests
```

The tests run a full day without any external service: a bar requisition through approval, order, short delivery, bill mismatch and override, Petpooja push, accounts verification and Tally export; two days of stock counts with a housekeeping leakage; escalation; admin routing changes; and the Claude loop and Twilio webhook with a scripted fake model.

## Useful commands

```
python -m app.cli send-count-sheets     # send today's count sheets now
python -m app.cli stock-report          # print today's consumption report
python -m app.cli sync-items            # pull raw materials from Petpooja
python -m app.cli chase                 # remind and escalate overdue approvals
```

## Things to know

- Claude model: `claude-opus-5-5` at low effort by default (`CLAUDE_MODEL`, `CLAUDE_EFFORT`). Refusal fallback is switched on, so a request a safety filter declines is retried on another Claude model automatically.
- WhatsApp only allows free-form messages within 24 hours of the person's last message; outside that, the agent uses your approved template. If a send fails it is logged in the `outbox` table.
- Voice notes are not transcribed yet; the agent asks the person to type or send a photo. A speech-to-text service can be added in `app/agent.py` (`_media_blocks`).
- Bill photos are sent to Claude for reading; keep `LINK_SECRET` private, since export links are signed with it.
